import * as i0 from '@angular/core';
import { input, booleanAttribute, inject, ElementRef, computed, afterNextRender, ChangeDetectionStrategy, Component, signal, contentChild, effect, model, output, Injectable, DOCUMENT, DestroyRef, HostListener, Directive, viewChild } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i1 from '@angular/cdk/a11y';
import { A11yModule } from '@angular/cdk/a11y';
import * as i1$1 from '@angular/cdk/scrolling';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { NgTemplateOutlet } from '@angular/common';

/**
 * Botão do design system.
 *
 * Usa seletor de atributo para aplicar em `<button>` ou `<a>` sem elemento
 * extra no DOM e sem perder a semântica nativa (foco, Enter, `href`).
 *
 * @example
 * ```html
 * <button bdButton>Salvar</button>
 * <button bdButton variant="ghost" size="sm">Cancelar</button>
 * <button bdButton [loading]="salvando()">Enviar</button>
 * <button bdButton iconOnly aria-label="Fechar"><i class="fas fa-times"></i></button>
 * <a bdButton variant="subtle" href="/docs">Documentação</a>
 * ```
 */
class BdButtonComponent {
    variant = input('primary', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : []));
    /** Ocupa toda a largura disponível. */
    block = input(false, ...(ngDevMode ? [{ debugName: "block", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Mostra o spinner e bloqueia a interação. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Botão quadrado só com ícone — exige `aria-label`. */
    iconOnly = input(false, ...(ngDevMode ? [{ debugName: "iconOnly", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    host = inject(ElementRef);
    isDisabled = computed(() => this.disabled() || this.loading(), ...(ngDevMode ? [{ debugName: "isDisabled" }] : []));
    classes = computed(() => [
        `bd-button--${this.variant()}`,
        `bd-button--${this.size()}`,
        this.block() ? 'bd-button--block' : '',
        this.iconOnly() ? 'bd-button--icon' : '',
    ]
        .filter(Boolean)
        .join(' '), ...(ngDevMode ? [{ debugName: "classes" }] : []));
    constructor() {
        // Um botão só de ícone sem rótulo acessível é invisível para leitor de
        // tela. Avisa em desenvolvimento; em produção o aviso é removido do bundle.
        if (ngDevMode) {
            afterNextRender(() => {
                const el = this.host.nativeElement;
                if (this.iconOnly() &&
                    !el.getAttribute('aria-label') &&
                    !el.getAttribute('aria-labelledby')) {
                    console.warn('[bandeira-ui] <button bdButton iconOnly> precisa de aria-label ou aria-labelledby ' +
                        'para ser anunciado por leitores de tela.', el);
                }
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdButtonComponent, isStandalone: true, selector: "button[bdButton], a[bdButton]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, block: { classPropertyName: "block", publicName: "block", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, iconOnly: { classPropertyName: "iconOnly", publicName: "iconOnly", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()", "attr.aria-busy": "loading() ? true : null", "attr.disabled": "isDisabled() || null", "attr.tabindex": "isDisabled() ? -1 : null" } }, ngImport: i0, template: `
    @if (loading()) {
      <span class="bd-button__spinner" aria-hidden="true"></span>
    }
    <span class="bd-button__content"><ng-content /></span>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;justify-content:center;gap:var(--bd-space-2, .5rem);border:1px solid transparent;border-radius:var(--bd-radius-sm, .5rem);font-family:inherit;font-weight:var(--bd-weight-semibold, 600);text-decoration:none;white-space:nowrap;cursor:pointer;transition:background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease),box-shadow var(--bd-duration, .25s) ease}:host(:hover:not([disabled])){transform:translateY(-2px)}:host(:active:not([disabled])){transform:translateY(0)}:host(:focus-visible){outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}:host([disabled]),:host([aria-busy=\"true\"]){opacity:.6;cursor:not-allowed;transform:none;pointer-events:none}:host(.bd-button--sm){min-height:38px;padding:.45rem .95rem;font-size:var(--bd-text-sm, .875rem)}:host(.bd-button--md){min-height:44px;padding:.7rem 1.4rem;font-size:.95rem}:host(.bd-button--lg){min-height:52px;padding:.9rem 1.9rem;font-size:var(--bd-text-lg, 1.125rem)}:host(.bd-button--icon.bd-button--sm){width:38px;padding:0}:host(.bd-button--icon.bd-button--md){width:44px;padding:0}:host(.bd-button--icon.bd-button--lg){width:52px;padding:0}:host(.bd-button--block){display:flex;width:100%}:host(.bd-button--primary){background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}:host(.bd-button--primary:hover:not([disabled])){background:var(--bd-primary, #3d5ce8)}:host(.bd-button--ghost){background:transparent;border-color:var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c)}:host(.bd-button--ghost:hover:not([disabled])){border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}:host(.bd-button--subtle){background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8)}:host(.bd-button--subtle:hover:not([disabled])){background:var(--bd-surface-hover, #f1f3f9)}:host(.bd-button--danger){background:var(--bd-danger, #dc2626);color:var(--bd-danger-contrast, #fff)}:host(.bd-button--danger:hover:not([disabled])){filter:brightness(1.1)}.bd-button__content{display:inline-flex;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-button__spinner{width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:bd-spin .7s linear infinite}@keyframes bd-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){:host,:host(:hover:not([disabled])){transition:none;transform:none}.bd-button__spinner{animation-duration:1.6s}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'button[bdButton], a[bdButton]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (loading()) {
      <span class="bd-button__spinner" aria-hidden="true"></span>
    }
    <span class="bd-button__content"><ng-content /></span>
  `, host: {
                        '[class]': 'classes()',
                        '[attr.aria-busy]': 'loading() ? true : null',
                        '[attr.disabled]': 'isDisabled() || null',
                        '[attr.tabindex]': 'isDisabled() ? -1 : null',
                    }, styles: [":host{display:inline-flex;align-items:center;justify-content:center;gap:var(--bd-space-2, .5rem);border:1px solid transparent;border-radius:var(--bd-radius-sm, .5rem);font-family:inherit;font-weight:var(--bd-weight-semibold, 600);text-decoration:none;white-space:nowrap;cursor:pointer;transition:background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease),box-shadow var(--bd-duration, .25s) ease}:host(:hover:not([disabled])){transform:translateY(-2px)}:host(:active:not([disabled])){transform:translateY(0)}:host(:focus-visible){outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}:host([disabled]),:host([aria-busy=\"true\"]){opacity:.6;cursor:not-allowed;transform:none;pointer-events:none}:host(.bd-button--sm){min-height:38px;padding:.45rem .95rem;font-size:var(--bd-text-sm, .875rem)}:host(.bd-button--md){min-height:44px;padding:.7rem 1.4rem;font-size:.95rem}:host(.bd-button--lg){min-height:52px;padding:.9rem 1.9rem;font-size:var(--bd-text-lg, 1.125rem)}:host(.bd-button--icon.bd-button--sm){width:38px;padding:0}:host(.bd-button--icon.bd-button--md){width:44px;padding:0}:host(.bd-button--icon.bd-button--lg){width:52px;padding:0}:host(.bd-button--block){display:flex;width:100%}:host(.bd-button--primary){background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}:host(.bd-button--primary:hover:not([disabled])){background:var(--bd-primary, #3d5ce8)}:host(.bd-button--ghost){background:transparent;border-color:var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c)}:host(.bd-button--ghost:hover:not([disabled])){border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}:host(.bd-button--subtle){background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8)}:host(.bd-button--subtle:hover:not([disabled])){background:var(--bd-surface-hover, #f1f3f9)}:host(.bd-button--danger){background:var(--bd-danger, #dc2626);color:var(--bd-danger-contrast, #fff)}:host(.bd-button--danger:hover:not([disabled])){filter:brightness(1.1)}.bd-button__content{display:inline-flex;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-button__spinner{width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:bd-spin .7s linear infinite}@keyframes bd-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){:host,:host(:hover:not([disabled])){transition:none;transform:none}.bd-button__spinner{animation-duration:1.6s}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], block: [{ type: i0.Input, args: [{ isSignal: true, alias: "block", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], iconOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnly", required: false }] }] } });

let instanceCount$5 = 0;
/**
 * Aplica o estilo do design system em `<input>`, `<textarea>` e `<select>`.
 *
 * É um componente de seletor por atributo com template vazio: o estilo fica
 * encapsulado (sem `::ng-deep`) e o elemento nativo continua sendo o elemento
 * real do formulário, então `formControlName`, `type` e validação nativa
 * funcionam sem intermediário.
 *
 * Dentro de um `<bd-field>`, recebe automaticamente o `id` usado pelo `for` do
 * rótulo e as ligações de `aria-describedby` / `aria-invalid`.
 *
 * @example
 * ```html
 * <bd-field label="Seu e-mail" [error]="erro()">
 *   <input bdInput type="email" formControlName="email" />
 * </bd-field>
 *
 * <input bdInput type="text" placeholder="Busca" />
 * ```
 */
class BdInputComponent {
    /** Informe para fixar o `id`; do contrário um é gerado. */
    inputId = input('', ...(ngDevMode ? [{ debugName: "inputId", alias: 'id' }] : [{ alias: 'id' }]));
    gerado = `bd-input-${instanceCount$5++}`;
    /** Preenchidos pelo `<bd-field>` que envolve este campo. */
    fieldDescribedBy = signal('', ...(ngDevMode ? [{ debugName: "fieldDescribedBy" }] : []));
    fieldInvalid = signal(false, ...(ngDevMode ? [{ debugName: "fieldInvalid" }] : []));
    element = inject(ElementRef);
    id = computed(() => this.inputId() || this.gerado, ...(ngDevMode ? [{ debugName: "id" }] : []));
    describedBy = computed(() => this.fieldDescribedBy(), ...(ngDevMode ? [{ debugName: "describedBy" }] : []));
    invalid = computed(() => this.fieldInvalid(), ...(ngDevMode ? [{ debugName: "invalid" }] : []));
    /** @internal chamado pelo `<bd-field>` que envolve este campo. */
    _conectarAoField(describedBy, invalido) {
        this.fieldDescribedBy.set(describedBy);
        this.fieldInvalid.set(invalido);
    }
    focus() {
        this.element.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdInputComponent, isStandalone: true, selector: "input[bdInput], textarea[bdInput], select[bdInput]", inputs: { inputId: { classPropertyName: "inputId", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()", "attr.aria-describedby": "describedBy() || null", "attr.aria-invalid": "invalid() || null", "class.bd-input--invalid": "invalid()" }, classAttribute: "bd-input" }, ngImport: i0, template: '', isInline: true, styles: [":host{display:block;width:100%;padding:var(--bd-space-3, .75rem) var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font-family:inherit;font-size:var(--bd-text-base, 1rem);line-height:var(--bd-leading-normal, 1.6);transition:border-color var(--bd-duration, .25s) ease,box-shadow var(--bd-duration, .25s) ease}:host::placeholder{color:var(--bd-fg-subtle, #7b8399)}:host(:hover:not(:disabled)){border-color:var(--bd-border-strong, #cbd2e2)}:host(:focus){outline:none;border-color:var(--bd-primary, #3d5ce8);box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .1))}:host(:disabled){opacity:.6;cursor:not-allowed;background:var(--bd-surface-hover, #f1f3f9)}:host(.bd-input--invalid){border-color:var(--bd-danger, #dc2626)}:host(.bd-input--invalid:focus){box-shadow:0 0 0 3px var(--bd-danger-soft, rgba(220, 38, 38, .1))}:host(textarea){resize:vertical;min-height:120px}:host(select){cursor:pointer;appearance:none;padding-right:var(--bd-space-6, 2rem)}@media(prefers-reduced-motion:reduce){:host{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'input[bdInput], textarea[bdInput], select[bdInput]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: '', host: {
                        class: 'bd-input',
                        '[id]': 'id()',
                        '[attr.aria-describedby]': 'describedBy() || null',
                        '[attr.aria-invalid]': 'invalid() || null',
                        '[class.bd-input--invalid]': 'invalid()',
                    }, styles: [":host{display:block;width:100%;padding:var(--bd-space-3, .75rem) var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font-family:inherit;font-size:var(--bd-text-base, 1rem);line-height:var(--bd-leading-normal, 1.6);transition:border-color var(--bd-duration, .25s) ease,box-shadow var(--bd-duration, .25s) ease}:host::placeholder{color:var(--bd-fg-subtle, #7b8399)}:host(:hover:not(:disabled)){border-color:var(--bd-border-strong, #cbd2e2)}:host(:focus){outline:none;border-color:var(--bd-primary, #3d5ce8);box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .1))}:host(:disabled){opacity:.6;cursor:not-allowed;background:var(--bd-surface-hover, #f1f3f9)}:host(.bd-input--invalid){border-color:var(--bd-danger, #dc2626)}:host(.bd-input--invalid:focus){box-shadow:0 0 0 3px var(--bd-danger-soft, rgba(220, 38, 38, .1))}:host(textarea){resize:vertical;min-height:120px}:host(select){cursor:pointer;appearance:none;padding-right:var(--bd-space-6, 2rem)}@media(prefers-reduced-motion:reduce){:host{transition:none}}\n"] }]
        }], propDecorators: { inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

let instanceCount$4 = 0;
/**
 * Envelope de campo de formulário: rótulo, controle, dica e mensagem de erro.
 *
 * Encontra o `[bdInput]` projetado e liga tudo sozinho — o `for` do rótulo
 * aponta para o `id` real do campo, o `aria-describedby` aponta para a dica ou
 * o erro, e o `aria-invalid` acompanha o estado. Quem consome não precisa
 * lembrar de nada disso.
 *
 * @example
 * ```html
 * <bd-field label="Seu e-mail" hint="Não compartilho com ninguém" required>
 *   <input bdInput type="email" formControlName="email" />
 * </bd-field>
 *
 * <bd-field label="Mensagem" [error]="erro()">
 *   <textarea bdInput rows="4"></textarea>
 * </bd-field>
 * ```
 */
class BdFieldComponent {
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    hint = input('', ...(ngDevMode ? [{ debugName: "hint" }] : []));
    /** Quando presente, substitui a dica, pinta o campo e vira `role="alert"`. */
    error = input('', ...(ngDevMode ? [{ debugName: "error" }] : []));
    required = input(false, ...(ngDevMode ? [{ debugName: "required", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    uid = instanceCount$4++;
    errorId = `bd-field-error-${this.uid}`;
    hintId = `bd-field-hint-${this.uid}`;
    /** O campo projetado — é dele que sai o `id` usado no `for` do rótulo. */
    control = contentChild(BdInputComponent, ...(ngDevMode ? [{ debugName: "control" }] : []));
    controlId = computed(() => this.control()?.id() ?? '', ...(ngDevMode ? [{ debugName: "controlId" }] : []));
    constructor() {
        // Empurra a descrição e o estado de erro para o campo projetado.
        effect(() => {
            const control = this.control();
            if (!control)
                return;
            const describedBy = this.error() ? this.errorId : this.hint() ? this.hintId : '';
            control._conectarAoField(describedBy, !!this.error());
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdFieldComponent, isStandalone: true, selector: "bd-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "control", first: true, predicate: BdInputComponent, descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (label()) {
      <label class="bd-field__label" [attr.for]="controlId()">
        {{ label() }}
        @if (required()) {
          <span class="bd-field__required" aria-hidden="true">*</span>
          <span class="bd-sr-only">(obrigatório)</span>
        }
      </label>
    }

    <ng-content />

    @if (error()) {
      <span class="bd-field__error" [id]="errorId" role="alert">{{ error() }}</span>
    } @else if (hint()) {
      <span class="bd-field__hint" [id]="hintId">{{ hint() }}</span>
    }
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;gap:var(--bd-space-2, .5rem)}.bd-field__label{font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-semibold, 600);color:var(--bd-fg-muted, #545c70)}.bd-field__required{margin-left:.15rem;color:var(--bd-danger, #dc2626)}.bd-field__error{color:var(--bd-danger, #dc2626);font-size:var(--bd-text-xs, .75rem)}.bd-field__hint{color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem)}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-field', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (label()) {
      <label class="bd-field__label" [attr.for]="controlId()">
        {{ label() }}
        @if (required()) {
          <span class="bd-field__required" aria-hidden="true">*</span>
          <span class="bd-sr-only">(obrigatório)</span>
        }
      </label>
    }

    <ng-content />

    @if (error()) {
      <span class="bd-field__error" [id]="errorId" role="alert">{{ error() }}</span>
    } @else if (hint()) {
      <span class="bd-field__hint" [id]="hintId">{{ hint() }}</span>
    }
  `, styles: [":host{display:flex;flex-direction:column;gap:var(--bd-space-2, .5rem)}.bd-field__label{font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-semibold, 600);color:var(--bd-fg-muted, #545c70)}.bd-field__required{margin-left:.15rem;color:var(--bd-danger, #dc2626)}.bd-field__error{color:var(--bd-danger, #dc2626);font-size:var(--bd-text-xs, .75rem)}.bd-field__hint{color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem)}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], control: [{ type: i0.ContentChild, args: [i0.forwardRef(() => BdInputComponent), { isSignal: true }] }] } });

let instanceCount$3 = 0;
/**
 * Caixa de seleção.
 *
 * Suporta o estado indeterminado — o "traço" que representa seleção parcial
 * numa lista de filhos. Ele é visual e ARIA, não um terceiro value: ao clicar,
 * o controle vira marcado.
 *
 * @example
 * ```html
 * <bd-checkbox [(checked)]="aceito">Aceito os termos</bd-checkbox>
 * <bd-checkbox formControlName="ativo" indeterminate>Todos</bd-checkbox>
 * ```
 */
class BdCheckboxComponent {
    /** Two-way: `[(checked)]="aceito"`. */
    checked = model(false, ...(ngDevMode ? [{ debugName: "checked" }] : []));
    /** Seleção parcial. Ao clicar, o controle passa a marcado. */
    indeterminate = model(false, ...(ngDevMode ? [{ debugName: "indeterminate" }] : []));
    /** Desabilita via template: `<bd-checkbox disabled>`. */
    disabledInput = input(false, ...(ngDevMode ? [{ debugName: "disabledInput", alias: 'disabled', transform: booleanAttribute }] : [{ alias: 'disabled', transform: booleanAttribute }]));
    /** Escrito pelo Reactive Forms via setDisabledState. */
    disabledByForm = signal(false, ...(ngDevMode ? [{ debugName: "disabledByForm" }] : []));
    /** Vale isDisabled se veio do template OU do formulário. */
    disabled = computed(() => this.disabledInput() || this.disabledByForm(), ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    uid = instanceCount$3++;
    id = `bd-checkbox-${this.uid}`;
    labelId = `bd-checkbox-label-${this.uid}`;
    onChangeFn = () => { };
    onTouchedFn = () => { };
    toggle() {
        if (this.disabled())
            return;
        // Indeterminado sempre resolve para marcado — é o comportamento nativo.
        const novo = this.indeterminate() ? true : !this.checked();
        this.indeterminate.set(false);
        this.checked.set(novo);
        this.onChangeFn(novo);
    }
    /* ---------------------------------------------- ControlValueAccessor --- */
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabledByForm.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdCheckboxComponent, isStandalone: true, selector: "bd-checkbox", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, indeterminate: { classPropertyName: "indeterminate", publicName: "indeterminate", isSignal: true, isRequired: false, transformFunction: null }, disabledInput: { classPropertyName: "disabledInput", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange", indeterminate: "indeterminateChange" }, host: { properties: { "class.bd-checkbox--disabled": "disabled()" } }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: BdCheckboxComponent, multi: true }], ngImport: i0, template: `
    <button
      type="button"
      role="checkbox"
      class="bd-checkbox__box"
      [id]="id"
      [attr.aria-checked]="indeterminate() ? 'mixed' : checked()"
      [attr.aria-labelledby]="labelId"
      [disabled]="disabled()"
      (click)="toggle()"
      (blur)="onTouchedFn()"
    >
      <span class="bd-checkbox__mark" aria-hidden="true">
        {{ indeterminate() ? '–' : '✓' }}
      </span>
    </button>

    <!-- O atributo for só vincula elementos rotuláveis, e um button não é um
         deles: o vínculo semântico vem de aria-labelledby, e o clique no
         rótulo é encaminhado explicitamente. -->
    <span class="bd-checkbox__label" [id]="labelId" (click)="toggle()">
      <ng-content />
    </span>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:flex-start;gap:var(--bd-space-3, .75rem)}.bd-checkbox__box{flex-shrink:0;display:grid;place-items:center;width:20px;height:20px;margin-top:.1rem;padding:0;background:var(--bd-bg, #fff);border:1.5px solid var(--bd-border-strong, #cbd2e2);border-radius:.35rem;cursor:pointer;transition:background var(--bd-duration-fast, .15s) ease,border-color var(--bd-duration-fast, .15s) ease}.bd-checkbox__box[aria-checked=true],.bd-checkbox__box[aria-checked=mixed]{background:var(--bd-primary, #3d5ce8);border-color:var(--bd-primary, #3d5ce8)}.bd-checkbox__box:hover:not(:disabled){border-color:var(--bd-primary, #3d5ce8)}.bd-checkbox__box:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-checkbox__box:disabled{opacity:.5;cursor:not-allowed}.bd-checkbox__mark{color:var(--bd-primary-contrast, #fff);font-size:.72rem;font-weight:700;line-height:1;opacity:0;transform:scale(.6);transition:opacity var(--bd-duration-fast, .15s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease)}.bd-checkbox__box[aria-checked=true] .bd-checkbox__mark,.bd-checkbox__box[aria-checked=mixed] .bd-checkbox__mark{opacity:1;transform:none}.bd-checkbox__label{color:var(--bd-fg, #10131c);font-size:.93rem;line-height:1.5;cursor:pointer;-webkit-user-select:none;user-select:none}:host(.bd-checkbox--disabled) .bd-checkbox__label{opacity:.5;cursor:not-allowed}@media(prefers-reduced-motion:reduce){.bd-checkbox__box,.bd-checkbox__mark{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-checkbox', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: BdCheckboxComponent, multi: true }], template: `
    <button
      type="button"
      role="checkbox"
      class="bd-checkbox__box"
      [id]="id"
      [attr.aria-checked]="indeterminate() ? 'mixed' : checked()"
      [attr.aria-labelledby]="labelId"
      [disabled]="disabled()"
      (click)="toggle()"
      (blur)="onTouchedFn()"
    >
      <span class="bd-checkbox__mark" aria-hidden="true">
        {{ indeterminate() ? '–' : '✓' }}
      </span>
    </button>

    <!-- O atributo for só vincula elementos rotuláveis, e um button não é um
         deles: o vínculo semântico vem de aria-labelledby, e o clique no
         rótulo é encaminhado explicitamente. -->
    <span class="bd-checkbox__label" [id]="labelId" (click)="toggle()">
      <ng-content />
    </span>
  `, host: { '[class.bd-checkbox--disabled]': 'disabled()' }, styles: [":host{display:inline-flex;align-items:flex-start;gap:var(--bd-space-3, .75rem)}.bd-checkbox__box{flex-shrink:0;display:grid;place-items:center;width:20px;height:20px;margin-top:.1rem;padding:0;background:var(--bd-bg, #fff);border:1.5px solid var(--bd-border-strong, #cbd2e2);border-radius:.35rem;cursor:pointer;transition:background var(--bd-duration-fast, .15s) ease,border-color var(--bd-duration-fast, .15s) ease}.bd-checkbox__box[aria-checked=true],.bd-checkbox__box[aria-checked=mixed]{background:var(--bd-primary, #3d5ce8);border-color:var(--bd-primary, #3d5ce8)}.bd-checkbox__box:hover:not(:disabled){border-color:var(--bd-primary, #3d5ce8)}.bd-checkbox__box:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-checkbox__box:disabled{opacity:.5;cursor:not-allowed}.bd-checkbox__mark{color:var(--bd-primary-contrast, #fff);font-size:.72rem;font-weight:700;line-height:1;opacity:0;transform:scale(.6);transition:opacity var(--bd-duration-fast, .15s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease)}.bd-checkbox__box[aria-checked=true] .bd-checkbox__mark,.bd-checkbox__box[aria-checked=mixed] .bd-checkbox__mark{opacity:1;transform:none}.bd-checkbox__label{color:var(--bd-fg, #10131c);font-size:.93rem;line-height:1.5;cursor:pointer;-webkit-user-select:none;user-select:none}:host(.bd-checkbox--disabled) .bd-checkbox__label{opacity:.5;cursor:not-allowed}@media(prefers-reduced-motion:reduce){.bd-checkbox__box,.bd-checkbox__mark{transition:none}}\n"] }]
        }], propDecorators: { checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], indeterminate: [{ type: i0.Input, args: [{ isSignal: true, alias: "indeterminate", required: false }] }, { type: i0.Output, args: ["indeterminateChange"] }], disabledInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

let instanceCount$2 = 0;
/**
 * Interruptor liga/desliga.
 *
 * Use quando o efeito é imediato ("ativar notificações"). Para algo que só vale
 * ao enviar o formulário, prefira `<bd-checkbox>`.
 *
 * Implementa `ControlValueAccessor`, então funciona com `formControlName` e
 * `[(ngModel)]` — e também de forma avulsa com `[(checked)]`.
 *
 * @example
 * ```html
 * <bd-switch [(checked)]="notificacoes">Notificações por e-mail</bd-switch>
 * <bd-switch formControlName="ativo">Ativo</bd-switch>
 * ```
 */
class BdSwitchComponent {
    /** Two-way: `[(checked)]="ativo"`. */
    checked = model(false, ...(ngDevMode ? [{ debugName: "checked" }] : []));
    /** Desabilita via template: `<bd-switch disabled>`. */
    disabledInput = input(false, ...(ngDevMode ? [{ debugName: "disabledInput", alias: 'disabled', transform: booleanAttribute }] : [{ alias: 'disabled', transform: booleanAttribute }]));
    /** Escrito pelo Reactive Forms via setDisabledState. */
    disabledByForm = signal(false, ...(ngDevMode ? [{ debugName: "disabledByForm" }] : []));
    /** Vale isDisabled se veio do template OU do formulário. */
    disabled = computed(() => this.disabledInput() || this.disabledByForm(), ...(ngDevMode ? [{ debugName: "disabled" }] : []));
    uid = instanceCount$2++;
    id = `bd-switch-${this.uid}`;
    labelId = `bd-switch-label-${this.uid}`;
    onChangeFn = () => { };
    onTouchedFn = () => { };
    toggle() {
        if (this.disabled())
            return;
        const novo = !this.checked();
        this.checked.set(novo);
        this.onChangeFn(novo);
    }
    /* ---------------------------------------------- ControlValueAccessor --- */
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabledByForm.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSwitchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdSwitchComponent, isStandalone: true, selector: "bd-switch", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabledInput: { classPropertyName: "disabledInput", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "checkedChange" }, host: { properties: { "class.bd-switch--disabled": "disabled()" } }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: BdSwitchComponent, multi: true }], ngImport: i0, template: `
    <button
      type="button"
      role="switch"
      class="bd-switch__control"
      [id]="id"
      [attr.aria-checked]="checked()"
      [attr.aria-labelledby]="labelId"
      [disabled]="disabled()"
      (click)="toggle()"
      (blur)="onTouchedFn()"
    >
      <span class="bd-switch__thumb"></span>
    </button>

    <label class="bd-switch__label" [id]="labelId" [attr.for]="id">
      <ng-content />
    </label>
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;gap:var(--bd-space-3, .75rem)}.bd-switch__control{position:relative;flex-shrink:0;width:42px;height:24px;padding:0;background:var(--bd-border-strong, #cbd2e2);border:none;border-radius:var(--bd-radius-full, 9999px);cursor:pointer;transition:background var(--bd-duration, .25s) ease}.bd-switch__control[aria-checked=true]{background:var(--bd-primary, #3d5ce8)}.bd-switch__control:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-switch__control:disabled{opacity:.5;cursor:not-allowed}.bd-switch__thumb{position:absolute;top:3px;left:3px;width:18px;height:18px;background:#fff;border-radius:50%;box-shadow:0 1px 3px #00000040;transition:transform var(--bd-duration, .25s) var(--bd-ease, ease)}.bd-switch__control[aria-checked=true] .bd-switch__thumb{transform:translate(18px)}.bd-switch__label{color:var(--bd-fg, #10131c);font-size:.93rem;cursor:pointer;-webkit-user-select:none;user-select:none}:host(.bd-switch--disabled) .bd-switch__label{opacity:.5;cursor:not-allowed}@media(prefers-reduced-motion:reduce){.bd-switch__control,.bd-switch__thumb{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSwitchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-switch', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: BdSwitchComponent, multi: true }], template: `
    <button
      type="button"
      role="switch"
      class="bd-switch__control"
      [id]="id"
      [attr.aria-checked]="checked()"
      [attr.aria-labelledby]="labelId"
      [disabled]="disabled()"
      (click)="toggle()"
      (blur)="onTouchedFn()"
    >
      <span class="bd-switch__thumb"></span>
    </button>

    <label class="bd-switch__label" [id]="labelId" [attr.for]="id">
      <ng-content />
    </label>
  `, host: { '[class.bd-switch--disabled]': 'disabled()' }, styles: [":host{display:inline-flex;align-items:center;gap:var(--bd-space-3, .75rem)}.bd-switch__control{position:relative;flex-shrink:0;width:42px;height:24px;padding:0;background:var(--bd-border-strong, #cbd2e2);border:none;border-radius:var(--bd-radius-full, 9999px);cursor:pointer;transition:background var(--bd-duration, .25s) ease}.bd-switch__control[aria-checked=true]{background:var(--bd-primary, #3d5ce8)}.bd-switch__control:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-switch__control:disabled{opacity:.5;cursor:not-allowed}.bd-switch__thumb{position:absolute;top:3px;left:3px;width:18px;height:18px;background:#fff;border-radius:50%;box-shadow:0 1px 3px #00000040;transition:transform var(--bd-duration, .25s) var(--bd-ease, ease)}.bd-switch__control[aria-checked=true] .bd-switch__thumb{transform:translate(18px)}.bd-switch__label{color:var(--bd-fg, #10131c);font-size:.93rem;cursor:pointer;-webkit-user-select:none;user-select:none}:host(.bd-switch--disabled) .bd-switch__label{opacity:.5;cursor:not-allowed}@media(prefers-reduced-motion:reduce){.bd-switch__control,.bd-switch__thumb{transition:none}}\n"] }]
        }], propDecorators: { checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }, { type: i0.Output, args: ["checkedChange"] }], disabledInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

const ICONES = {
    info: 'ℹ',
    success: '✓',
    warning: '!',
    danger: '✕',
};
/**
 * Mensagem persistente na página — diferente do toast, que some sozinho.
 *
 * Erros e avisos recebem `role="alert"` (o leitor de tela interrompe e anuncia);
 * info e sucesso recebem `role="status"` (anuncia sem interromper).
 *
 * @example
 * ```html
 * <bd-alert tone="warning" title="Plano expirando">
 *   Sua assinatura vence em 3 dias.
 * </bd-alert>
 *
 * <bd-alert tone="danger" dismissible (dismissed)="esconder()">
 *   Não foi possível salvar.
 * </bd-alert>
 * ```
 */
class BdAlertComponent {
    tone = input('info', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    dismissible = input(false, ...(ngDevMode ? [{ debugName: "dismissible", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    closeLabel = input('Fechar aviso', ...(ngDevMode ? [{ debugName: "closeLabel" }] : []));
    dismissed = output();
    icone = computed(() => ICONES[this.tone()], ...(ngDevMode ? [{ debugName: "icone" }] : []));
    classes = computed(() => `bd-alert--${this.tone()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    /** Erro e aviso interrompem o leitor de tela; os demais só anunciam. */
    papel = computed(() => this.tone() === 'danger' || this.tone() === 'warning' ? 'alert' : 'status', ...(ngDevMode ? [{ debugName: "papel" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdAlertComponent, isStandalone: true, selector: "bd-alert", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null }, closeLabel: { classPropertyName: "closeLabel", publicName: "closeLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismissed: "dismissed" }, host: { properties: { "class": "classes()", "attr.role": "papel()" } }, ngImport: i0, template: `
    <span class="bd-alert__icon" aria-hidden="true">{{ icone() }}</span>

    <div class="bd-alert__body">
      @if (title()) {
        <strong class="bd-alert__title">{{ title() }}</strong>
      }
      <div class="bd-alert__content"><ng-content /></div>
    </div>

    @if (dismissible()) {
      <button
        type="button"
        class="bd-alert__close"
        [attr.aria-label]="closeLabel()"
        (click)="dismissed.emit()"
      >
        &times;
      </button>
    }
  `, isInline: true, styles: [":host{display:flex;align-items:flex-start;gap:var(--bd-space-3, .75rem);padding:var(--bd-space-4, 1rem);border:1px solid transparent;border-radius:var(--bd-radius, .875rem);font-size:.92rem;line-height:1.6}.bd-alert__icon{display:grid;place-items:center;flex-shrink:0;width:22px;height:22px;border-radius:50%;background:currentColor;font-size:.72rem;font-weight:700}.bd-alert__icon:first-letter{color:var(--bd-bg, #fff)}.bd-alert__body{flex:1;min-width:0}.bd-alert__title{display:block;margin-bottom:.15rem;font-weight:var(--bd-weight-semibold, 600)}.bd-alert__content{color:var(--bd-fg-muted, #545c70)}.bd-alert__close{flex-shrink:0;display:grid;place-items:center;width:26px;height:26px;margin:-.15rem -.15rem 0 0;background:transparent;border:none;border-radius:50%;color:inherit;font-size:1.25rem;line-height:1;cursor:pointer;opacity:.65;transition:opacity .2s ease,background .2s ease}.bd-alert__close:hover{opacity:1;background:#00000014}.bd-alert__close:focus-visible{outline:none;opacity:1;box-shadow:0 0 0 2px currentColor}:host(.bd-alert--info){background:var(--bd-info-soft, rgba(2, 132, 199, .1));border-color:color-mix(in srgb,var(--bd-info, #0284c7) 30%,transparent);color:var(--bd-info, #0284c7)}:host(.bd-alert--success){background:var(--bd-success-soft, rgba(22, 163, 74, .1));border-color:color-mix(in srgb,var(--bd-success, #16a34a) 30%,transparent);color:var(--bd-success, #16a34a)}:host(.bd-alert--warning){background:var(--bd-warning-soft, rgba(217, 119, 6, .1));border-color:color-mix(in srgb,var(--bd-warning, #d97706) 30%,transparent);color:var(--bd-warning, #d97706)}:host(.bd-alert--danger){background:var(--bd-danger-soft, rgba(220, 38, 38, .1));border-color:color-mix(in srgb,var(--bd-danger, #dc2626) 30%,transparent);color:var(--bd-danger, #dc2626)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-alert', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="bd-alert__icon" aria-hidden="true">{{ icone() }}</span>

    <div class="bd-alert__body">
      @if (title()) {
        <strong class="bd-alert__title">{{ title() }}</strong>
      }
      <div class="bd-alert__content"><ng-content /></div>
    </div>

    @if (dismissible()) {
      <button
        type="button"
        class="bd-alert__close"
        [attr.aria-label]="closeLabel()"
        (click)="dismissed.emit()"
      >
        &times;
      </button>
    }
  `, host: {
                        '[class]': 'classes()',
                        '[attr.role]': 'papel()',
                    }, styles: [":host{display:flex;align-items:flex-start;gap:var(--bd-space-3, .75rem);padding:var(--bd-space-4, 1rem);border:1px solid transparent;border-radius:var(--bd-radius, .875rem);font-size:.92rem;line-height:1.6}.bd-alert__icon{display:grid;place-items:center;flex-shrink:0;width:22px;height:22px;border-radius:50%;background:currentColor;font-size:.72rem;font-weight:700}.bd-alert__icon:first-letter{color:var(--bd-bg, #fff)}.bd-alert__body{flex:1;min-width:0}.bd-alert__title{display:block;margin-bottom:.15rem;font-weight:var(--bd-weight-semibold, 600)}.bd-alert__content{color:var(--bd-fg-muted, #545c70)}.bd-alert__close{flex-shrink:0;display:grid;place-items:center;width:26px;height:26px;margin:-.15rem -.15rem 0 0;background:transparent;border:none;border-radius:50%;color:inherit;font-size:1.25rem;line-height:1;cursor:pointer;opacity:.65;transition:opacity .2s ease,background .2s ease}.bd-alert__close:hover{opacity:1;background:#00000014}.bd-alert__close:focus-visible{outline:none;opacity:1;box-shadow:0 0 0 2px currentColor}:host(.bd-alert--info){background:var(--bd-info-soft, rgba(2, 132, 199, .1));border-color:color-mix(in srgb,var(--bd-info, #0284c7) 30%,transparent);color:var(--bd-info, #0284c7)}:host(.bd-alert--success){background:var(--bd-success-soft, rgba(22, 163, 74, .1));border-color:color-mix(in srgb,var(--bd-success, #16a34a) 30%,transparent);color:var(--bd-success, #16a34a)}:host(.bd-alert--warning){background:var(--bd-warning-soft, rgba(217, 119, 6, .1));border-color:color-mix(in srgb,var(--bd-warning, #d97706) 30%,transparent);color:var(--bd-warning, #d97706)}:host(.bd-alert--danger){background:var(--bd-danger-soft, rgba(220, 38, 38, .1));border-color:color-mix(in srgb,var(--bd-danger, #dc2626) 30%,transparent);color:var(--bd-danger, #dc2626)}\n"] }]
        }], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], closeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeLabel", required: false }] }], dismissed: [{ type: i0.Output, args: ["dismissed"] }] } });

/**
 * Barra de progresso determinada.
 *
 * Expõe `role="progressbar"` com os valores ARIA corretos, então leitores de
 * tela anunciam a porcentagem. Para carregamento sem fim conhecido, use
 * `<bd-spinner>` — uma barra que não avança confunde mais do que informa.
 *
 * @example
 * ```html
 * <bd-progress [value]="65" />
 * <bd-progress [value]="3" [max]="5" tone="success" showValue label="Etapas" />
 * ```
 */
class BdProgressComponent {
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : []));
    max = input(100, ...(ngDevMode ? [{ debugName: "max" }] : []));
    tone = input('primary', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Mostra a porcentagem ao lado do rótulo. */
    showValue = input(false, ...(ngDevMode ? [{ debugName: "showValue", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    classes = computed(() => `bd-progress--${this.tone()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    percentual = computed(() => {
        const max = this.max() || 1;
        return Math.min(100, Math.max(0, Math.round((this.value() / max) * 100)));
    }, ...(ngDevMode ? [{ debugName: "percentual" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdProgressComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdProgressComponent, isStandalone: true, selector: "bd-progress", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, showValue: { classPropertyName: "showValue", publicName: "showValue", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    @if (label() || showValue()) {
      <div class="bd-progress__head">
        <span class="bd-progress__label">{{ label() }}</span>
        @if (showValue()) {
          <span class="bd-progress__value">{{ percentual() }}%</span>
        }
      </div>
    }

    <div
      class="bd-progress__track"
      role="progressbar"
      [attr.aria-valuenow]="value()"
      [attr.aria-valuemin]="0"
      [attr.aria-valuemax]="max()"
      [attr.aria-label]="label() || 'Progresso'"
    >
      <div class="bd-progress__bar" [style.width.%]="percentual()"></div>
    </div>
  `, isInline: true, styles: [":host{display:block}.bd-progress__head{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;margin-bottom:.4rem}.bd-progress__label{color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-medium, 500)}.bd-progress__value{color:var(--bd-fg-subtle, #7b8399);font-family:var(--bd-font-mono);font-size:var(--bd-text-xs, .75rem);font-variant-numeric:tabular-nums}.bd-progress__track{height:8px;background:var(--bd-surface-hover, #f1f3f9);border-radius:var(--bd-radius-full, 9999px);overflow:hidden}.bd-progress__bar{height:100%;border-radius:inherit;transition:width .4s var(--bd-ease, ease)}:host(.bd-progress--primary) .bd-progress__bar{background:var(--bd-primary, #3d5ce8)}:host(.bd-progress--accent) .bd-progress__bar{background:var(--bd-accent, #0d9488)}:host(.bd-progress--success) .bd-progress__bar{background:var(--bd-success, #16a34a)}:host(.bd-progress--warning) .bd-progress__bar{background:var(--bd-warning, #d97706)}:host(.bd-progress--danger) .bd-progress__bar{background:var(--bd-danger, #dc2626)}@media(prefers-reduced-motion:reduce){.bd-progress__bar{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdProgressComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-progress', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (label() || showValue()) {
      <div class="bd-progress__head">
        <span class="bd-progress__label">{{ label() }}</span>
        @if (showValue()) {
          <span class="bd-progress__value">{{ percentual() }}%</span>
        }
      </div>
    }

    <div
      class="bd-progress__track"
      role="progressbar"
      [attr.aria-valuenow]="value()"
      [attr.aria-valuemin]="0"
      [attr.aria-valuemax]="max()"
      [attr.aria-label]="label() || 'Progresso'"
    >
      <div class="bd-progress__bar" [style.width.%]="percentual()"></div>
    </div>
  `, host: { '[class]': 'classes()' }, styles: [":host{display:block}.bd-progress__head{display:flex;align-items:baseline;justify-content:space-between;gap:1rem;margin-bottom:.4rem}.bd-progress__label{color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-medium, 500)}.bd-progress__value{color:var(--bd-fg-subtle, #7b8399);font-family:var(--bd-font-mono);font-size:var(--bd-text-xs, .75rem);font-variant-numeric:tabular-nums}.bd-progress__track{height:8px;background:var(--bd-surface-hover, #f1f3f9);border-radius:var(--bd-radius-full, 9999px);overflow:hidden}.bd-progress__bar{height:100%;border-radius:inherit;transition:width .4s var(--bd-ease, ease)}:host(.bd-progress--primary) .bd-progress__bar{background:var(--bd-primary, #3d5ce8)}:host(.bd-progress--accent) .bd-progress__bar{background:var(--bd-accent, #0d9488)}:host(.bd-progress--success) .bd-progress__bar{background:var(--bd-success, #16a34a)}:host(.bd-progress--warning) .bd-progress__bar{background:var(--bd-warning, #d97706)}:host(.bd-progress--danger) .bd-progress__bar{background:var(--bd-danger, #dc2626)}@media(prefers-reduced-motion:reduce){.bd-progress__bar{transition:none}}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], showValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "showValue", required: false }] }] } });

/**
 * Placeholder do conteúdo enquanto ele carrega.
 *
 * Prefira skeleton a spinner quando você já sabe o formato do que vai chegar:
 * a página não "salta" na troca e a espera parece mais curta.
 *
 * É invisível para leitores de tela (`aria-hidden`) — anuncie o carregamento
 * no container, com `aria-busy`.
 *
 * @example
 * ```html
 * <bd-skeleton variant="title" />
 * <bd-skeleton variant="text" width="80%" />
 * <bd-skeleton variant="circle" width="48px" height="48px" />
 * ```
 */
class BdSkeletonComponent {
    variant = input('text', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    /** Sobrescreve a largura padrão da variante. */
    width = input('', ...(ngDevMode ? [{ debugName: "width" }] : []));
    /** Sobrescreve a altura padrão da variante. */
    height = input('', ...(ngDevMode ? [{ debugName: "height" }] : []));
    classes = computed(() => `bd-skeleton--${this.variant()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdSkeletonComponent, isStandalone: true, selector: "bd-skeleton", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "aria-hidden": "true" }, properties: { "class": "classes()", "style.width": "width() || null", "style.height": "height() || null" } }, ngImport: i0, template: '', isInline: true, styles: [":host{display:block;background:linear-gradient(90deg,var(--bd-surface-hover, #f1f3f9) 25%,var(--bd-border, #e3e7f0) 37%,var(--bd-surface-hover, #f1f3f9) 63%);background-size:400% 100%;border-radius:var(--bd-radius-sm, .5rem);animation:bd-shimmer 1.4s ease infinite}:host(.bd-skeleton--text){height:.85rem;margin-block:.25rem}:host(.bd-skeleton--title){height:1.5rem;width:55%;margin-block:.4rem}:host(.bd-skeleton--circle){width:42px;height:42px;border-radius:50%}:host(.bd-skeleton--rect){height:120px;border-radius:var(--bd-radius, .875rem)}@keyframes bd-shimmer{0%{background-position:100% 50%}to{background-position:0 50%}}@media(prefers-reduced-motion:reduce){:host{animation:none;background:var(--bd-surface-hover, #f1f3f9)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-skeleton', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: '', host: {
                        '[class]': 'classes()',
                        '[style.width]': 'width() || null',
                        '[style.height]': 'height() || null',
                        'aria-hidden': 'true',
                    }, styles: [":host{display:block;background:linear-gradient(90deg,var(--bd-surface-hover, #f1f3f9) 25%,var(--bd-border, #e3e7f0) 37%,var(--bd-surface-hover, #f1f3f9) 63%);background-size:400% 100%;border-radius:var(--bd-radius-sm, .5rem);animation:bd-shimmer 1.4s ease infinite}:host(.bd-skeleton--text){height:.85rem;margin-block:.25rem}:host(.bd-skeleton--title){height:1.5rem;width:55%;margin-block:.4rem}:host(.bd-skeleton--circle){width:42px;height:42px;border-radius:50%}:host(.bd-skeleton--rect){height:120px;border-radius:var(--bd-radius, .875rem)}@keyframes bd-shimmer{0%{background-position:100% 50%}to{background-position:0 50%}}@media(prefers-reduced-motion:reduce){:host{animation:none;background:var(--bd-surface-hover, #f1f3f9)}}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });

/**
 * Indicador de carregamento indeterminado.
 *
 * Traz o rótulo para leitores de tela por padrão — um spinner mudo deixa quem
 * não enxerga sem saber que algo está acontecendo.
 *
 * @example
 * ```html
 * <bd-spinner />
 * <bd-spinner size="lg" label="Carregando projetos" />
 * ```
 */
class BdSpinnerComponent {
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : []));
    /** Texto anunciado por leitores de tela. */
    label = input('Carregando', ...(ngDevMode ? [{ debugName: "label" }] : []));
    classes = computed(() => `bd-spinner--${this.size()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdSpinnerComponent, isStandalone: true, selector: "bd-spinner", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status" }, properties: { "class": "classes()", "attr.aria-live": "\"polite\"" } }, ngImport: i0, template: `
    <span class="bd-spinner__ring" aria-hidden="true"></span>
    <span class="bd-sr-only">{{ label() }}</span>
  `, isInline: true, styles: [":host{display:inline-grid;place-items:center}.bd-spinner__ring{display:block;border-style:solid;border-color:currentColor;border-right-color:transparent;border-radius:50%;color:var(--bd-primary, #3d5ce8);animation:bd-spin .7s linear infinite}:host(.bd-spinner--sm) .bd-spinner__ring{width:16px;height:16px;border-width:2px}:host(.bd-spinner--md) .bd-spinner__ring{width:26px;height:26px;border-width:3px}:host(.bd-spinner--lg) .bd-spinner__ring{width:42px;height:42px;border-width:4px}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@keyframes bd-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.bd-spinner__ring{animation-duration:1.8s}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-spinner', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span class="bd-spinner__ring" aria-hidden="true"></span>
    <span class="bd-sr-only">{{ label() }}</span>
  `, host: {
                        '[class]': 'classes()',
                        role: 'status',
                        '[attr.aria-live]': '"polite"',
                    }, styles: [":host{display:inline-grid;place-items:center}.bd-spinner__ring{display:block;border-style:solid;border-color:currentColor;border-right-color:transparent;border-radius:50%;color:var(--bd-primary, #3d5ce8);animation:bd-spin .7s linear infinite}:host(.bd-spinner--sm) .bd-spinner__ring{width:16px;height:16px;border-width:2px}:host(.bd-spinner--md) .bd-spinner__ring{width:26px;height:26px;border-width:3px}:host(.bd-spinner--lg) .bd-spinner__ring{width:42px;height:42px;border-width:4px}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@keyframes bd-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.bd-spinner__ring{animation-duration:1.8s}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Pilha das camadas sobrepostas abertas (diálogos, tour, gavetas).
 *
 * Existe para que atalhos globais atinjam apenas a camada do topo: com dois
 * diálogos empilhados, `Esc` fecha o de cima e mantém o de baixo. Sem essa
 * arbitragem, cada instância reagiria ao mesmo evento de teclado.
 */
class BdOverlayStackService {
    stack = [];
    push(reference) {
        this.remove(reference);
        this.stack.push(reference);
    }
    remove(reference) {
        const index = this.stack.indexOf(reference);
        if (index > -1) {
            this.stack.splice(index, 1);
        }
    }
    /** `true` quando a referência é a camada mais alta da pilha. */
    isTopmost(reference) {
        return this.stack.length > 0 && this.stack[this.stack.length - 1] === reference;
    }
    get depth() {
        return this.stack.length;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdOverlayStackService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdOverlayStackService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdOverlayStackService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Trava a rolagem do documento enquanto houver camadas sobrepostas abertas.
 *
 * O controle é por contagem de referências: dois diálogos empilhados produzem
 * duas travas, e a rolagem só volta quando a última é liberada. O valor
 * original de `overflow` é preservado e restaurado — a biblioteca não descarta
 * estilos definidos pela aplicação hospedeira.
 *
 * A largura da barra de rolagem é compensada com `padding-right` para que o
 * conteúdo não salte lateralmente ao abrir a camada.
 */
class BdScrollLockService {
    document = inject(DOCUMENT);
    references = 0;
    previousOverflow = '';
    previousPaddingRight = '';
    /** Número de travas ativas. Exposto para diagnóstico e testes. */
    get active() {
        return this.references;
    }
    lock() {
        if (this.references++ > 0)
            return;
        const body = this.document.body;
        const view = this.document.defaultView;
        if (!body || !view)
            return;
        this.previousOverflow = body.style.overflow;
        this.previousPaddingRight = body.style.paddingRight;
        const scrollbar = view.innerWidth - this.document.documentElement.clientWidth;
        if (scrollbar > 0) {
            const current = parseFloat(view.getComputedStyle(body).paddingRight) || 0;
            body.style.paddingRight = `${current + scrollbar}px`;
        }
        body.style.overflow = 'hidden';
    }
    release() {
        if (this.references === 0)
            return;
        if (--this.references > 0)
            return;
        const body = this.document.body;
        if (!body)
            return;
        body.style.overflow = this.previousOverflow;
        body.style.paddingRight = this.previousPaddingRight;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdScrollLockService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdScrollLockService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdScrollLockService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

let instanceCount$1 = 0;
/**
 * Diálogo modal acessível.
 *
 * Confina o foco (`cdkTrapFocus`), encerra com `Esc` ou clique no fundo, trava
 * a rolagem da página e devolve o foco ao elemento que o abriu. Abaixo de
 * 600px assume o formato de bottom sheet, ao alcance do polegar.
 *
 * Diálogos empilhados são coordenados: a trava de rolagem é contada por
 * referência e `Esc` encerra apenas o diálogo do topo da pilha.
 *
 * @example
 * ```html
 * <bd-modal [(open)]="confirmacaoAberta" title="Excluir projeto">
 *   <p>Esta ação não pode ser desfeita.</p>
 * </bd-modal>
 * ```
 */
class BdModalComponent {
    /** Two-way: `[(open)]="mostrar"`. */
    open = model(false, ...(ngDevMode ? [{ debugName: "open" }] : []));
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : []));
    /** Rótulo acessível quando o diálogo não tem título visível. */
    ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
    /** Quando `false`, esconde o X e ignora `Esc` e clique no fundo. */
    dismissible = input(true, ...(ngDevMode ? [{ debugName: "dismissible", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    closeLabel = input('Fechar', ...(ngDevMode ? [{ debugName: "closeLabel" }] : []));
    titleId = `bd-modal-title-${instanceCount$1++}`;
    document = inject(DOCUMENT);
    scrollLock = inject(BdScrollLockService);
    overlayStack = inject(BdOverlayStackService);
    focusOrigin = null;
    locked = false;
    constructor() {
        // O efeito reage apenas às transições reais de estado: um diálogo fechado
        // nunca toca no documento, e cada `lock()` tem exatamente um `release()`.
        effect(() => (this.open() ? this.onOpen() : this.onClose()));
        inject(DestroyRef).onDestroy(() => this.onClose());
    }
    onEscape() {
        // Com diálogos empilhados, apenas o do topo responde ao atalho.
        if (this.open() && this.dismissible() && this.overlayStack.isTopmost(this)) {
            this.open.set(false);
        }
    }
    close() {
        if (this.dismissible()) {
            this.open.set(false);
        }
    }
    onOpen() {
        if (this.locked)
            return;
        this.locked = true;
        this.focusOrigin = this.document.activeElement;
        this.overlayStack.push(this);
        this.scrollLock.lock();
    }
    onClose() {
        if (!this.locked)
            return;
        this.locked = false;
        this.overlayStack.remove(this);
        this.scrollLock.release();
        // `cdkTrapFocus` restaura o foco na interação; a devolução explícita cobre
        // o fechamento por código, quando não houve interação a restaurar.
        this.focusOrigin?.focus();
        this.focusOrigin = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdModalComponent, isStandalone: true, selector: "bd-modal", inputs: { open: { classPropertyName: "open", publicName: "open", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null }, closeLabel: { classPropertyName: "closeLabel", publicName: "closeLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "openChange" }, host: { listeners: { "document:keydown.escape": "onEscape()" } }, ngImport: i0, template: `
    @if (open()) {
      <div class="bd-modal__overlay" (click)="close()">
        <div
          class="bd-modal__panel"
          role="dialog"
          aria-modal="true"
          [attr.aria-labelledby]="title() ? titleId : null"
          [attr.aria-label]="title() ? null : ariaLabel()"
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          (click)="$event.stopPropagation()"
        >
          @if (dismissible()) {
            <button
              type="button"
              class="bd-modal__close"
              [attr.aria-label]="closeLabel()"
              (click)="close()"
            >
              &times;
            </button>
          }

          @if (title()) {
            <h2 class="bd-modal__title" [id]="titleId">{{ title() }}</h2>
          }

          <ng-content />
        </div>
      </div>
    }
  `, isInline: true, styles: [".bd-modal__overlay{position:fixed;inset:0;z-index:var(--bd-z-modal, 200);display:flex;align-items:center;justify-content:center;padding:var(--bd-space-4, 1rem);background:#03050ab8;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);animation:bd-overlay-in .22s ease}@keyframes bd-overlay-in{0%{opacity:0}to{opacity:1}}.bd-modal__panel{position:relative;width:100%;max-width:480px;max-height:90vh;overflow-y:auto;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem) var(--bd-space-5, 1.5rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .12));color:var(--bd-fg, #10131c);animation:bd-panel-in .28s var(--bd-ease, cubic-bezier(.16, 1, .3, 1))}@keyframes bd-panel-in{0%{opacity:0;transform:translateY(24px) scale(.97)}to{opacity:1;transform:none}}.bd-modal__panel:focus{outline:none}.bd-modal__title{margin:0 0 var(--bd-space-4, 1rem);font-size:var(--bd-text-2xl, 1.75rem);font-weight:var(--bd-weight-bold, 700)}.bd-modal__close{position:absolute;top:var(--bd-space-3, .75rem);right:var(--bd-space-3, .75rem);display:flex;align-items:center;justify-content:center;width:38px;height:38px;background:var(--bd-surface-hover, #f1f3f9);border:1px solid var(--bd-border, #e3e7f0);border-radius:50%;color:var(--bd-fg-muted, #545c70);font-size:1.5rem;line-height:1;cursor:pointer;transition:color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease}.bd-modal__close:hover{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-modal__close:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}@media(prefers-reduced-motion:reduce){.bd-modal__overlay,.bd-modal__panel{animation:none}}@media(max-width:600px){.bd-modal__overlay{align-items:flex-end;padding:0}.bd-modal__panel{max-width:100%;max-height:88vh;border-radius:var(--bd-radius-lg, 1.25rem) var(--bd-radius-lg, 1.25rem) 0 0}}\n"], dependencies: [{ kind: "ngmodule", type: A11yModule }, { kind: "directive", type: i1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-modal', standalone: true, imports: [A11yModule], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (open()) {
      <div class="bd-modal__overlay" (click)="close()">
        <div
          class="bd-modal__panel"
          role="dialog"
          aria-modal="true"
          [attr.aria-labelledby]="title() ? titleId : null"
          [attr.aria-label]="title() ? null : ariaLabel()"
          cdkTrapFocus
          [cdkTrapFocusAutoCapture]="true"
          (click)="$event.stopPropagation()"
        >
          @if (dismissible()) {
            <button
              type="button"
              class="bd-modal__close"
              [attr.aria-label]="closeLabel()"
              (click)="close()"
            >
              &times;
            </button>
          }

          @if (title()) {
            <h2 class="bd-modal__title" [id]="titleId">{{ title() }}</h2>
          }

          <ng-content />
        </div>
      </div>
    }
  `, styles: [".bd-modal__overlay{position:fixed;inset:0;z-index:var(--bd-z-modal, 200);display:flex;align-items:center;justify-content:center;padding:var(--bd-space-4, 1rem);background:#03050ab8;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px);animation:bd-overlay-in .22s ease}@keyframes bd-overlay-in{0%{opacity:0}to{opacity:1}}.bd-modal__panel{position:relative;width:100%;max-width:480px;max-height:90vh;overflow-y:auto;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem) var(--bd-space-5, 1.5rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .12));color:var(--bd-fg, #10131c);animation:bd-panel-in .28s var(--bd-ease, cubic-bezier(.16, 1, .3, 1))}@keyframes bd-panel-in{0%{opacity:0;transform:translateY(24px) scale(.97)}to{opacity:1;transform:none}}.bd-modal__panel:focus{outline:none}.bd-modal__title{margin:0 0 var(--bd-space-4, 1rem);font-size:var(--bd-text-2xl, 1.75rem);font-weight:var(--bd-weight-bold, 700)}.bd-modal__close{position:absolute;top:var(--bd-space-3, .75rem);right:var(--bd-space-3, .75rem);display:flex;align-items:center;justify-content:center;width:38px;height:38px;background:var(--bd-surface-hover, #f1f3f9);border:1px solid var(--bd-border, #e3e7f0);border-radius:50%;color:var(--bd-fg-muted, #545c70);font-size:1.5rem;line-height:1;cursor:pointer;transition:color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease}.bd-modal__close:hover{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-modal__close:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}@media(prefers-reduced-motion:reduce){.bd-modal__overlay,.bd-modal__panel{animation:none}}@media(max-width:600px){.bd-modal__overlay{align-items:flex-end;padding:0}.bd-modal__panel{max-width:100%;max-height:88vh;border-radius:var(--bd-radius-lg, 1.25rem) var(--bd-radius-lg, 1.25rem) 0 0}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { open: [{ type: i0.Input, args: [{ isSignal: true, alias: "open", required: false }] }, { type: i0.Output, args: ["openChange"] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], closeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeLabel", required: false }] }], onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }] } });

/**
 * Estrutura de aplicação: cabeçalho fixo, barra lateral e área de conteúdo.
 *
 * No desktop a lateral fica fixa; abaixo de 900px ela vira gaveta sobreposta,
 * com fundo escuro clicável para fechar. O `<main>` é marcado como
 * `id="conteudo"`, alvo do link "pular para o conteúdo".
 *
 * @example
 * ```html
 * <bd-app-shell [(sidebarOpen)]="menuAberto">
 *   <a bdAppShellBrand href="/">Minha Empresa</a>
 *   <nav bdAppShellNav>…</nav>
 *   <button bdAppShellActions bdButton size="sm">Novo</button>
 *
 *   <router-outlet />
 * </bd-app-shell>
 * ```
 */
class BdAppShellComponent {
    /** Two-way: `[(sidebarOpen)]="menuAberto"`. Só afeta o mobile. */
    sidebarOpen = model(false, ...(ngDevMode ? [{ debugName: "sidebarOpen" }] : []));
    /** Esconde o botão de menu — útil quando não há navegação lateral. */
    hideToggle = input(false, ...(ngDevMode ? [{ debugName: "hideToggle", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    skipLabel = input('Pular para o conteúdo', ...(ngDevMode ? [{ debugName: "skipLabel" }] : []));
    openMenuLabel = input('Abrir menu', ...(ngDevMode ? [{ debugName: "openMenuLabel" }] : []));
    closeMenuLabel = input('Fechar menu', ...(ngDevMode ? [{ debugName: "closeMenuLabel" }] : []));
    navLabel = input('Navegação principal', ...(ngDevMode ? [{ debugName: "navLabel" }] : []));
    toggle() {
        this.sidebarOpen.update((v) => !v);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAppShellComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdAppShellComponent, isStandalone: true, selector: "bd-app-shell", inputs: { sidebarOpen: { classPropertyName: "sidebarOpen", publicName: "sidebarOpen", isSignal: true, isRequired: false, transformFunction: null }, hideToggle: { classPropertyName: "hideToggle", publicName: "hideToggle", isSignal: true, isRequired: false, transformFunction: null }, skipLabel: { classPropertyName: "skipLabel", publicName: "skipLabel", isSignal: true, isRequired: false, transformFunction: null }, openMenuLabel: { classPropertyName: "openMenuLabel", publicName: "openMenuLabel", isSignal: true, isRequired: false, transformFunction: null }, closeMenuLabel: { classPropertyName: "closeMenuLabel", publicName: "closeMenuLabel", isSignal: true, isRequired: false, transformFunction: null }, navLabel: { classPropertyName: "navLabel", publicName: "navLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sidebarOpen: "sidebarOpenChange" }, ngImport: i0, template: `
    <a class="bd-shell__skip" href="#conteudo">{{ skipLabel() }}</a>

    <header class="bd-shell__header">
      <div class="bd-shell__header-left">
        <button
          type="button"
          class="bd-shell__toggle"
          [attr.aria-expanded]="sidebarOpen()"
          aria-controls="bd-shell-sidebar"
          [attr.aria-label]="sidebarOpen() ? closeMenuLabel() : openMenuLabel()"
          (click)="toggle()"
        >
          {{ sidebarOpen() ? '✕' : '☰' }}
        </button>

        <div class="bd-shell__brand">
          <ng-content select="[bdAppShellBrand]" />
        </div>
      </div>

      <div class="bd-shell__actions">
        <ng-content select="[bdAppShellActions]" />
      </div>
    </header>

    <div class="bd-shell__body">
      <aside
        id="bd-shell-sidebar"
        class="bd-shell__sidebar"
        [class.is-open]="sidebarOpen()"
        [attr.aria-label]="navLabel()"
      >
        <ng-content select="[bdAppShellNav]" />
      </aside>

      <!-- Fundo clicável só existe quando a gaveta está aberta no mobile. -->
      @if (sidebarOpen()) {
        <div class="bd-shell__scrim" (click)="sidebarOpen.set(false)"></div>
      }

      <main id="conteudo" class="bd-shell__main">
        <ng-content />
      </main>
    </div>
  `, isInline: true, styles: [":host{display:block;min-height:100vh;background:var(--bd-bg, #fff);color:var(--bd-fg, #10131c);--bd-shell-header-h: 60px;--bd-shell-sidebar-w: 248px}.bd-shell__skip{position:absolute;left:-9999px;z-index:100;padding:.75rem 1.25rem;background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff);text-decoration:none}.bd-shell__skip:focus{left:0}.bd-shell__header{position:sticky;top:0;z-index:40;display:flex;align-items:center;justify-content:space-between;gap:var(--bd-space-4, 1rem);height:var(--bd-shell-header-h);padding-inline:var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-shell__header-left{display:flex;align-items:center;gap:var(--bd-space-3, .75rem);min-width:0}.bd-shell__brand{font-weight:var(--bd-weight-bold, 700);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bd-shell__actions{display:flex;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-shell__toggle{display:none;place-items:center;width:38px;height:38px;background:transparent;border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:1rem;cursor:pointer}.bd-shell__toggle:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-shell__body{display:grid;grid-template-columns:var(--bd-shell-sidebar-w) minmax(0,1fr);align-items:start}.bd-shell__sidebar{position:sticky;top:var(--bd-shell-header-h);height:calc(100vh - var(--bd-shell-header-h));overflow-y:auto;padding:var(--bd-space-5, 1.5rem) var(--bd-space-3, .75rem);background:var(--bd-bg-elevated, #f8fafc);border-right:1px solid var(--bd-border, #e3e7f0)}.bd-shell__main{min-width:0;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem) var(--bd-space-7, 3rem)}.bd-shell__scrim{display:none}@media(max-width:900px){.bd-shell__toggle{display:grid}.bd-shell__body{grid-template-columns:minmax(0,1fr)}.bd-shell__sidebar{position:fixed;top:var(--bd-shell-header-h);left:0;bottom:0;z-index:45;width:var(--bd-shell-sidebar-w);height:auto;transform:translate(-100%);transition:transform var(--bd-duration, .25s) var(--bd-ease, ease);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(0, 0, 0, .2))}.bd-shell__sidebar.is-open{transform:none}.bd-shell__scrim{display:block;position:fixed;inset:var(--bd-shell-header-h) 0 0 0;z-index:44;background:#03050a80}.bd-shell__main{padding-inline:var(--bd-space-4, 1rem)}}@media(prefers-reduced-motion:reduce){.bd-shell__sidebar{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAppShellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-app-shell', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <a class="bd-shell__skip" href="#conteudo">{{ skipLabel() }}</a>

    <header class="bd-shell__header">
      <div class="bd-shell__header-left">
        <button
          type="button"
          class="bd-shell__toggle"
          [attr.aria-expanded]="sidebarOpen()"
          aria-controls="bd-shell-sidebar"
          [attr.aria-label]="sidebarOpen() ? closeMenuLabel() : openMenuLabel()"
          (click)="toggle()"
        >
          {{ sidebarOpen() ? '✕' : '☰' }}
        </button>

        <div class="bd-shell__brand">
          <ng-content select="[bdAppShellBrand]" />
        </div>
      </div>

      <div class="bd-shell__actions">
        <ng-content select="[bdAppShellActions]" />
      </div>
    </header>

    <div class="bd-shell__body">
      <aside
        id="bd-shell-sidebar"
        class="bd-shell__sidebar"
        [class.is-open]="sidebarOpen()"
        [attr.aria-label]="navLabel()"
      >
        <ng-content select="[bdAppShellNav]" />
      </aside>

      <!-- Fundo clicável só existe quando a gaveta está aberta no mobile. -->
      @if (sidebarOpen()) {
        <div class="bd-shell__scrim" (click)="sidebarOpen.set(false)"></div>
      }

      <main id="conteudo" class="bd-shell__main">
        <ng-content />
      </main>
    </div>
  `, styles: [":host{display:block;min-height:100vh;background:var(--bd-bg, #fff);color:var(--bd-fg, #10131c);--bd-shell-header-h: 60px;--bd-shell-sidebar-w: 248px}.bd-shell__skip{position:absolute;left:-9999px;z-index:100;padding:.75rem 1.25rem;background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff);text-decoration:none}.bd-shell__skip:focus{left:0}.bd-shell__header{position:sticky;top:0;z-index:40;display:flex;align-items:center;justify-content:space-between;gap:var(--bd-space-4, 1rem);height:var(--bd-shell-header-h);padding-inline:var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-shell__header-left{display:flex;align-items:center;gap:var(--bd-space-3, .75rem);min-width:0}.bd-shell__brand{font-weight:var(--bd-weight-bold, 700);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bd-shell__actions{display:flex;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-shell__toggle{display:none;place-items:center;width:38px;height:38px;background:transparent;border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:1rem;cursor:pointer}.bd-shell__toggle:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-shell__body{display:grid;grid-template-columns:var(--bd-shell-sidebar-w) minmax(0,1fr);align-items:start}.bd-shell__sidebar{position:sticky;top:var(--bd-shell-header-h);height:calc(100vh - var(--bd-shell-header-h));overflow-y:auto;padding:var(--bd-space-5, 1.5rem) var(--bd-space-3, .75rem);background:var(--bd-bg-elevated, #f8fafc);border-right:1px solid var(--bd-border, #e3e7f0)}.bd-shell__main{min-width:0;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem) var(--bd-space-7, 3rem)}.bd-shell__scrim{display:none}@media(max-width:900px){.bd-shell__toggle{display:grid}.bd-shell__body{grid-template-columns:minmax(0,1fr)}.bd-shell__sidebar{position:fixed;top:var(--bd-shell-header-h);left:0;bottom:0;z-index:45;width:var(--bd-shell-sidebar-w);height:auto;transform:translate(-100%);transition:transform var(--bd-duration, .25s) var(--bd-ease, ease);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(0, 0, 0, .2))}.bd-shell__sidebar.is-open{transform:none}.bd-shell__scrim{display:block;position:fixed;inset:var(--bd-shell-header-h) 0 0 0;z-index:44;background:#03050a80}.bd-shell__main{padding-inline:var(--bd-space-4, 1rem)}}@media(prefers-reduced-motion:reduce){.bd-shell__sidebar{transition:none}}\n"] }]
        }], propDecorators: { sidebarOpen: [{ type: i0.Input, args: [{ isSignal: true, alias: "sidebarOpen", required: false }] }, { type: i0.Output, args: ["sidebarOpenChange"] }], hideToggle: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideToggle", required: false }] }], skipLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "skipLabel", required: false }] }], openMenuLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "openMenuLabel", required: false }] }], closeMenuLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeMenuLabel", required: false }] }], navLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "navLabel", required: false }] }] } });

/**
 * Tela dividida para login, cadastro e recuperação de senha.
 *
 * O painel de marca some abaixo de 900px — no celular o formulário ocupa a
 * tela inteira, que é o que importa ali. Por ser decorativo, ele fica depois
 * do formulário na ordem do DOM: quem navega por teclado chega ao campo antes.
 *
 * @example
 * ```html
 * <bd-auth-layout title="Bem-vindo de volta" subtitle="Entre para continuar.">
 *   <div bdAuthAside>
 *     <h2>Sua marca aqui</h2>
 *   </div>
 *
 *   <form>…</form>
 * </bd-auth-layout>
 * ```
 */
class BdAuthLayoutComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    subtitle = input('', ...(ngDevMode ? [{ debugName: "subtitle" }] : []));
    /** Lado do painel decorativo no desktop. */
    asideSide = input('right', ...(ngDevMode ? [{ debugName: "asideSide" }] : []));
    classes = computed(() => `bd-auth--${this.asideSide()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAuthLayoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdAuthLayoutComponent, isStandalone: true, selector: "bd-auth-layout", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: false, transformFunction: null }, asideSide: { classPropertyName: "asideSide", publicName: "asideSide", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    <main class="bd-auth__main">
      <div class="bd-auth__box">
        <div class="bd-auth__brand">
          <ng-content select="[bdAuthBrand]" />
        </div>

        <h1 class="bd-auth__title">{{ title() }}</h1>
        @if (subtitle()) {
          <p class="bd-auth__subtitle">{{ subtitle() }}</p>
        }

        <div class="bd-auth__content"><ng-content /></div>

        <div class="bd-auth__footer">
          <ng-content select="[bdAuthFooter]" />
        </div>
      </div>
    </main>

    <!-- Decorativo e depois do formulário no DOM: o teclado chega ao campo antes. -->
    <aside class="bd-auth__aside" aria-hidden="true">
      <ng-content select="[bdAuthAside]" />
    </aside>
  `, isInline: true, styles: [":host{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);min-height:100vh;background:var(--bd-bg, #fff);color:var(--bd-fg, #10131c)}:host(.bd-auth--left) .bd-auth__main{order:2}:host(.bd-auth--left) .bd-auth__aside{order:1}.bd-auth__main{display:grid;place-items:center;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem)}.bd-auth__box{width:100%;max-width:380px}.bd-auth__brand:not(:empty){margin-bottom:var(--bd-space-6, 2rem)}.bd-auth__title{margin:0;font-size:var(--bd-text-2xl, 1.75rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em}.bd-auth__subtitle{margin:.4rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-auth__content{margin-top:var(--bd-space-6, 2rem)}.bd-auth__footer:not(:empty){margin-top:var(--bd-space-5, 1.5rem);padding-top:var(--bd-space-5, 1.5rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-muted, #545c70);font-size:.88rem;text-align:center}.bd-auth__aside{display:grid;place-items:center;padding:var(--bd-space-7, 3rem);background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));color:#fff}@media(max-width:900px){:host{grid-template-columns:minmax(0,1fr)}.bd-auth__aside{display:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAuthLayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-auth-layout', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <main class="bd-auth__main">
      <div class="bd-auth__box">
        <div class="bd-auth__brand">
          <ng-content select="[bdAuthBrand]" />
        </div>

        <h1 class="bd-auth__title">{{ title() }}</h1>
        @if (subtitle()) {
          <p class="bd-auth__subtitle">{{ subtitle() }}</p>
        }

        <div class="bd-auth__content"><ng-content /></div>

        <div class="bd-auth__footer">
          <ng-content select="[bdAuthFooter]" />
        </div>
      </div>
    </main>

    <!-- Decorativo e depois do formulário no DOM: o teclado chega ao campo antes. -->
    <aside class="bd-auth__aside" aria-hidden="true">
      <ng-content select="[bdAuthAside]" />
    </aside>
  `, host: { '[class]': 'classes()' }, styles: [":host{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);min-height:100vh;background:var(--bd-bg, #fff);color:var(--bd-fg, #10131c)}:host(.bd-auth--left) .bd-auth__main{order:2}:host(.bd-auth--left) .bd-auth__aside{order:1}.bd-auth__main{display:grid;place-items:center;padding:var(--bd-space-6, 2rem) var(--bd-space-5, 1.5rem)}.bd-auth__box{width:100%;max-width:380px}.bd-auth__brand:not(:empty){margin-bottom:var(--bd-space-6, 2rem)}.bd-auth__title{margin:0;font-size:var(--bd-text-2xl, 1.75rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em}.bd-auth__subtitle{margin:.4rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-auth__content{margin-top:var(--bd-space-6, 2rem)}.bd-auth__footer:not(:empty){margin-top:var(--bd-space-5, 1.5rem);padding-top:var(--bd-space-5, 1.5rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-muted, #545c70);font-size:.88rem;text-align:center}.bd-auth__aside{display:grid;place-items:center;padding:var(--bd-space-7, 3rem);background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));color:#fff}@media(max-width:900px){:host{grid-template-columns:minmax(0,1fr)}.bd-auth__aside{display:none}}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: false }] }], asideSide: [{ type: i0.Input, args: [{ isSignal: true, alias: "asideSide", required: false }] }] } });

/**
 * Centraliza o conteúdo com largura máxima e respiro lateral.
 *
 * O respiro é responsivo, então o conteúdo nunca encosta na borda no celular.
 *
 * @example
 * ```html
 * <bd-container size="md">…</bd-container>
 * ```
 */
class BdContainerComponent {
    size = input('lg', ...(ngDevMode ? [{ debugName: "size" }] : []));
    classes = computed(() => `bd-container--${this.size()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdContainerComponent, isStandalone: true, selector: "bd-container", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `<ng-content />`, isInline: true, styles: [":host{display:block;width:100%;margin-inline:auto;padding-inline:var(--bd-space-4, 1rem)}:host(.bd-container--sm){max-width:640px}:host(.bd-container--md){max-width:960px}:host(.bd-container--lg){max-width:1280px}:host(.bd-container--full){max-width:none}@media(min-width:768px){:host{padding-inline:var(--bd-space-5, 1.5rem)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-container', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `<ng-content />`, host: { '[class]': 'classes()' }, styles: [":host{display:block;width:100%;margin-inline:auto;padding-inline:var(--bd-space-4, 1rem)}:host(.bd-container--sm){max-width:640px}:host(.bd-container--md){max-width:960px}:host(.bd-container--lg){max-width:1280px}:host(.bd-container--full){max-width:none}@media(min-width:768px){:host{padding-inline:var(--bd-space-5, 1.5rem)}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

/**
 * Cabeçalho de página: título, descrição e ações à direita.
 *
 * O título sai como `<h1>` — em quase toda tela ele é o título principal, e
 * pular esse nível quebra a navegação por cabeçalhos no leitor de tela.
 *
 * @example
 * ```html
 * <bd-page-header title="Projetos" description="Tudo que está em andamento.">
 *   <nav bdPageHeaderBreadcrumb>Início / Projetos</nav>
 *   <button bdButton bdPageHeaderActions>Novo projeto</button>
 * </bd-page-header>
 * ```
 */
class BdPageHeaderComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdPageHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdPageHeaderComponent, isStandalone: true, selector: "bd-page-header", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="bd-page-header__breadcrumb">
      <ng-content select="[bdPageHeaderBreadcrumb]" />
    </div>

    <div class="bd-page-header__row">
      <div class="bd-page-header__text">
        <h1 class="bd-page-header__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-page-header__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-page-header__actions">
        <ng-content select="[bdPageHeaderActions]" />
      </div>
    </div>

    <!-- Conteúdo livre embaixo: abas, filtros, o que a tela precisar. -->
    <div class="bd-page-header__extra"><ng-content /></div>
  `, isInline: true, styles: [":host{display:block;padding-bottom:var(--bd-space-5, 1.5rem);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-page-header__breadcrumb:not(:empty){margin-bottom:var(--bd-space-2, .5rem);color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-sm, .875rem)}.bd-page-header__row{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem)}.bd-page-header__text{min-width:0}.bd-page-header__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-page-header__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-page-header__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-page-header__extra:not(:empty){margin-top:var(--bd-space-5, 1.5rem)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdPageHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-page-header', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="bd-page-header__breadcrumb">
      <ng-content select="[bdPageHeaderBreadcrumb]" />
    </div>

    <div class="bd-page-header__row">
      <div class="bd-page-header__text">
        <h1 class="bd-page-header__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-page-header__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-page-header__actions">
        <ng-content select="[bdPageHeaderActions]" />
      </div>
    </div>

    <!-- Conteúdo livre embaixo: abas, filtros, o que a tela precisar. -->
    <div class="bd-page-header__extra"><ng-content /></div>
  `, styles: [":host{display:block;padding-bottom:var(--bd-space-5, 1.5rem);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-page-header__breadcrumb:not(:empty){margin-bottom:var(--bd-space-2, .5rem);color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-sm, .875rem)}.bd-page-header__row{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem)}.bd-page-header__text{min-width:0}.bd-page-header__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-page-header__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-page-header__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-page-header__extra:not(:empty){margin-top:var(--bd-space-5, 1.5rem)}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }] } });

/**
 * Lista de seções expansíveis.
 *
 * O cabeçalho de cada seção é um `<button>` dentro de um heading, com
 * `aria-expanded` e `aria-controls` ligados ao painel — a estrutura que
 * leitores de tela usam para navegar por seções.
 *
 * @example
 * ```html
 * <bd-accordion [items]="perguntas" [(opened)]="abertas" />
 * <bd-accordion [items]="perguntas" multiple />
 * ```
 */
class BdAccordionComponent {
    items = input.required(...(ngDevMode ? [{ debugName: "items" }] : []));
    /** Ids das seções abertas. Two-way: `[(opened)]="abertas"`. */
    opened = model([], ...(ngDevMode ? [{ debugName: "opened" }] : []));
    /** Permite mais de uma seção aberta ao mesmo tempo. */
    multiple = input(false, ...(ngDevMode ? [{ debugName: "multiple", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Emitido com o id e o novo estado da seção. */
    toggled = output();
    estaAberto(id) {
        return this.opened().includes(id);
    }
    toggle(item) {
        if (item.disabled)
            return;
        const abertas = this.opened();
        const jaAberto = abertas.includes(item.id);
        const novas = jaAberto
            ? abertas.filter((i) => i !== item.id)
            : this.multiple()
                ? [...abertas, item.id]
                : [item.id];
        this.opened.set(novas);
        this.toggled.emit({ id: item.id, open: !jaAberto });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAccordionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdAccordionComponent, isStandalone: true, selector: "bd-accordion", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, opened: { classPropertyName: "opened", publicName: "opened", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { opened: "openedChange", toggled: "toggled" }, ngImport: i0, template: `
    @for (item of items(); track item.id) {
      <div class="bd-accordion__item" [class.is-open]="estaAberto(item.id)">
        <h3 class="bd-accordion__heading">
          <button
            type="button"
            class="bd-accordion__trigger"
            [id]="'bd-acc-trigger-' + item.id"
            [attr.aria-expanded]="estaAberto(item.id)"
            [attr.aria-controls]="'bd-acc-panel-' + item.id"
            [disabled]="item.disabled || null"
            (click)="toggle(item)"
          >
            <span class="bd-accordion__title">{{ item.title }}</span>
            <span class="bd-accordion__chevron" aria-hidden="true">⌄</span>
          </button>
        </h3>

        <div
          class="bd-accordion__panel"
          role="region"
          [id]="'bd-acc-panel-' + item.id"
          [attr.aria-labelledby]="'bd-acc-trigger-' + item.id"
          [hidden]="!estaAberto(item.id)"
        >
          <div class="bd-accordion__content">{{ item.content }}</div>
        </div>
      </div>
    }
  `, isInline: true, styles: [":host{display:block;border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem);overflow:hidden}.bd-accordion__item+.bd-accordion__item{border-top:1px solid var(--bd-border, #e3e7f0)}.bd-accordion__heading{margin:0;font-size:inherit;font-weight:inherit}.bd-accordion__trigger{display:flex;align-items:center;justify-content:space-between;gap:1rem;width:100%;padding:var(--bd-space-4, 1rem) var(--bd-space-5, 1.5rem);background:transparent;border:none;color:var(--bd-fg, #10131c);font-family:inherit;font-size:.95rem;font-weight:var(--bd-weight-semibold, 600);text-align:left;cursor:pointer;transition:background var(--bd-duration-fast, .15s) ease}.bd-accordion__trigger:hover:not(:disabled){background:var(--bd-surface-hover, #f1f3f9)}.bd-accordion__trigger:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));outline-offset:-3px}.bd-accordion__trigger:disabled{opacity:.5;cursor:not-allowed}.bd-accordion__chevron{flex-shrink:0;color:var(--bd-fg-subtle, #7b8399);font-size:1.1rem;line-height:1;transition:transform var(--bd-duration, .25s) var(--bd-ease, ease)}.is-open .bd-accordion__chevron{transform:rotate(180deg);color:var(--bd-primary, #3d5ce8)}.bd-accordion__panel[hidden]{display:none}.bd-accordion__content{padding:0 var(--bd-space-5, 1.5rem) var(--bd-space-5, 1.5rem);color:var(--bd-fg-muted, #545c70);font-size:.92rem;line-height:1.7}@media(prefers-reduced-motion:reduce){.bd-accordion__chevron,.bd-accordion__trigger{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-accordion', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @for (item of items(); track item.id) {
      <div class="bd-accordion__item" [class.is-open]="estaAberto(item.id)">
        <h3 class="bd-accordion__heading">
          <button
            type="button"
            class="bd-accordion__trigger"
            [id]="'bd-acc-trigger-' + item.id"
            [attr.aria-expanded]="estaAberto(item.id)"
            [attr.aria-controls]="'bd-acc-panel-' + item.id"
            [disabled]="item.disabled || null"
            (click)="toggle(item)"
          >
            <span class="bd-accordion__title">{{ item.title }}</span>
            <span class="bd-accordion__chevron" aria-hidden="true">⌄</span>
          </button>
        </h3>

        <div
          class="bd-accordion__panel"
          role="region"
          [id]="'bd-acc-panel-' + item.id"
          [attr.aria-labelledby]="'bd-acc-trigger-' + item.id"
          [hidden]="!estaAberto(item.id)"
        >
          <div class="bd-accordion__content">{{ item.content }}</div>
        </div>
      </div>
    }
  `, styles: [":host{display:block;border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem);overflow:hidden}.bd-accordion__item+.bd-accordion__item{border-top:1px solid var(--bd-border, #e3e7f0)}.bd-accordion__heading{margin:0;font-size:inherit;font-weight:inherit}.bd-accordion__trigger{display:flex;align-items:center;justify-content:space-between;gap:1rem;width:100%;padding:var(--bd-space-4, 1rem) var(--bd-space-5, 1.5rem);background:transparent;border:none;color:var(--bd-fg, #10131c);font-family:inherit;font-size:.95rem;font-weight:var(--bd-weight-semibold, 600);text-align:left;cursor:pointer;transition:background var(--bd-duration-fast, .15s) ease}.bd-accordion__trigger:hover:not(:disabled){background:var(--bd-surface-hover, #f1f3f9)}.bd-accordion__trigger:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));outline-offset:-3px}.bd-accordion__trigger:disabled{opacity:.5;cursor:not-allowed}.bd-accordion__chevron{flex-shrink:0;color:var(--bd-fg-subtle, #7b8399);font-size:1.1rem;line-height:1;transition:transform var(--bd-duration, .25s) var(--bd-ease, ease)}.is-open .bd-accordion__chevron{transform:rotate(180deg);color:var(--bd-primary, #3d5ce8)}.bd-accordion__panel[hidden]{display:none}.bd-accordion__content{padding:0 var(--bd-space-5, 1.5rem) var(--bd-space-5, 1.5rem);color:var(--bd-fg-muted, #545c70);font-size:.92rem;line-height:1.7}@media(prefers-reduced-motion:reduce){.bd-accordion__chevron,.bd-accordion__trigger{transition:none}}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], opened: [{ type: i0.Input, args: [{ isSignal: true, alias: "opened", required: false }] }, { type: i0.Output, args: ["openedChange"] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], toggled: [{ type: i0.Output, args: ["toggled"] }] } });

/**
 * Indicador de progresso em etapas.
 *
 * A marcação é sempre a mesma — uma lista ordenada com `aria-current="step"` na
 * etapa corrente —, o que muda entre as variantes é apenas a apresentação. A
 * posição no processo é, portanto, anunciada por leitores de tela em todas
 * elas, e não apenas sinalizada por cor.
 *
 * Etapas já concluídas voltam a ser navegáveis quando `clickable` está ativo;
 * as futuras permanecem bloqueadas, porque o indicador não tem como saber se as
 * intermediárias foram preenchidas.
 *
 * @example
 * ```html
 * <bd-steps [steps]="etapas" [(active)]="etapa" variant="line" clickable />
 * <bd-steps [steps]="etapas" [active]="etapa()" variant="numbered" orientation="vertical" />
 * <bd-steps [steps]="etapas" [active]="etapa()" variant="progress" />
 * ```
 */
class BdStepsComponent {
    steps = input([], ...(ngDevMode ? [{ debugName: "steps" }] : []));
    /** Two-way com o índice da etapa corrente. */
    active = model(0, ...(ngDevMode ? [{ debugName: "active" }] : []));
    variant = input('panel', ...(ngDevMode ? [{ debugName: "variant" }] : []));
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : []));
    /** Permite retornar a etapas já concluídas pelo próprio indicador. */
    clickable = input(false, ...(ngDevMode ? [{ debugName: "clickable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    label = input('Etapas do processo', ...(ngDevMode ? [{ debugName: "label" }] : []));
    /** Recebe (posição atual, total) — ex.: "Etapa 2 de 5". */
    counter = input((current, total) => `Etapa ${current} de ${total}`, ...(ngDevMode ? [{ debugName: "counter" }] : []));
    stepChange = output();
    classes = computed(() => `bd-steps--${this.variant()} bd-steps--${this.orientation()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    hasConnector = computed(() => ['line', 'dots', 'numbered'].includes(this.variant()), ...(ngDevMode ? [{ debugName: "hasConnector" }] : []));
    progress = computed(() => {
        const total = this.steps().length;
        if (total <= 1)
            return 100;
        return ((this.active() + 1) / total) * 100;
    }, ...(ngDevMode ? [{ debugName: "progress" }] : []));
    currentLabel = computed(() => this.steps()[this.active()]?.label ?? '', ...(ngDevMode ? [{ debugName: "currentLabel" }] : []));
    counterText = computed(() => this.counter()(this.active() + 1, this.steps().length), ...(ngDevMode ? [{ debugName: "counterText" }] : []));
    isReachable(index) {
        return this.clickable() && index < this.active();
    }
    markerFor(step, index) {
        if (index < this.active())
            return step.icon ?? '✓';
        return step.icon ?? String(index + 1);
    }
    select(index) {
        if (!this.isReachable(index))
            return;
        this.active.set(index);
        this.stepChange.emit(index);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdStepsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdStepsComponent, isStandalone: true, selector: "bd-steps", inputs: { steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, clickable: { classPropertyName: "clickable", publicName: "clickable", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, counter: { classPropertyName: "counter", publicName: "counter", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { active: "activeChange", stepChange: "stepChange" }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    @if (variant() === 'progress') {
      <!-- Compacto: uma barra e um contador, sem repetir os rótulos. -->
      <div class="bd-steps__progress">
        <div class="bd-steps__progress-head">
          <span class="bd-steps__progress-label">{{ currentLabel() }}</span>
          <span class="bd-steps__progress-count">{{ counterText() }}</span>
        </div>
        <div
          class="bd-steps__progress-track"
          role="progressbar"
          [attr.aria-valuenow]="active() + 1"
          [attr.aria-valuemin]="1"
          [attr.aria-valuemax]="steps().length"
          [attr.aria-label]="label()"
        >
          <span class="bd-steps__progress-fill" [style.width.%]="progress()"></span>
        </div>
      </div>
    } @else {
      <ol class="bd-steps__list" [attr.aria-label]="label()">
        @for (step of steps(); track $index; let index = $index, last = $last) {
          <li
            class="bd-steps__item"
            [class.is-active]="index === active()"
            [class.is-done]="index < active()"
            [class.is-last]="last"
            [attr.aria-current]="index === active() ? 'step' : null"
          >
            <button
              type="button"
              class="bd-steps__btn"
              [disabled]="!isReachable(index)"
              (click)="select(index)"
            >
              <span class="bd-steps__marker" aria-hidden="true">
                {{ markerFor(step, index) }}
              </span>

              @if (variant() !== 'dots') {
                <span class="bd-steps__text">
                  <span class="bd-steps__label">{{ step.label }}</span>
                  @if (step.hint) {
                    <span class="bd-steps__hint">{{ step.hint }}</span>
                  }
                </span>
              } @else {
                <span class="bd-steps__sr">{{ step.label }}</span>
              }
            </button>

            @if (!last && hasConnector()) {
              <span class="bd-steps__connector" aria-hidden="true"></span>
            }
          </li>
        }
      </ol>
    }
  `, isInline: true, styles: [":host{display:block}.bd-steps__list{display:flex;margin:0;padding:0;list-style:none}.bd-steps__item{display:flex;align-items:center;min-width:0}.bd-steps__btn{display:flex;align-items:center;gap:var(--bd-space-3, .75rem);min-width:0;background:transparent;border:1px solid transparent;color:var(--bd-fg-muted, #545c70);font-family:inherit;text-align:left;cursor:pointer;transition:border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.bd-steps__btn:disabled{cursor:default;opacity:.62}.bd-steps__btn:not(:disabled):hover{color:var(--bd-primary, #3d5ce8)}.bd-steps__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}.bd-steps__marker{display:grid;place-items:center;flex-shrink:0;width:28px;height:28px;background:var(--bd-surface-hover, #f1f3f9);border-radius:50%;font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-bold, 700);transition:background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.is-active .bd-steps__marker,.is-done .bd-steps__marker{background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}.bd-steps__text{min-width:0}.bd-steps__label{display:block;font-size:.9rem;font-weight:var(--bd-weight-semibold, 600)}.bd-steps__hint{display:block;color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-normal, 400)}.is-active .bd-steps__label{color:var(--bd-primary, #3d5ce8)}.bd-steps__connector{flex:1;min-width:18px;height:2px;margin:0 var(--bd-space-2, .5rem);background:var(--bd-border, #e3e7f0);border-radius:2px;transition:background var(--bd-duration, .25s) ease}.is-done .bd-steps__connector{background:var(--bd-primary, #3d5ce8)}.bd-steps__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}:host(.bd-steps--panel) .bd-steps__list{flex-wrap:wrap;gap:var(--bd-space-2, .5rem)}:host(.bd-steps--panel) .bd-steps__item{flex:1 1 180px}:host(.bd-steps--panel) .bd-steps__btn{width:100%;padding:.7rem .85rem;border-color:var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem)}:host(.bd-steps--panel) .bd-steps__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8)}:host(.bd-steps--panel) .is-active .bd-steps__btn{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8)}:host(.bd-steps--line) .bd-steps__item,:host(.bd-steps--dots) .bd-steps__item{flex:1 1 auto}:host(.bd-steps--line) .bd-steps__item.is-last,:host(.bd-steps--dots) .bd-steps__item.is-last{flex:0 0 auto}:host(.bd-steps--line) .bd-steps__btn{flex-direction:column;gap:.4rem;text-align:center}:host(.bd-steps--line) .bd-steps__text{max-width:12ch}:host(.bd-steps--line) .bd-steps__connector{align-self:flex-start;margin-top:14px}:host(.bd-steps--dots) .bd-steps__marker{width:10px;height:10px;font-size:0}:host(.bd-steps--dots) .is-active .bd-steps__marker{width:26px;border-radius:var(--bd-radius-full, 9999px)}:host(.bd-steps--dots) .bd-steps__connector{min-width:10px;margin:0 4px}:host(.bd-steps--numbered) .bd-steps__list{gap:var(--bd-space-4, 1rem)}:host(.bd-steps--numbered) .bd-steps__marker{border:2px solid var(--bd-border-strong, #cbd2e2);background:transparent;color:var(--bd-fg-muted, #545c70)}:host(.bd-steps--numbered) .is-active .bd-steps__marker,:host(.bd-steps--numbered) .is-done .bd-steps__marker{border-color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}:host(.bd-steps--vertical) .bd-steps__list{flex-direction:column;align-items:stretch;gap:0}:host(.bd-steps--vertical) .bd-steps__item{flex-direction:column;align-items:stretch}:host(.bd-steps--vertical) .bd-steps__btn{flex-direction:row;padding-block:.4rem;text-align:left}:host(.bd-steps--vertical) .bd-steps__text{max-width:none}:host(.bd-steps--vertical) .bd-steps__connector{flex:0 0 18px;width:2px;height:18px;min-width:0;margin:0 0 0 13px;align-self:flex-start}.bd-steps__progress-head{display:flex;align-items:baseline;justify-content:space-between;gap:var(--bd-space-3, .75rem);margin-bottom:.5rem}.bd-steps__progress-label{color:var(--bd-fg, #10131c);font-size:.95rem;font-weight:var(--bd-weight-semibold, 600)}.bd-steps__progress-count{color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-sm, .875rem);font-variant-numeric:tabular-nums}.bd-steps__progress-track{height:6px;background:var(--bd-surface-hover, #f1f3f9);border-radius:var(--bd-radius-full, 9999px);overflow:hidden}.bd-steps__progress-fill{display:block;height:100%;background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));border-radius:inherit;transition:width var(--bd-duration-slow, .5s) var(--bd-ease, ease)}@media(prefers-reduced-motion:reduce){.bd-steps__btn,.bd-steps__marker,.bd-steps__connector,.bd-steps__progress-fill{transition:none}}@media(max-width:640px){:host(.bd-steps--line) .bd-steps__item:not(.is-active) .bd-steps__text{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}:host(.bd-steps--panel) .bd-steps__hint{display:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdStepsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-steps', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: { '[class]': 'classes()' }, template: `
    @if (variant() === 'progress') {
      <!-- Compacto: uma barra e um contador, sem repetir os rótulos. -->
      <div class="bd-steps__progress">
        <div class="bd-steps__progress-head">
          <span class="bd-steps__progress-label">{{ currentLabel() }}</span>
          <span class="bd-steps__progress-count">{{ counterText() }}</span>
        </div>
        <div
          class="bd-steps__progress-track"
          role="progressbar"
          [attr.aria-valuenow]="active() + 1"
          [attr.aria-valuemin]="1"
          [attr.aria-valuemax]="steps().length"
          [attr.aria-label]="label()"
        >
          <span class="bd-steps__progress-fill" [style.width.%]="progress()"></span>
        </div>
      </div>
    } @else {
      <ol class="bd-steps__list" [attr.aria-label]="label()">
        @for (step of steps(); track $index; let index = $index, last = $last) {
          <li
            class="bd-steps__item"
            [class.is-active]="index === active()"
            [class.is-done]="index < active()"
            [class.is-last]="last"
            [attr.aria-current]="index === active() ? 'step' : null"
          >
            <button
              type="button"
              class="bd-steps__btn"
              [disabled]="!isReachable(index)"
              (click)="select(index)"
            >
              <span class="bd-steps__marker" aria-hidden="true">
                {{ markerFor(step, index) }}
              </span>

              @if (variant() !== 'dots') {
                <span class="bd-steps__text">
                  <span class="bd-steps__label">{{ step.label }}</span>
                  @if (step.hint) {
                    <span class="bd-steps__hint">{{ step.hint }}</span>
                  }
                </span>
              } @else {
                <span class="bd-steps__sr">{{ step.label }}</span>
              }
            </button>

            @if (!last && hasConnector()) {
              <span class="bd-steps__connector" aria-hidden="true"></span>
            }
          </li>
        }
      </ol>
    }
  `, styles: [":host{display:block}.bd-steps__list{display:flex;margin:0;padding:0;list-style:none}.bd-steps__item{display:flex;align-items:center;min-width:0}.bd-steps__btn{display:flex;align-items:center;gap:var(--bd-space-3, .75rem);min-width:0;background:transparent;border:1px solid transparent;color:var(--bd-fg-muted, #545c70);font-family:inherit;text-align:left;cursor:pointer;transition:border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.bd-steps__btn:disabled{cursor:default;opacity:.62}.bd-steps__btn:not(:disabled):hover{color:var(--bd-primary, #3d5ce8)}.bd-steps__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}.bd-steps__marker{display:grid;place-items:center;flex-shrink:0;width:28px;height:28px;background:var(--bd-surface-hover, #f1f3f9);border-radius:50%;font-size:var(--bd-text-sm, .875rem);font-weight:var(--bd-weight-bold, 700);transition:background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.is-active .bd-steps__marker,.is-done .bd-steps__marker{background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}.bd-steps__text{min-width:0}.bd-steps__label{display:block;font-size:.9rem;font-weight:var(--bd-weight-semibold, 600)}.bd-steps__hint{display:block;color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-normal, 400)}.is-active .bd-steps__label{color:var(--bd-primary, #3d5ce8)}.bd-steps__connector{flex:1;min-width:18px;height:2px;margin:0 var(--bd-space-2, .5rem);background:var(--bd-border, #e3e7f0);border-radius:2px;transition:background var(--bd-duration, .25s) ease}.is-done .bd-steps__connector{background:var(--bd-primary, #3d5ce8)}.bd-steps__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}:host(.bd-steps--panel) .bd-steps__list{flex-wrap:wrap;gap:var(--bd-space-2, .5rem)}:host(.bd-steps--panel) .bd-steps__item{flex:1 1 180px}:host(.bd-steps--panel) .bd-steps__btn{width:100%;padding:.7rem .85rem;border-color:var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem)}:host(.bd-steps--panel) .bd-steps__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8)}:host(.bd-steps--panel) .is-active .bd-steps__btn{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8)}:host(.bd-steps--line) .bd-steps__item,:host(.bd-steps--dots) .bd-steps__item{flex:1 1 auto}:host(.bd-steps--line) .bd-steps__item.is-last,:host(.bd-steps--dots) .bd-steps__item.is-last{flex:0 0 auto}:host(.bd-steps--line) .bd-steps__btn{flex-direction:column;gap:.4rem;text-align:center}:host(.bd-steps--line) .bd-steps__text{max-width:12ch}:host(.bd-steps--line) .bd-steps__connector{align-self:flex-start;margin-top:14px}:host(.bd-steps--dots) .bd-steps__marker{width:10px;height:10px;font-size:0}:host(.bd-steps--dots) .is-active .bd-steps__marker{width:26px;border-radius:var(--bd-radius-full, 9999px)}:host(.bd-steps--dots) .bd-steps__connector{min-width:10px;margin:0 4px}:host(.bd-steps--numbered) .bd-steps__list{gap:var(--bd-space-4, 1rem)}:host(.bd-steps--numbered) .bd-steps__marker{border:2px solid var(--bd-border-strong, #cbd2e2);background:transparent;color:var(--bd-fg-muted, #545c70)}:host(.bd-steps--numbered) .is-active .bd-steps__marker,:host(.bd-steps--numbered) .is-done .bd-steps__marker{border-color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-strong, #2b46c9);color:var(--bd-primary-contrast, #fff)}:host(.bd-steps--vertical) .bd-steps__list{flex-direction:column;align-items:stretch;gap:0}:host(.bd-steps--vertical) .bd-steps__item{flex-direction:column;align-items:stretch}:host(.bd-steps--vertical) .bd-steps__btn{flex-direction:row;padding-block:.4rem;text-align:left}:host(.bd-steps--vertical) .bd-steps__text{max-width:none}:host(.bd-steps--vertical) .bd-steps__connector{flex:0 0 18px;width:2px;height:18px;min-width:0;margin:0 0 0 13px;align-self:flex-start}.bd-steps__progress-head{display:flex;align-items:baseline;justify-content:space-between;gap:var(--bd-space-3, .75rem);margin-bottom:.5rem}.bd-steps__progress-label{color:var(--bd-fg, #10131c);font-size:.95rem;font-weight:var(--bd-weight-semibold, 600)}.bd-steps__progress-count{color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-sm, .875rem);font-variant-numeric:tabular-nums}.bd-steps__progress-track{height:6px;background:var(--bd-surface-hover, #f1f3f9);border-radius:var(--bd-radius-full, 9999px);overflow:hidden}.bd-steps__progress-fill{display:block;height:100%;background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));border-radius:inherit;transition:width var(--bd-duration-slow, .5s) var(--bd-ease, ease)}@media(prefers-reduced-motion:reduce){.bd-steps__btn,.bd-steps__marker,.bd-steps__connector,.bd-steps__progress-fill{transition:none}}@media(max-width:640px){:host(.bd-steps--line) .bd-steps__item:not(.is-active) .bd-steps__text{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}:host(.bd-steps--panel) .bd-steps__hint{display:none}}\n"] }]
        }], propDecorators: { steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: false }] }, { type: i0.Output, args: ["activeChange"] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], clickable: [{ type: i0.Input, args: [{ isSignal: true, alias: "clickable", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], counter: [{ type: i0.Input, args: [{ isSignal: true, alias: "counter", required: false }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }] } });

/**
 * Painel de conteúdo ligado a uma aba do `<bd-tabs>`.
 *
 * Recebe `role="tabpanel"` e o `aria-labelledby` apontando para a aba
 * correspondente, fechando o par que os leitores de tela esperam.
 *
 * @example
 * ```html
 * <bd-tabs [tabs]="abas" [(active)]="abaAtiva" />
 *
 * <bd-tab-panel tabId="design" [active]="abaAtiva()">
 *   Conteúdo da aba de design
 * </bd-tab-panel>
 * ```
 */
class BdTabPanelComponent {
    /** Deve casar com o `id` da aba correspondente em `<bd-tabs>`. */
    tabId = input.required(...(ngDevMode ? [{ debugName: "tabId" }] : []));
    /** O `id` da aba ativa no momento. */
    active = input.required(...(ngDevMode ? [{ debugName: "active" }] : []));
    isVisible = computed(() => this.active() === this.tabId(), ...(ngDevMode ? [{ debugName: "isVisible" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTabPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdTabPanelComponent, isStandalone: true, selector: "bd-tab-panel", inputs: { tabId: { classPropertyName: "tabId", publicName: "tabId", isSignal: true, isRequired: true, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: true, transformFunction: null } }, host: { attributes: { "role": "tabpanel" }, properties: { "id": "\"bd-panel-\" + tabId()", "attr.aria-labelledby": "\"bd-tab-\" + tabId()", "hidden": "!isVisible()", "attr.tabindex": "isVisible() ? 0 : null" } }, ngImport: i0, template: `
    @if (isVisible()) {
      <ng-content />
    }
  `, isInline: true, styles: [":host{display:block;outline:none}:host([hidden]){display:none}:host(:focus-visible){box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTabPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-tab-panel', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (isVisible()) {
      <ng-content />
    }
  `, host: {
                        role: 'tabpanel',
                        '[id]': '"bd-panel-" + tabId()',
                        '[attr.aria-labelledby]': '"bd-tab-" + tabId()',
                        '[hidden]': '!isVisible()',
                        // Painel focável pelo teclado quando não há elemento interativo dentro.
                        '[attr.tabindex]': 'isVisible() ? 0 : null',
                    }, styles: [":host{display:block;outline:none}:host([hidden]){display:none}:host(:focus-visible){box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}\n"] }]
        }], propDecorators: { tabId: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabId", required: true }] }], active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: true }] }] } });

/**
 * Navegação por abas seguindo o padrão WAI-ARIA de `tablist`.
 *
 * Setas ←/→ movem entre as abas, `Home`/`End` vão para as pontas e o foco
 * acompanha a seleção. Abas desabilitadas são puladas na navegação.
 *
 * Use com `<bd-tab-panel>` para que o painel também receba os papéis corretos.
 *
 * @example
 * ```html
 * <bd-tabs [tabs]="abas" [(active)]="abaAtiva" label="Seções" />
 *
 * <bd-tab-panel tabId="design" [active]="abaAtiva()">
 *   Conteúdo da aba
 * </bd-tab-panel>
 * ```
 */
class BdTabsComponent {
    tabs = input.required(...(ngDevMode ? [{ debugName: "tabs" }] : []));
    /** Two-way: `[(active)]="minhaAba"`. */
    active = model.required(...(ngDevMode ? [{ debugName: "active" }] : []));
    label = input('Abas', ...(ngDevMode ? [{ debugName: "label" }] : []));
    host = inject(ElementRef);
    select(tab) {
        if (!tab.disabled) {
            this.active.set(tab.id);
        }
    }
    onKeydown(event, index) {
        const tabs = this.tabs();
        const total = tabs.length;
        let target = null;
        switch (event.key) {
            case 'ArrowRight':
                target = this.nextEnabled(index, 1);
                break;
            case 'ArrowLeft':
                target = this.nextEnabled(index, -1);
                break;
            case 'Home':
                target = this.nextEnabled(-1, 1);
                break;
            case 'End':
                target = this.nextEnabled(total, -1);
                break;
        }
        if (target === null)
            return;
        event.preventDefault();
        this.active.set(tabs[target].id);
        // O foco acompanha a seleção, conforme o padrão de `tablist`.
        this.host.nativeElement.querySelectorAll('.bd-tabs__tab')[target]?.focus();
    }
    /**
     * Caminha na direção informada ignorando abas desabilitadas, com retorno
     * circular. Devolve `null` quando não há nenhuma aba habilitada.
     */
    nextEnabled(start, step) {
        const tabs = this.tabs();
        const total = tabs.length;
        for (let i = 1; i <= total; i++) {
            const index = (((start + step * i) % total) + total) % total;
            if (!tabs[index].disabled)
                return index;
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdTabsComponent, isStandalone: true, selector: "bd-tabs", inputs: { tabs: { classPropertyName: "tabs", publicName: "tabs", isSignal: true, isRequired: true, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { active: "activeChange" }, ngImport: i0, template: `
    <div class="bd-tabs" role="tablist" [attr.aria-label]="label()">
      @for (tab of tabs(); track tab.id; let i = $index) {
        <button
          type="button"
          role="tab"
          class="bd-tabs__tab"
          [id]="'bd-tab-' + tab.id"
          [class.is-active]="active() === tab.id"
          [attr.aria-selected]="active() === tab.id"
          [attr.aria-controls]="'bd-panel-' + tab.id"
          [attr.tabindex]="active() === tab.id ? 0 : -1"
          [disabled]="tab.disabled || null"
          (click)="select(tab)"
          (keydown)="onKeydown($event, i)"
        >
          @if (tab.icon) {
            <i [class]="tab.icon" aria-hidden="true"></i>
          }
          {{ tab.label }}
        </button>
      }
    </div>
  `, isInline: true, styles: [".bd-tabs{display:flex;flex-wrap:wrap;gap:var(--bd-space-2, .5rem)}.bd-tabs__tab{display:inline-flex;align-items:center;gap:var(--bd-space-2, .5rem);min-height:44px;padding:.55rem 1.15rem;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-full, 9999px);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:.92rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease)}.bd-tabs__tab:hover:not(:disabled){color:var(--bd-fg, #10131c);border-color:var(--bd-border-strong, #cbd2e2);transform:translateY(-2px)}.bd-tabs__tab:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-tabs__tab:disabled{opacity:.5;cursor:not-allowed}.bd-tabs__tab.is-active{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}@media(prefers-reduced-motion:reduce){.bd-tabs__tab,.bd-tabs__tab:hover:not(:disabled){transition:none;transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-tabs', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div class="bd-tabs" role="tablist" [attr.aria-label]="label()">
      @for (tab of tabs(); track tab.id; let i = $index) {
        <button
          type="button"
          role="tab"
          class="bd-tabs__tab"
          [id]="'bd-tab-' + tab.id"
          [class.is-active]="active() === tab.id"
          [attr.aria-selected]="active() === tab.id"
          [attr.aria-controls]="'bd-panel-' + tab.id"
          [attr.tabindex]="active() === tab.id ? 0 : -1"
          [disabled]="tab.disabled || null"
          (click)="select(tab)"
          (keydown)="onKeydown($event, i)"
        >
          @if (tab.icon) {
            <i [class]="tab.icon" aria-hidden="true"></i>
          }
          {{ tab.label }}
        </button>
      }
    </div>
  `, styles: [".bd-tabs{display:flex;flex-wrap:wrap;gap:var(--bd-space-2, .5rem)}.bd-tabs__tab{display:inline-flex;align-items:center;gap:var(--bd-space-2, .5rem);min-height:44px;padding:.55rem 1.15rem;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-full, 9999px);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:.92rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,transform var(--bd-duration-fast, .15s) var(--bd-ease, ease)}.bd-tabs__tab:hover:not(:disabled){color:var(--bd-fg, #10131c);border-color:var(--bd-border-strong, #cbd2e2);transform:translateY(-2px)}.bd-tabs__tab:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-tabs__tab:disabled{opacity:.5;cursor:not-allowed}.bd-tabs__tab.is-active{background:var(--bd-primary-soft, rgba(61, 92, 232, .1));border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}@media(prefers-reduced-motion:reduce){.bd-tabs__tab,.bd-tabs__tab:hover:not(:disabled){transition:none;transform:none}}\n"] }]
        }], propDecorators: { tabs: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabs", required: true }] }], active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: true }] }, { type: i0.Output, args: ["activeChange"] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/** Reticências na sequência de páginas. */
const GAP = '…';
/**
 * Paginação de listagens e tabelas.
 *
 * A sequência de páginas é condensada com reticências quando o total é grande:
 * exibir cem botões não ajuda ninguém a navegar. As extremidades e a vizinhança
 * da página corrente permanecem sempre acessíveis, que é o que se usa na
 * prática.
 *
 * O elemento é um `<nav>` com rótulo, e a página corrente é marcada com
 * `aria-current="page"` — a posição é anunciada, não apenas destacada.
 *
 * @example
 * ```html
 * <bd-pagination
 *   [total]="240"
 *   [(page)]="pagina"
 *   [(pageSize)]="tamanho"
 *   (paginate)="carregar($event)"
 * />
 * ```
 */
class BdPaginationComponent {
    /** Total de registros. */
    total = input.required(...(ngDevMode ? [{ debugName: "total" }] : []));
    /** Two-way com o índice da página, começando em 0. */
    page = model(0, ...(ngDevMode ? [{ debugName: "page" }] : []));
    pageSize = model(20, ...(ngDevMode ? [{ debugName: "pageSize" }] : []));
    pageSizeOptions = input([20], ...(ngDevMode ? [{ debugName: "pageSizeOptions" }] : []));
    /** Quantidade de páginas exibidas de cada lado da corrente. */
    siblings = input(1, ...(ngDevMode ? [{ debugName: "siblings" }] : []));
    label = input('Paginação', ...(ngDevMode ? [{ debugName: "label" }] : []));
    pageLabel = input('Página', ...(ngDevMode ? [{ debugName: "pageLabel" }] : []));
    previousLabel = input('Página anterior', ...(ngDevMode ? [{ debugName: "previousLabel" }] : []));
    nextLabel = input('Próxima página', ...(ngDevMode ? [{ debugName: "nextLabel" }] : []));
    pageSizeLabel = input('Por página', ...(ngDevMode ? [{ debugName: "pageSizeLabel" }] : []));
    /** Recebe (primeiro, último, total) — ex.: "21–40 de 240". */
    summaryText = input((from, to, total) => `${from}–${to} de ${total}`, ...(ngDevMode ? [{ debugName: "summaryText" }] : []));
    /**
     * Emitido a cada navegação, com página e tamanho já resolvidos.
     *
     * Deliberadamente **não** se chama `pageChange`: esse nome pertence ao output
     * implícito do `model page`, e reutilizá-lo faria a sintaxe `[(page)]`
     * escrever este objeto na variável do consumidor.
     */
    paginate = output();
    gap = GAP;
    pageCount = computed(() => Math.max(1, Math.ceil(this.total() / Math.max(1, this.pageSize()))), ...(ngDevMode ? [{ debugName: "pageCount" }] : []));
    isFirst = computed(() => this.page() <= 0, ...(ngDevMode ? [{ debugName: "isFirst" }] : []));
    isLast = computed(() => this.page() >= this.pageCount() - 1, ...(ngDevMode ? [{ debugName: "isLast" }] : []));
    summary = computed(() => {
        const total = this.total();
        if (total === 0)
            return this.summaryText()(0, 0, 0);
        const from = this.page() * this.pageSize() + 1;
        const to = Math.min(total, from + this.pageSize() - 1);
        return this.summaryText()(from, to, total);
    }, ...(ngDevMode ? [{ debugName: "summary" }] : []));
    /**
     * Sequência condensada de páginas: primeira, vizinhança da corrente, última,
     * com reticências onde há salto.
     */
    sequence = computed(() => {
        const count = this.pageCount();
        const current = this.page();
        const siblings = Math.max(0, this.siblings());
        // Até sete páginas cabem inteiras — condensar aqui só atrapalharia.
        if (count <= 7)
            return range(0, count - 1);
        const start = Math.max(1, current - siblings);
        const end = Math.min(count - 2, current + siblings);
        const items = [0];
        if (start > 1)
            items.push(GAP);
        items.push(...range(start, end));
        if (end < count - 2)
            items.push(GAP);
        items.push(count - 1);
        return items;
    }, ...(ngDevMode ? [{ debugName: "sequence" }] : []));
    goTo(page) {
        const target = Math.min(Math.max(0, page), this.pageCount() - 1);
        if (target === this.page())
            return;
        this.page.set(target);
        this.paginate.emit({ page: target, pageSize: this.pageSize() });
    }
    onPageSizeChange(event) {
        const size = Number(event.target.value);
        if (!Number.isFinite(size) || size <= 0)
            return;
        this.pageSize.set(size);
        // Ao mudar o tamanho, a página corrente pode deixar de existir; volta-se
        // ao início, que é o comportamento previsível.
        this.page.set(0);
        this.paginate.emit({ page: 0, pageSize: size });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdPaginationComponent, isStandalone: true, selector: "bd-pagination", inputs: { total: { classPropertyName: "total", publicName: "total", isSignal: true, isRequired: true, transformFunction: null }, page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, pageSize: { classPropertyName: "pageSize", publicName: "pageSize", isSignal: true, isRequired: false, transformFunction: null }, pageSizeOptions: { classPropertyName: "pageSizeOptions", publicName: "pageSizeOptions", isSignal: true, isRequired: false, transformFunction: null }, siblings: { classPropertyName: "siblings", publicName: "siblings", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, pageLabel: { classPropertyName: "pageLabel", publicName: "pageLabel", isSignal: true, isRequired: false, transformFunction: null }, previousLabel: { classPropertyName: "previousLabel", publicName: "previousLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, pageSizeLabel: { classPropertyName: "pageSizeLabel", publicName: "pageSizeLabel", isSignal: true, isRequired: false, transformFunction: null }, summaryText: { classPropertyName: "summaryText", publicName: "summaryText", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { page: "pageChange", pageSize: "pageSizeChange", paginate: "paginate" }, ngImport: i0, template: `
    <nav class="bd-pagination" [attr.aria-label]="label()">
      <p class="bd-pagination__summary">{{ summary() }}</p>

      <div class="bd-pagination__controls">
        @if (pageSizeOptions().length > 1) {
          <label class="bd-pagination__size">
            <span>{{ pageSizeLabel() }}</span>
            <select [value]="pageSize()" (change)="onPageSizeChange($event)">
              @for (option of pageSizeOptions(); track option) {
                <option [value]="option">{{ option }}</option>
              }
            </select>
          </label>
        }

        <button
          type="button"
          class="bd-pagination__btn"
          [disabled]="isFirst()"
          [attr.aria-label]="previousLabel()"
          (click)="goTo(page() - 1)"
        >
          ‹
        </button>

        @for (item of sequence(); track $index) {
          @if (item === gap) {
            <span class="bd-pagination__gap" aria-hidden="true">{{ gap }}</span>
          } @else {
            <button
              type="button"
              class="bd-pagination__btn bd-pagination__btn--page"
              [class.is-active]="item === page()"
              [attr.aria-current]="item === page() ? 'page' : null"
              [attr.aria-label]="pageLabel() + ' ' + (+item + 1)"
              (click)="goTo(+item)"
            >
              {{ +item + 1 }}
            </button>
          }
        }

        <button
          type="button"
          class="bd-pagination__btn"
          [disabled]="isLast()"
          [attr.aria-label]="nextLabel()"
          (click)="goTo(page() + 1)"
        >
          ›
        </button>
      </div>
    </nav>
  `, isInline: true, styles: [":host{display:block}.bd-pagination{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem)}.bd-pagination__summary{margin:0;color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem);font-variant-numeric:tabular-nums}.bd-pagination__controls{display:flex;align-items:center;gap:.25rem}.bd-pagination__size{display:flex;align-items:center;gap:.4rem;margin-right:var(--bd-space-3, .75rem);color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem)}.bd-pagination__size select{padding:.3rem .4rem;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font:inherit;cursor:pointer}.bd-pagination__size select:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-pagination__btn{display:grid;place-items:center;min-width:36px;height:36px;padding-inline:.5rem;background:transparent;border:1px solid transparent;border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:.88rem;font-weight:var(--bd-weight-semibold, 600);font-variant-numeric:tabular-nums;cursor:pointer;transition:background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}.bd-pagination__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-pagination__btn:disabled{opacity:.45;cursor:not-allowed}.bd-pagination__btn.is-active{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-pagination__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-pagination__gap{padding-inline:.25rem;color:var(--bd-fg-subtle, #7b8399)}@media(prefers-reduced-motion:reduce){.bd-pagination__btn{transition:none}}@media(max-width:640px){.bd-pagination{justify-content:center}.bd-pagination__btn--page:not(.is-active){display:none}.bd-pagination__gap{display:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-pagination', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <nav class="bd-pagination" [attr.aria-label]="label()">
      <p class="bd-pagination__summary">{{ summary() }}</p>

      <div class="bd-pagination__controls">
        @if (pageSizeOptions().length > 1) {
          <label class="bd-pagination__size">
            <span>{{ pageSizeLabel() }}</span>
            <select [value]="pageSize()" (change)="onPageSizeChange($event)">
              @for (option of pageSizeOptions(); track option) {
                <option [value]="option">{{ option }}</option>
              }
            </select>
          </label>
        }

        <button
          type="button"
          class="bd-pagination__btn"
          [disabled]="isFirst()"
          [attr.aria-label]="previousLabel()"
          (click)="goTo(page() - 1)"
        >
          ‹
        </button>

        @for (item of sequence(); track $index) {
          @if (item === gap) {
            <span class="bd-pagination__gap" aria-hidden="true">{{ gap }}</span>
          } @else {
            <button
              type="button"
              class="bd-pagination__btn bd-pagination__btn--page"
              [class.is-active]="item === page()"
              [attr.aria-current]="item === page() ? 'page' : null"
              [attr.aria-label]="pageLabel() + ' ' + (+item + 1)"
              (click)="goTo(+item)"
            >
              {{ +item + 1 }}
            </button>
          }
        }

        <button
          type="button"
          class="bd-pagination__btn"
          [disabled]="isLast()"
          [attr.aria-label]="nextLabel()"
          (click)="goTo(page() + 1)"
        >
          ›
        </button>
      </div>
    </nav>
  `, styles: [":host{display:block}.bd-pagination{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem)}.bd-pagination__summary{margin:0;color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem);font-variant-numeric:tabular-nums}.bd-pagination__controls{display:flex;align-items:center;gap:.25rem}.bd-pagination__size{display:flex;align-items:center;gap:.4rem;margin-right:var(--bd-space-3, .75rem);color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem)}.bd-pagination__size select{padding:.3rem .4rem;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font:inherit;cursor:pointer}.bd-pagination__size select:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-pagination__btn{display:grid;place-items:center;min-width:36px;height:36px;padding-inline:.5rem;background:transparent;border:1px solid transparent;border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-muted, #545c70);font-family:inherit;font-size:.88rem;font-weight:var(--bd-weight-semibold, 600);font-variant-numeric:tabular-nums;cursor:pointer;transition:background var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}.bd-pagination__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-pagination__btn:disabled{opacity:.45;cursor:not-allowed}.bd-pagination__btn.is-active{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-pagination__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-pagination__gap{padding-inline:.25rem;color:var(--bd-fg-subtle, #7b8399)}@media(prefers-reduced-motion:reduce){.bd-pagination__btn{transition:none}}@media(max-width:640px){.bd-pagination{justify-content:center}.bd-pagination__btn--page:not(.is-active){display:none}.bd-pagination__gap{display:none}}\n"] }]
        }], propDecorators: { total: [{ type: i0.Input, args: [{ isSignal: true, alias: "total", required: true }] }], page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }, { type: i0.Output, args: ["pageChange"] }], pageSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSize", required: false }] }, { type: i0.Output, args: ["pageSizeChange"] }], pageSizeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeOptions", required: false }] }], siblings: [{ type: i0.Input, args: [{ isSignal: true, alias: "siblings", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], pageLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageLabel", required: false }] }], previousLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], pageSizeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageSizeLabel", required: false }] }], summaryText: [{ type: i0.Input, args: [{ isSignal: true, alias: "summaryText", required: false }] }], paginate: [{ type: i0.Output, args: ["paginate"] }] } });
function range(from, to) {
    return Array.from({ length: Math.max(0, to - from + 1) }, (_, index) => from + index);
}

/** Largura das colunas de controle (seleção e expansão). */
const CONTROL_WIDTH = 44;
/**
 * Tabela de dados.
 *
 * ## Semântica
 *
 * A estrutura usa papéis ARIA (`table`, `rowgroup`, `row`, `columnheader`,
 * `cell`) sobre uma grade CSS, e não os elementos `<table>` nativos. A escolha
 * é deliberada: uma tabela nativa não pode ter suas linhas virtualizadas sem
 * quebrar o modelo de layout, e a virtualização é o que torna viável exibir
 * dezenas de milhares de linhas. Os papéis entregam ao leitor de tela a mesma
 * informação que a tabela nativa entregaria.
 *
 * ## Custo de renderização
 *
 * - Detecção de mudanças `OnPush` e estado em signals: uma alteração de página
 *   ou de ordenação não propaga verificação para o resto da aplicação.
 * - `track` obrigatório via {@link trackBy} — sem identidade estável, cada
 *   atualização destrói e recria todas as linhas do DOM.
 * - Ordenação no cliente derivada em `computed`: reordena apenas quando as
 *   linhas ou o critério mudam, nunca a cada ciclo de detecção.
 * - Com `virtual`, apenas as linhas visíveis existem no DOM. O custo de
 *   renderização passa a ser função da altura da janela, não do tamanho do
 *   conjunto de dados.
 *
 * ## Volume de dados
 *
 * | Linhas          | Configuração recomendada                          |
 * | --------------- | ------------------------------------------------- |
 * | até ~200        | padrão, ordenação no cliente                      |
 * | ~200 a ~2.000   | `virtual` com `viewportHeight`                    |
 * | acima disso     | `sortMode="server"` com paginação ou `(loadMore)`  |
 *
 * ## Combinações incompatíveis
 *
 * `virtual` pressupõe altura de linha uniforme, e por isso não se combina com
 * `expandable` nem com `wrap` — ambos tornam a altura dependente do conteúdo.
 * Para conjuntos grandes que também precisam de detalhe, pagine em vez de
 * virtualizar.
 *
 * @example
 * ```html
 * <bd-table
 *   [columns]="colunas"
 *   [rows]="projetos()"
 *   [trackBy]="rastrear"
 *   [(sort)]="ordenacao"
 *   [loading]="carregando()"
 *   (rowClick)="abrir($event)"
 * />
 * ```
 */
class BdTableComponent {
    columns = input.required(...(ngDevMode ? [{ debugName: "columns" }] : []));
    rows = input([], ...(ngDevMode ? [{ debugName: "rows" }] : []));
    /**
     * Identidade estável das linhas. O padrão usa o índice, o que é correto
     * apenas para listas imutáveis: com dados que mudam de ordem, forneça uma
     * chave real para evitar a recriação de todo o corpo da tabela.
     */
    trackBy = input((index) => index, ...(ngDevMode ? [{ debugName: "trackBy" }] : []));
    /** Two-way com o critério de ordenação. `null` significa ordem original. */
    sort = model(null, ...(ngDevMode ? [{ debugName: "sort" }] : []));
    /**
     * `client` reordena as linhas recebidas; `server` apenas emite
     * `(sortChange)` e mantém a ordem em que os dados chegaram.
     */
    sortMode = input('client', ...(ngDevMode ? [{ debugName: "sortMode" }] : []));
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    placeholderCount = input(6, ...(ngDevMode ? [{ debugName: "placeholderCount" }] : []));
    /** Habilita a coluna de seleção. */
    selectable = input(false, ...(ngDevMode ? [{ debugName: "selectable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Two-way com o conjunto de linhas selecionadas. */
    selection = model([], ...(ngDevMode ? [{ debugName: "selection" }] : []));
    /** Renderiza apenas as linhas visíveis. Exige altura de linha uniforme. */
    virtual = input(false, ...(ngDevMode ? [{ debugName: "virtual", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    rowHeight = input(48, ...(ngDevMode ? [{ debugName: "rowHeight" }] : []));
    viewportHeight = input(420, ...(ngDevMode ? [{ debugName: "viewportHeight" }] : []));
    density = input('default', ...(ngDevMode ? [{ debugName: "density" }] : []));
    /** Alterna o fundo das linhas, ajudando a percorrer tabelas largas. */
    striped = input(false, ...(ngDevMode ? [{ debugName: "striped", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Permite que as células quebrem em várias linhas. A altura passa a depender
     * do conteúdo, o que é incompatível com `virtual` — as duas são exclusivas.
     */
    wrap = input(false, ...(ngDevMode ? [{ debugName: "wrap", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /**
     * Habilita a linha de detalhe, revelada pelo botão no início da linha.
     *
     * O detalhe é renderizado como uma linha irmã que ocupa toda a largura, e não
     * ampliando a linha original: alterar a altura de uma linha desalinharia as
     * colunas de todas as demais. Como a altura deixa de ser uniforme, a expansão
     * não é combinável com `virtual`.
     */
    expandable = input(false, ...(ngDevMode ? [{ debugName: "expandable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Two-way com as linhas expandidas. */
    expanded = model([], ...(ngDevMode ? [{ debugName: "expanded" }] : []));
    /** Total de registros no servidor, quando maior que o conjunto exibido. */
    totalCount = input(null, ...(ngDevMode ? [{ debugName: "totalCount" }] : []));
    label = input('Tabela de dados', ...(ngDevMode ? [{ debugName: "label" }] : []));
    emptyLabel = input('Nenhum registro encontrado.', ...(ngDevMode ? [{ debugName: "emptyLabel" }] : []));
    loadingLabel = input('Carregando registros…', ...(ngDevMode ? [{ debugName: "loadingLabel" }] : []));
    selectAllLabel = input('Selecionar todas as linhas', ...(ngDevMode ? [{ debugName: "selectAllLabel" }] : []));
    selectRowLabel = input('Selecionar linha', ...(ngDevMode ? [{ debugName: "selectRowLabel" }] : []));
    expandColumnLabel = input('Detalhes', ...(ngDevMode ? [{ debugName: "expandColumnLabel" }] : []));
    expandLabel = input('Mostrar detalhes da linha', ...(ngDevMode ? [{ debugName: "expandLabel" }] : []));
    collapseLabel = input('Ocultar detalhes da linha', ...(ngDevMode ? [{ debugName: "collapseLabel" }] : []));
    /** Conteúdo do estado vazio, quando um texto não basta. */
    emptyTemplate = contentChild('bdTableEmpty', ...(ngDevMode ? [{ debugName: "emptyTemplate" }] : []));
    /** Conteúdo da linha de detalhe. Recebe a linha como contexto implícito. */
    detailTemplate = contentChild('bdTableRowDetail', ...(ngDevMode ? [{ debugName: "detailTemplate" }] : []));
    rowClick = output();
    sortChange = output();
    /** Emitido ao abrir ou fechar uma linha, com o conjunto expandido resultante. */
    expandedChangeRows = output();
    /**
     * Emitido no modo virtual quando a rolagem se aproxima do fim da lista.
     * Use para carregar a página seguinte sob demanda.
     */
    loadMore = output();
    /** Linhas efetivamente renderizadas, já ordenadas quando `sortMode` é `client`. */
    visibleRows = computed(() => {
        const rows = this.rows();
        const sort = this.sort();
        if (this.sortMode() === 'server' || !sort)
            return rows;
        const column = this.columns().find((candidate) => candidate.key === sort.key);
        if (!column)
            return rows;
        const factor = sort.direction === 'asc' ? 1 : -1;
        // Cópia antes de ordenar: `sort` altera o array no lugar, e a entrada
        // pertence a quem a forneceu.
        return [...rows].sort((a, b) => {
            const left = this.sortKey(column, a);
            const right = this.sortKey(column, b);
            // Vazios ficam no fim nas duas direções: uma coluna com lacunas ordenada
            // de forma decrescente não deve começar por elas. Por isso a decisão é
            // tomada antes de aplicar o fator de direção.
            const emptiness = compareEmptiness(left, right);
            if (emptiness !== null)
                return emptiness;
            return factor * compare(left, right);
        });
    }, ...(ngDevMode ? [{ debugName: "visibleRows" }] : []));
    placeholderRows = computed(() => Array.from({ length: Math.max(1, this.placeholderCount()) }, (_, index) => index), ...(ngDevMode ? [{ debugName: "placeholderRows" }] : []));
    gridTemplate = computed(() => {
        const tracks = this.columns().map((column) => column.width ?? 'minmax(120px, 1fr)');
        if (this.selectable())
            tracks.unshift(`${CONTROL_WIDTH}px`);
        if (this.expandable())
            tracks.unshift(`${CONTROL_WIDTH}px`);
        return tracks.join(' ');
    }, ...(ngDevMode ? [{ debugName: "gridTemplate" }] : []));
    /* -------------------------------------------------------- colunas fixas */
    hasFrozenStart = computed(() => this.columns().some((column) => column.frozen === 'start'), ...(ngDevMode ? [{ debugName: "hasFrozenStart" }] : []));
    expandOffset = computed(() => 0, ...(ngDevMode ? [{ debugName: "expandOffset" }] : []));
    selectOffset = computed(() => (this.expandable() ? CONTROL_WIDTH : 0), ...(ngDevMode ? [{ debugName: "selectOffset" }] : []));
    /** Largura ocupada pelas colunas de controle, que precedem as demais. */
    controlsWidth = computed(() => (this.expandable() ? CONTROL_WIDTH : 0) + (this.selectable() ? CONTROL_WIDTH : 0), ...(ngDevMode ? [{ debugName: "controlsWidth" }] : []));
    /**
     * Deslocamento acumulado de cada coluna fixa, por chave.
     *
     * Colunas fixas ao início acumulam da esquerda; ao fim, da direita. O cálculo
     * exige largura em pixels — uma trilha flexível não tem largura conhecida
     * antes do layout, e um deslocamento errado empilharia as colunas umas sobre
     * as outras.
     */
    frozenOffsets = computed(() => {
        const offsets = new Map();
        const columns = this.columns();
        let left = this.controlsWidth();
        for (const column of columns) {
            if (column.frozen !== 'start')
                continue;
            offsets.set(column.key, left);
            left += pixelWidth(column);
        }
        let right = 0;
        for (let i = columns.length - 1; i >= 0; i--) {
            const column = columns[i];
            if (column.frozen !== 'end')
                continue;
            offsets.set(column.key, right);
            right += pixelWidth(column);
        }
        return offsets;
    }, ...(ngDevMode ? [{ debugName: "frozenOffsets" }] : []));
    /** Última coluna fixa de cada lado: é nela que a borda de separação vai. */
    frozenEdges = computed(() => {
        const columns = this.columns();
        const start = columns.filter((column) => column.frozen === 'start').at(-1);
        const end = columns.filter((column) => column.frozen === 'end').at(0);
        return { start: start?.key, end: end?.key };
    }, ...(ngDevMode ? [{ debugName: "frozenEdges" }] : []));
    allSelected = computed(() => {
        const rows = this.visibleRows();
        return rows.length > 0 && this.selection().length === rows.length;
    }, ...(ngDevMode ? [{ debugName: "allSelected" }] : []));
    someSelected = computed(() => {
        const count = this.selection().length;
        return count > 0 && count < this.visibleRows().length;
    }, ...(ngDevMode ? [{ debugName: "someSelected" }] : []));
    hasFooter = computed(() => this.columns().some((column) => !!column.footer), ...(ngDevMode ? [{ debugName: "hasFooter" }] : []));
    frozenStartOffset(column) {
        return column.frozen === 'start' ? (this.frozenOffsets().get(column.key) ?? 0) : null;
    }
    frozenEndOffset(column) {
        return column.frozen === 'end' ? (this.frozenOffsets().get(column.key) ?? 0) : null;
    }
    isFrozenEdge(column) {
        const edges = this.frozenEdges();
        return column.key === edges.start || column.key === edges.end;
    }
    footerValue(column) {
        const raw = column.footer?.(this.visibleRows());
        return raw === null || raw === undefined ? '' : String(raw);
    }
    isExpanded(row) {
        return this.expanded().includes(row);
    }
    toggleExpanded(row) {
        const expanded = this.expanded();
        const next = expanded.includes(row)
            ? expanded.filter((candidate) => candidate !== row)
            : [...expanded, row];
        this.expanded.set(next);
        this.expandedChangeRows.emit(next);
    }
    display(column, row) {
        const raw = column.value ? column.value(row) : row[column.key];
        return raw === null || raw === undefined ? '' : String(raw);
    }
    ariaSortFor(column) {
        if (!column.sortable)
            return null;
        const sort = this.sort();
        if (sort?.key !== column.key)
            return 'none';
        return sort.direction === 'asc' ? 'ascending' : 'descending';
    }
    sortGlyphFor(column) {
        const sort = this.sort();
        if (sort?.key !== column.key)
            return '↕';
        return sort.direction === 'asc' ? '↑' : '↓';
    }
    /** Alterna entre ascendente, descendente e sem ordenação. */
    toggleSort(column) {
        if (!column.sortable)
            return;
        const current = this.sort();
        let next;
        if (current?.key !== column.key) {
            next = { key: column.key, direction: 'asc' };
        }
        else if (current.direction === 'asc') {
            next = { key: column.key, direction: 'desc' };
        }
        else {
            next = null;
        }
        this.sort.set(next);
        this.sortChange.emit(next);
    }
    isSelected(row) {
        return this.selection().includes(row);
    }
    toggleRow(row) {
        const selection = this.selection();
        this.selection.set(selection.includes(row)
            ? selection.filter((candidate) => candidate !== row)
            : [...selection, row]);
    }
    toggleAll() {
        this.selection.set(this.allSelected() ? [] : [...this.visibleRows()]);
    }
    onRowClick(row) {
        this.rowClick.emit(row);
    }
    onScrolledIndexChange(index) {
        const total = this.visibleRows().length;
        const perScreen = Math.ceil(this.viewportHeight() / this.rowHeight());
        // Antecipa em uma tela: os dados chegam antes de o usuário ver o fim.
        if (total > 0 && index + perScreen * 2 >= total) {
            this.loadMore.emit();
        }
    }
    sortKey(column, row) {
        if (column.sortValue)
            return column.sortValue(row);
        if (column.value)
            return column.value(row);
        return row[column.key];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdTableComponent, isStandalone: true, selector: "bd-table", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: true, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, trackBy: { classPropertyName: "trackBy", publicName: "trackBy", isSignal: true, isRequired: false, transformFunction: null }, sort: { classPropertyName: "sort", publicName: "sort", isSignal: true, isRequired: false, transformFunction: null }, sortMode: { classPropertyName: "sortMode", publicName: "sortMode", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, placeholderCount: { classPropertyName: "placeholderCount", publicName: "placeholderCount", isSignal: true, isRequired: false, transformFunction: null }, selectable: { classPropertyName: "selectable", publicName: "selectable", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, virtual: { classPropertyName: "virtual", publicName: "virtual", isSignal: true, isRequired: false, transformFunction: null }, rowHeight: { classPropertyName: "rowHeight", publicName: "rowHeight", isSignal: true, isRequired: false, transformFunction: null }, viewportHeight: { classPropertyName: "viewportHeight", publicName: "viewportHeight", isSignal: true, isRequired: false, transformFunction: null }, density: { classPropertyName: "density", publicName: "density", isSignal: true, isRequired: false, transformFunction: null }, striped: { classPropertyName: "striped", publicName: "striped", isSignal: true, isRequired: false, transformFunction: null }, wrap: { classPropertyName: "wrap", publicName: "wrap", isSignal: true, isRequired: false, transformFunction: null }, expandable: { classPropertyName: "expandable", publicName: "expandable", isSignal: true, isRequired: false, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null }, totalCount: { classPropertyName: "totalCount", publicName: "totalCount", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, loadingLabel: { classPropertyName: "loadingLabel", publicName: "loadingLabel", isSignal: true, isRequired: false, transformFunction: null }, selectAllLabel: { classPropertyName: "selectAllLabel", publicName: "selectAllLabel", isSignal: true, isRequired: false, transformFunction: null }, selectRowLabel: { classPropertyName: "selectRowLabel", publicName: "selectRowLabel", isSignal: true, isRequired: false, transformFunction: null }, expandColumnLabel: { classPropertyName: "expandColumnLabel", publicName: "expandColumnLabel", isSignal: true, isRequired: false, transformFunction: null }, expandLabel: { classPropertyName: "expandLabel", publicName: "expandLabel", isSignal: true, isRequired: false, transformFunction: null }, collapseLabel: { classPropertyName: "collapseLabel", publicName: "collapseLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { sort: "sortChange", selection: "selectionChange", expanded: "expandedChange", rowClick: "rowClick", sortChange: "sortChange", expandedChangeRows: "expandedChangeRows", loadMore: "loadMore" }, queries: [{ propertyName: "emptyTemplate", first: true, predicate: ["bdTableEmpty"], descendants: true, isSignal: true }, { propertyName: "detailTemplate", first: true, predicate: ["bdTableRowDetail"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      class="bd-table"
      role="table"
      [attr.aria-label]="label()"
      [attr.aria-rowcount]="totalCount() ?? visibleRows().length"
      [attr.aria-busy]="loading()"
      [class.bd-table--compact]="density() === 'compact'"
      [class.bd-table--striped]="striped()"
      [class.bd-table--wrap]="wrap()"
      [style.--bd-table-columns]="gridTemplate()"
    >
      <div class="bd-table__head" role="rowgroup">
        <div class="bd-table__row bd-table__row--head" role="row">
          @if (expandable()) {
            <span
              class="bd-table__cell bd-table__cell--control"
              role="columnheader"
              [class.is-frozen]="hasFrozenStart()"
              [style.left.px]="expandOffset()"
            >
              <span class="bd-table__sr">{{ expandColumnLabel() }}</span>
            </span>
          }

          @if (selectable()) {
            <span
              class="bd-table__cell bd-table__cell--control"
              role="columnheader"
              [class.is-frozen]="hasFrozenStart()"
              [style.left.px]="selectOffset()"
            >
              <input
                type="checkbox"
                [attr.aria-label]="selectAllLabel()"
                [checked]="allSelected()"
                [indeterminate]="someSelected()"
                (change)="toggleAll()"
              />
            </span>
          }

          @for (column of columns(); track column.key) {
            <span
              class="bd-table__cell bd-table__cell--head"
              role="columnheader"
              [class]="'bd-table__cell--' + (column.align ?? 'start')"
              [class.bd-table__cell--secondary]="column.secondary"
              [class.is-frozen]="!!column.frozen"
              [class.is-frozen-edge]="isFrozenEdge(column)"
              [style.left.px]="frozenStartOffset(column)"
              [style.right.px]="frozenEndOffset(column)"
              [attr.aria-sort]="ariaSortFor(column)"
            >
              @if (column.sortable) {
                <button type="button" class="bd-table__sort" (click)="toggleSort(column)">
                  {{ column.header }}
                  <span class="bd-table__sort-glyph" aria-hidden="true">
                    {{ sortGlyphFor(column) }}
                  </span>
                </button>
              } @else {
                {{ column.header }}
              }
            </span>
          }
        </div>
      </div>

      @if (loading()) {
        <div class="bd-table__body" role="rowgroup">
          @for (placeholder of placeholderRows(); track placeholder) {
            <div class="bd-table__row" role="row">
              <span class="bd-table__cell" [style.grid-column]="'1 / -1'" role="cell">
                <bd-skeleton variant="text" width="100%" />
              </span>
            </div>
          }
        </div>
        <span class="bd-table__sr" role="status">{{ loadingLabel() }}</span>
      } @else if (!visibleRows().length) {
        <div class="bd-table__empty" role="row">
          <span role="cell">
            @if (emptyTemplate()) {
              <ng-container [ngTemplateOutlet]="emptyTemplate()!" />
            } @else {
              {{ emptyLabel() }}
            }
          </span>
        </div>
      } @else if (virtual()) {
        <!-- Somente as linhas visíveis existem no DOM. -->
        <cdk-virtual-scroll-viewport
          class="bd-table__viewport"
          role="rowgroup"
          [itemSize]="rowHeight()"
          [style.height.px]="viewportHeight()"
          (scrolledIndexChange)="onScrolledIndexChange($event)"
        >
          <div
            *cdkVirtualFor="let row of visibleRows(); trackBy: trackBy(); let index = index"
            class="bd-table__row"
            role="row"
            [class.is-selected]="isSelected(row)"
            [style.height.px]="rowHeight()"
            (click)="onRowClick(row)"
          >
            <ng-container
              [ngTemplateOutlet]="cells"
              [ngTemplateOutletContext]="{ $implicit: row }"
            />
          </div>
        </cdk-virtual-scroll-viewport>
      } @else {
        <div class="bd-table__body" role="rowgroup">
          @for (row of visibleRows(); track trackBy()($index, row)) {
            <div
              class="bd-table__row"
              role="row"
              [class.is-selected]="isSelected(row)"
              [class.is-expanded]="isExpanded(row)"
              (click)="onRowClick(row)"
            >
              <ng-container
                [ngTemplateOutlet]="cells"
                [ngTemplateOutletContext]="{ $implicit: row }"
              />
            </div>

            @if (expandable() && isExpanded(row)) {
              <!-- O detalhe é uma linha própria que ocupa toda a largura da
                   grade: ampliar a linha original quebraria o alinhamento das
                   colunas em todas as demais. -->
              <div class="bd-table__detail" role="row">
                <span class="bd-table__detail-cell" role="cell">
                  @if (detailTemplate()) {
                    <ng-container
                      [ngTemplateOutlet]="detailTemplate()!"
                      [ngTemplateOutletContext]="{ $implicit: row }"
                    />
                  }
                </span>
              </div>
            }
          }
        </div>
      }

      @if (hasFooter() && !loading() && visibleRows().length) {
        <div class="bd-table__foot" role="rowgroup">
          <div class="bd-table__row bd-table__row--foot" role="row">
            @if (expandable()) {
              <span class="bd-table__cell bd-table__cell--control" role="cell"></span>
            }
            @if (selectable()) {
              <span class="bd-table__cell bd-table__cell--control" role="cell"></span>
            }

            @for (column of columns(); track column.key) {
              <span
                class="bd-table__cell"
                role="cell"
                [class]="'bd-table__cell--' + (column.align ?? 'start')"
                [class.bd-table__cell--secondary]="column.secondary"
                [class.is-frozen]="!!column.frozen"
                [class.is-frozen-edge]="isFrozenEdge(column)"
                [style.left.px]="frozenStartOffset(column)"
                [style.right.px]="frozenEndOffset(column)"
              >
                {{ footerValue(column) }}
              </span>
            }
          </div>
        </div>
      }
    </div>

    <!-- Corpo da linha, compartilhado entre o modo virtual e o comum. -->
    <ng-template #cells let-row>
      @if (expandable()) {
        <span
          class="bd-table__cell bd-table__cell--control"
          role="cell"
          [class.is-frozen]="hasFrozenStart()"
          [style.left.px]="expandOffset()"
        >
          <button
            type="button"
            class="bd-table__expand"
            [class.is-open]="isExpanded(row)"
            [attr.aria-expanded]="isExpanded(row)"
            [attr.aria-label]="isExpanded(row) ? collapseLabel() : expandLabel()"
            (click)="$event.stopPropagation(); toggleExpanded(row)"
          >
            <span aria-hidden="true">›</span>
          </button>
        </span>
      }

      @if (selectable()) {
        <span
          class="bd-table__cell bd-table__cell--control"
          role="cell"
          [class.is-frozen]="hasFrozenStart()"
          [style.left.px]="selectOffset()"
        >
          <input
            type="checkbox"
            [attr.aria-label]="selectRowLabel()"
            [checked]="isSelected(row)"
            (click)="$event.stopPropagation()"
            (change)="toggleRow(row)"
          />
        </span>
      }

      @for (column of columns(); track column.key) {
        <span
          class="bd-table__cell"
          role="cell"
          [class]="'bd-table__cell--' + (column.align ?? 'start')"
          [class.bd-table__cell--secondary]="column.secondary"
          [class.is-frozen]="!!column.frozen"
          [class.is-frozen-edge]="isFrozenEdge(column)"
          [style.left.px]="frozenStartOffset(column)"
          [style.right.px]="frozenEndOffset(column)"
        >
          {{ display(column, row) }}
        </span>
      }
    </ng-template>
  `, isInline: true, styles: [":host{display:block;--bd-table-row-h: 48px}.bd-table{overflow-x:auto;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem);color:var(--bd-fg, #10131c);font-size:.9rem}.bd-table__row{display:grid;grid-template-columns:var(--bd-table-columns);align-items:center;min-width:100%}.bd-table__row:not(.bd-table__row--head){border-top:1px solid var(--bd-border, #e3e7f0);transition:background var(--bd-duration-fast, .15s) ease}.bd-table__row--head{position:sticky;top:0;z-index:3;background:var(--bd-bg-elevated, #f8fafc)}.bd-table__row--foot{position:sticky;bottom:0;z-index:3;background:var(--bd-bg-elevated, #f8fafc);border-top:1px solid var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c);font-weight:var(--bd-weight-semibold, 600)}.bd-table__row:not(.bd-table__row--head):hover{background:var(--bd-surface-hover, #f1f3f9)}.bd-table__row.is-selected{background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}.bd-table__row.is-expanded{background:var(--bd-bg-elevated, #f8fafc)}.bd-table--striped .bd-table__body>.bd-table__row:nth-child(odd){background:color-mix(in srgb,var(--bd-bg-elevated, #f8fafc) 55%,transparent)}.bd-table__cell{display:flex;align-items:center;min-width:0;padding:.75rem .9rem;color:var(--bd-fg-muted, #545c70);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bd-table--wrap .bd-table__cell{align-items:flex-start;overflow:visible;white-space:normal;line-height:1.5}.bd-table--compact .bd-table__cell{padding:.45rem .75rem}.bd-table__cell--head{color:var(--bd-fg-subtle, #7b8399);font-size:.76rem;font-weight:var(--bd-weight-bold, 700);letter-spacing:.06em;text-transform:uppercase}.bd-table__cell--center{justify-content:center;text-align:center}.bd-table__cell--end{justify-content:flex-end;font-variant-numeric:tabular-nums;text-align:right}.bd-table__cell--control{justify-content:center;padding-inline:.6rem}.bd-table__cell.is-frozen{position:sticky;z-index:2;background:inherit}.bd-table__row:not(.bd-table__row--head):not(.bd-table__row--foot) .bd-table__cell.is-frozen{background:var(--bd-surface, #fff)}.bd-table__row:hover .bd-table__cell.is-frozen{background:var(--bd-surface-hover, #f1f3f9)}.bd-table__row.is-selected .bd-table__cell.is-frozen{background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}.bd-table__row--head .bd-table__cell.is-frozen,.bd-table__row--foot .bd-table__cell.is-frozen{background:var(--bd-bg-elevated, #f8fafc)}.bd-table__cell.is-frozen-edge{box-shadow:inset -1px 0 0 var(--bd-border, #e3e7f0)}.bd-table__cell.is-frozen-edge.bd-table__cell--end{box-shadow:inset 1px 0 0 var(--bd-border, #e3e7f0)}.bd-table__expand{display:grid;place-items:center;width:26px;height:26px;background:transparent;border:none;border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-subtle, #7b8399);font-size:1.15rem;line-height:1;cursor:pointer;transition:transform var(--bd-duration-fast, .15s) ease,color var(--bd-duration-fast, .15s) ease}.bd-table__expand:hover{color:var(--bd-primary, #3d5ce8)}.bd-table__expand.is-open{transform:rotate(90deg);color:var(--bd-primary, #3d5ce8)}.bd-table__expand:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-table__detail{border-top:1px solid var(--bd-border, #e3e7f0);background:var(--bd-bg-elevated, #f8fafc)}.bd-table__detail-cell{display:block;padding:var(--bd-space-4, 1rem) var(--bd-space-5, 1.5rem);color:var(--bd-fg-muted, #545c70)}.bd-table__sort{display:inline-flex;align-items:center;gap:.3rem;padding:0;background:none;border:none;color:inherit;font:inherit;letter-spacing:inherit;text-transform:inherit;cursor:pointer}.bd-table__sort:hover{color:var(--bd-primary, #3d5ce8)}.bd-table__sort:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}.bd-table__sort-glyph{font-size:.9em;opacity:.75}.bd-table__empty{padding:var(--bd-space-7, 3rem) var(--bd-space-5, 1.5rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-subtle, #7b8399);text-align:center}.bd-table__viewport{width:100%}.bd-table__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:720px){.bd-table__cell--secondary{display:none}}@media(prefers-reduced-motion:reduce){.bd-table__row{transition:none}}\n"], dependencies: [{ kind: "ngmodule", type: ScrollingModule }, { kind: "directive", type: i1$1.CdkFixedSizeVirtualScroll, selector: "cdk-virtual-scroll-viewport[itemSize]", inputs: ["itemSize", "minBufferPx", "maxBufferPx"] }, { kind: "directive", type: i1$1.CdkVirtualForOf, selector: "[cdkVirtualFor][cdkVirtualForOf]", inputs: ["cdkVirtualForOf", "cdkVirtualForTrackBy", "cdkVirtualForTemplate", "cdkVirtualForTemplateCacheSize"] }, { kind: "component", type: i1$1.CdkVirtualScrollViewport, selector: "cdk-virtual-scroll-viewport", inputs: ["orientation", "appendOnly"], outputs: ["scrolledIndexChange"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: BdSkeletonComponent, selector: "bd-skeleton", inputs: ["variant", "width", "height"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-table', standalone: true, imports: [ScrollingModule, NgTemplateOutlet, BdSkeletonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <div
      class="bd-table"
      role="table"
      [attr.aria-label]="label()"
      [attr.aria-rowcount]="totalCount() ?? visibleRows().length"
      [attr.aria-busy]="loading()"
      [class.bd-table--compact]="density() === 'compact'"
      [class.bd-table--striped]="striped()"
      [class.bd-table--wrap]="wrap()"
      [style.--bd-table-columns]="gridTemplate()"
    >
      <div class="bd-table__head" role="rowgroup">
        <div class="bd-table__row bd-table__row--head" role="row">
          @if (expandable()) {
            <span
              class="bd-table__cell bd-table__cell--control"
              role="columnheader"
              [class.is-frozen]="hasFrozenStart()"
              [style.left.px]="expandOffset()"
            >
              <span class="bd-table__sr">{{ expandColumnLabel() }}</span>
            </span>
          }

          @if (selectable()) {
            <span
              class="bd-table__cell bd-table__cell--control"
              role="columnheader"
              [class.is-frozen]="hasFrozenStart()"
              [style.left.px]="selectOffset()"
            >
              <input
                type="checkbox"
                [attr.aria-label]="selectAllLabel()"
                [checked]="allSelected()"
                [indeterminate]="someSelected()"
                (change)="toggleAll()"
              />
            </span>
          }

          @for (column of columns(); track column.key) {
            <span
              class="bd-table__cell bd-table__cell--head"
              role="columnheader"
              [class]="'bd-table__cell--' + (column.align ?? 'start')"
              [class.bd-table__cell--secondary]="column.secondary"
              [class.is-frozen]="!!column.frozen"
              [class.is-frozen-edge]="isFrozenEdge(column)"
              [style.left.px]="frozenStartOffset(column)"
              [style.right.px]="frozenEndOffset(column)"
              [attr.aria-sort]="ariaSortFor(column)"
            >
              @if (column.sortable) {
                <button type="button" class="bd-table__sort" (click)="toggleSort(column)">
                  {{ column.header }}
                  <span class="bd-table__sort-glyph" aria-hidden="true">
                    {{ sortGlyphFor(column) }}
                  </span>
                </button>
              } @else {
                {{ column.header }}
              }
            </span>
          }
        </div>
      </div>

      @if (loading()) {
        <div class="bd-table__body" role="rowgroup">
          @for (placeholder of placeholderRows(); track placeholder) {
            <div class="bd-table__row" role="row">
              <span class="bd-table__cell" [style.grid-column]="'1 / -1'" role="cell">
                <bd-skeleton variant="text" width="100%" />
              </span>
            </div>
          }
        </div>
        <span class="bd-table__sr" role="status">{{ loadingLabel() }}</span>
      } @else if (!visibleRows().length) {
        <div class="bd-table__empty" role="row">
          <span role="cell">
            @if (emptyTemplate()) {
              <ng-container [ngTemplateOutlet]="emptyTemplate()!" />
            } @else {
              {{ emptyLabel() }}
            }
          </span>
        </div>
      } @else if (virtual()) {
        <!-- Somente as linhas visíveis existem no DOM. -->
        <cdk-virtual-scroll-viewport
          class="bd-table__viewport"
          role="rowgroup"
          [itemSize]="rowHeight()"
          [style.height.px]="viewportHeight()"
          (scrolledIndexChange)="onScrolledIndexChange($event)"
        >
          <div
            *cdkVirtualFor="let row of visibleRows(); trackBy: trackBy(); let index = index"
            class="bd-table__row"
            role="row"
            [class.is-selected]="isSelected(row)"
            [style.height.px]="rowHeight()"
            (click)="onRowClick(row)"
          >
            <ng-container
              [ngTemplateOutlet]="cells"
              [ngTemplateOutletContext]="{ $implicit: row }"
            />
          </div>
        </cdk-virtual-scroll-viewport>
      } @else {
        <div class="bd-table__body" role="rowgroup">
          @for (row of visibleRows(); track trackBy()($index, row)) {
            <div
              class="bd-table__row"
              role="row"
              [class.is-selected]="isSelected(row)"
              [class.is-expanded]="isExpanded(row)"
              (click)="onRowClick(row)"
            >
              <ng-container
                [ngTemplateOutlet]="cells"
                [ngTemplateOutletContext]="{ $implicit: row }"
              />
            </div>

            @if (expandable() && isExpanded(row)) {
              <!-- O detalhe é uma linha própria que ocupa toda a largura da
                   grade: ampliar a linha original quebraria o alinhamento das
                   colunas em todas as demais. -->
              <div class="bd-table__detail" role="row">
                <span class="bd-table__detail-cell" role="cell">
                  @if (detailTemplate()) {
                    <ng-container
                      [ngTemplateOutlet]="detailTemplate()!"
                      [ngTemplateOutletContext]="{ $implicit: row }"
                    />
                  }
                </span>
              </div>
            }
          }
        </div>
      }

      @if (hasFooter() && !loading() && visibleRows().length) {
        <div class="bd-table__foot" role="rowgroup">
          <div class="bd-table__row bd-table__row--foot" role="row">
            @if (expandable()) {
              <span class="bd-table__cell bd-table__cell--control" role="cell"></span>
            }
            @if (selectable()) {
              <span class="bd-table__cell bd-table__cell--control" role="cell"></span>
            }

            @for (column of columns(); track column.key) {
              <span
                class="bd-table__cell"
                role="cell"
                [class]="'bd-table__cell--' + (column.align ?? 'start')"
                [class.bd-table__cell--secondary]="column.secondary"
                [class.is-frozen]="!!column.frozen"
                [class.is-frozen-edge]="isFrozenEdge(column)"
                [style.left.px]="frozenStartOffset(column)"
                [style.right.px]="frozenEndOffset(column)"
              >
                {{ footerValue(column) }}
              </span>
            }
          </div>
        </div>
      }
    </div>

    <!-- Corpo da linha, compartilhado entre o modo virtual e o comum. -->
    <ng-template #cells let-row>
      @if (expandable()) {
        <span
          class="bd-table__cell bd-table__cell--control"
          role="cell"
          [class.is-frozen]="hasFrozenStart()"
          [style.left.px]="expandOffset()"
        >
          <button
            type="button"
            class="bd-table__expand"
            [class.is-open]="isExpanded(row)"
            [attr.aria-expanded]="isExpanded(row)"
            [attr.aria-label]="isExpanded(row) ? collapseLabel() : expandLabel()"
            (click)="$event.stopPropagation(); toggleExpanded(row)"
          >
            <span aria-hidden="true">›</span>
          </button>
        </span>
      }

      @if (selectable()) {
        <span
          class="bd-table__cell bd-table__cell--control"
          role="cell"
          [class.is-frozen]="hasFrozenStart()"
          [style.left.px]="selectOffset()"
        >
          <input
            type="checkbox"
            [attr.aria-label]="selectRowLabel()"
            [checked]="isSelected(row)"
            (click)="$event.stopPropagation()"
            (change)="toggleRow(row)"
          />
        </span>
      }

      @for (column of columns(); track column.key) {
        <span
          class="bd-table__cell"
          role="cell"
          [class]="'bd-table__cell--' + (column.align ?? 'start')"
          [class.bd-table__cell--secondary]="column.secondary"
          [class.is-frozen]="!!column.frozen"
          [class.is-frozen-edge]="isFrozenEdge(column)"
          [style.left.px]="frozenStartOffset(column)"
          [style.right.px]="frozenEndOffset(column)"
        >
          {{ display(column, row) }}
        </span>
      }
    </ng-template>
  `, styles: [":host{display:block;--bd-table-row-h: 48px}.bd-table{overflow-x:auto;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius, .875rem);color:var(--bd-fg, #10131c);font-size:.9rem}.bd-table__row{display:grid;grid-template-columns:var(--bd-table-columns);align-items:center;min-width:100%}.bd-table__row:not(.bd-table__row--head){border-top:1px solid var(--bd-border, #e3e7f0);transition:background var(--bd-duration-fast, .15s) ease}.bd-table__row--head{position:sticky;top:0;z-index:3;background:var(--bd-bg-elevated, #f8fafc)}.bd-table__row--foot{position:sticky;bottom:0;z-index:3;background:var(--bd-bg-elevated, #f8fafc);border-top:1px solid var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c);font-weight:var(--bd-weight-semibold, 600)}.bd-table__row:not(.bd-table__row--head):hover{background:var(--bd-surface-hover, #f1f3f9)}.bd-table__row.is-selected{background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}.bd-table__row.is-expanded{background:var(--bd-bg-elevated, #f8fafc)}.bd-table--striped .bd-table__body>.bd-table__row:nth-child(odd){background:color-mix(in srgb,var(--bd-bg-elevated, #f8fafc) 55%,transparent)}.bd-table__cell{display:flex;align-items:center;min-width:0;padding:.75rem .9rem;color:var(--bd-fg-muted, #545c70);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bd-table--wrap .bd-table__cell{align-items:flex-start;overflow:visible;white-space:normal;line-height:1.5}.bd-table--compact .bd-table__cell{padding:.45rem .75rem}.bd-table__cell--head{color:var(--bd-fg-subtle, #7b8399);font-size:.76rem;font-weight:var(--bd-weight-bold, 700);letter-spacing:.06em;text-transform:uppercase}.bd-table__cell--center{justify-content:center;text-align:center}.bd-table__cell--end{justify-content:flex-end;font-variant-numeric:tabular-nums;text-align:right}.bd-table__cell--control{justify-content:center;padding-inline:.6rem}.bd-table__cell.is-frozen{position:sticky;z-index:2;background:inherit}.bd-table__row:not(.bd-table__row--head):not(.bd-table__row--foot) .bd-table__cell.is-frozen{background:var(--bd-surface, #fff)}.bd-table__row:hover .bd-table__cell.is-frozen{background:var(--bd-surface-hover, #f1f3f9)}.bd-table__row.is-selected .bd-table__cell.is-frozen{background:var(--bd-primary-soft, rgba(61, 92, 232, .1))}.bd-table__row--head .bd-table__cell.is-frozen,.bd-table__row--foot .bd-table__cell.is-frozen{background:var(--bd-bg-elevated, #f8fafc)}.bd-table__cell.is-frozen-edge{box-shadow:inset -1px 0 0 var(--bd-border, #e3e7f0)}.bd-table__cell.is-frozen-edge.bd-table__cell--end{box-shadow:inset 1px 0 0 var(--bd-border, #e3e7f0)}.bd-table__expand{display:grid;place-items:center;width:26px;height:26px;background:transparent;border:none;border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg-subtle, #7b8399);font-size:1.15rem;line-height:1;cursor:pointer;transition:transform var(--bd-duration-fast, .15s) ease,color var(--bd-duration-fast, .15s) ease}.bd-table__expand:hover{color:var(--bd-primary, #3d5ce8)}.bd-table__expand.is-open{transform:rotate(90deg);color:var(--bd-primary, #3d5ce8)}.bd-table__expand:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-table__detail{border-top:1px solid var(--bd-border, #e3e7f0);background:var(--bd-bg-elevated, #f8fafc)}.bd-table__detail-cell{display:block;padding:var(--bd-space-4, 1rem) var(--bd-space-5, 1.5rem);color:var(--bd-fg-muted, #545c70)}.bd-table__sort{display:inline-flex;align-items:center;gap:.3rem;padding:0;background:none;border:none;color:inherit;font:inherit;letter-spacing:inherit;text-transform:inherit;cursor:pointer}.bd-table__sort:hover{color:var(--bd-primary, #3d5ce8)}.bd-table__sort:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3));border-radius:var(--bd-radius-sm, .5rem)}.bd-table__sort-glyph{font-size:.9em;opacity:.75}.bd-table__empty{padding:var(--bd-space-7, 3rem) var(--bd-space-5, 1.5rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-subtle, #7b8399);text-align:center}.bd-table__viewport{width:100%}.bd-table__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:720px){.bd-table__cell--secondary{display:none}}@media(prefers-reduced-motion:reduce){.bd-table__row{transition:none}}\n"] }]
        }], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: true }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], trackBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "trackBy", required: false }] }], sort: [{ type: i0.Input, args: [{ isSignal: true, alias: "sort", required: false }] }, { type: i0.Output, args: ["sortChange"] }], sortMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortMode", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], placeholderCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderCount", required: false }] }], selectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectable", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }, { type: i0.Output, args: ["selectionChange"] }], virtual: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtual", required: false }] }], rowHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHeight", required: false }] }], viewportHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewportHeight", required: false }] }], density: [{ type: i0.Input, args: [{ isSignal: true, alias: "density", required: false }] }], striped: [{ type: i0.Input, args: [{ isSignal: true, alias: "striped", required: false }] }], wrap: [{ type: i0.Input, args: [{ isSignal: true, alias: "wrap", required: false }] }], expandable: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandable", required: false }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }, { type: i0.Output, args: ["expandedChange"] }], totalCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalCount", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], loadingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingLabel", required: false }] }], selectAllLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAllLabel", required: false }] }], selectRowLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectRowLabel", required: false }] }], expandColumnLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandColumnLabel", required: false }] }], expandLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandLabel", required: false }] }], collapseLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapseLabel", required: false }] }], emptyTemplate: [{ type: i0.ContentChild, args: ['bdTableEmpty', { isSignal: true }] }], detailTemplate: [{ type: i0.ContentChild, args: ['bdTableRowDetail', { isSignal: true }] }], rowClick: [{ type: i0.Output, args: ["rowClick"] }], sortChange: [{ type: i0.Output, args: ["sortChange"] }], expandedChangeRows: [{ type: i0.Output, args: ["expandedChangeRows"] }], loadMore: [{ type: i0.Output, args: ["loadMore"] }] } });
/**
 * Largura em pixels de uma coluna fixa.
 *
 * Sem largura declarada não há como calcular o deslocamento da coluna seguinte;
 * o aviso em desenvolvimento evita o sintoma confuso — colunas empilhadas umas
 * sobre as outras — e aponta a causa.
 */
function pixelWidth(column) {
    const parsed = column.width ? parseFloat(column.width) : NaN;
    if (!Number.isFinite(parsed) || !column.width?.trim().endsWith('px')) {
        if (typeof ngDevMode !== 'undefined' && ngDevMode) {
            console.warn(`[bandeira-ui] A coluna "${column.key}" está fixada com frozen mas não declara ` +
                'width em pixels. Sem largura conhecida, o deslocamento das colunas fixas ' +
                'seguintes não pode ser calculado.');
        }
        return 0;
    }
    return parsed;
}
/**
 * Resolve a ordem quando ao menos um dos valores é vazio.
 *
 * Devolve `null` quando ambos têm conteúdo e a comparação normal deve seguir.
 */
function compareEmptiness(a, b) {
    const aEmpty = a === null || a === undefined || a === '';
    const bEmpty = b === null || b === undefined || b === '';
    if (!aEmpty && !bEmpty)
        return null;
    if (aEmpty && bEmpty)
        return 0;
    return aEmpty ? 1 : -1;
}
/** Comparação estável entre valores heterogêneos, ambos não vazios. */
function compare(a, b) {
    if (a instanceof Date && b instanceof Date)
        return a.getTime() - b.getTime();
    if (typeof a === 'number' && typeof b === 'number')
        return a - b;
    // `localeCompare` com sensibilidade de base: acentuação e caixa não separam
    // registros que o usuário lê como iguais.
    return String(a).localeCompare(String(b), 'pt-BR', { sensitivity: 'base', numeric: true });
}

/**
 * Container base do design system.
 *
 * @example
 * ```html
 * <bd-card>Conteúdo</bd-card>
 * <bd-card interactive padding="lg">Sobe no hover</bd-card>
 * <bd-card dashed>Placeholder / empty state</bd-card>
 * ```
 */
class BdCardComponent {
    padding = input('md', ...(ngDevMode ? [{ debugName: "padding" }] : []));
    /** Aplica elevação e deslocamento no hover. */
    interactive = input(false, ...(ngDevMode ? [{ debugName: "interactive", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Borda tracejada — bom para empty states e placeholders. */
    dashed = input(false, ...(ngDevMode ? [{ debugName: "dashed", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    classes = computed(() => [
        `bd-card--${this.padding()}`,
        this.interactive() ? 'bd-card--interactive' : '',
        this.dashed() ? 'bd-card--dashed' : '',
    ]
        .filter(Boolean)
        .join(' '), ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.27", type: BdCardComponent, isStandalone: true, selector: "bd-card", inputs: { padding: { classPropertyName: "padding", publicName: "padding", isSignal: true, isRequired: false, transformFunction: null }, interactive: { classPropertyName: "interactive", publicName: "interactive", isSignal: true, isRequired: false, transformFunction: null }, dashed: { classPropertyName: "dashed", publicName: "dashed", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `<ng-content />`, isInline: true, styles: [":host{display:block;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-sm, 0 1px 2px rgba(16, 19, 28, .06));color:var(--bd-fg, #10131c);transition:transform var(--bd-duration, .25s) var(--bd-ease, ease),box-shadow var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}:host(.bd-card--none){padding:0}:host(.bd-card--sm){padding:var(--bd-space-4, 1rem)}:host(.bd-card--md){padding:var(--bd-space-5, 1.5rem)}:host(.bd-card--lg){padding:var(--bd-space-6, 2rem)}:host(.bd-card--dashed){border-style:dashed;background:transparent;box-shadow:none}:host(.bd-card--interactive){cursor:pointer}:host(.bd-card--interactive:hover){transform:translateY(-4px);border-color:var(--bd-border-strong, #cbd2e2);box-shadow:var(--bd-shadow-md, 0 8px 24px rgba(16, 19, 28, .08))}@media(prefers-reduced-motion:reduce){:host,:host(.bd-card--interactive:hover){transition:none;transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `<ng-content />`, host: { '[class]': 'classes()' }, styles: [":host{display:block;background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-sm, 0 1px 2px rgba(16, 19, 28, .06));color:var(--bd-fg, #10131c);transition:transform var(--bd-duration, .25s) var(--bd-ease, ease),box-shadow var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}:host(.bd-card--none){padding:0}:host(.bd-card--sm){padding:var(--bd-space-4, 1rem)}:host(.bd-card--md){padding:var(--bd-space-5, 1.5rem)}:host(.bd-card--lg){padding:var(--bd-space-6, 2rem)}:host(.bd-card--dashed){border-style:dashed;background:transparent;box-shadow:none}:host(.bd-card--interactive){cursor:pointer}:host(.bd-card--interactive:hover){transform:translateY(-4px);border-color:var(--bd-border-strong, #cbd2e2);box-shadow:var(--bd-shadow-md, 0 8px 24px rgba(16, 19, 28, .08))}@media(prefers-reduced-motion:reduce){:host,:host(.bd-card--interactive:hover){transition:none;transform:none}}\n"] }]
        }], propDecorators: { padding: [{ type: i0.Input, args: [{ isSignal: true, alias: "padding", required: false }] }], interactive: [{ type: i0.Input, args: [{ isSignal: true, alias: "interactive", required: false }] }], dashed: [{ type: i0.Input, args: [{ isSignal: true, alias: "dashed", required: false }] }] } });

/**
 * Etiqueta compacta para tecnologias, níveis, filtros e status.
 *
 * @example
 * ```html
 * <bd-chip>Angular</bd-chip>
 * <bd-chip tone="accent">avançado</bd-chip>
 * <bd-chip tone="neutral" outlined>rascunho</bd-chip>
 * <bd-chip removable (removed)="tirarFiltro()">TypeScript</bd-chip>
 * ```
 */
class BdChipComponent {
    tone = input('primary', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    outlined = input(false, ...(ngDevMode ? [{ debugName: "outlined", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Mostra o botão de remover. */
    removable = input(false, ...(ngDevMode ? [{ debugName: "removable", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Rótulo acessível do botão de remover. */
    removeLabel = input('Remover', ...(ngDevMode ? [{ debugName: "removeLabel" }] : []));
    /** Emitido ao clicar no botão de remover. */
    removed = output();
    classes = computed(() => [`bd-chip--${this.tone()}`, this.outlined() ? 'bd-chip--outlined' : '']
        .filter(Boolean)
        .join(' '), ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdChipComponent, isStandalone: true, selector: "bd-chip", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, outlined: { classPropertyName: "outlined", publicName: "outlined", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null }, removeLabel: { classPropertyName: "removeLabel", publicName: "removeLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { removed: "removed" }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    <ng-content />
    @if (removable()) {
      <button
        type="button"
        class="bd-chip__remove"
        [attr.aria-label]="removeLabel()"
        (click)="removed.emit()"
      >
        &times;
      </button>
    }
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;gap:var(--bd-space-1, .25rem);padding:.28rem .7rem;border:1px solid transparent;border-radius:var(--bd-radius-full, 9999px);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-semibold, 600);letter-spacing:.01em;line-height:1.4;white-space:nowrap}:host(.bd-chip--primary){background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8)}:host(.bd-chip--accent){background:var(--bd-accent-soft, rgba(13, 148, 136, .1));color:var(--bd-accent, #0d9488)}:host(.bd-chip--neutral){background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}:host(.bd-chip--success){background:var(--bd-success-soft, rgba(22, 163, 74, .1));color:var(--bd-success, #16a34a)}:host(.bd-chip--warning){background:var(--bd-warning-soft, rgba(217, 119, 6, .1));color:var(--bd-warning, #d97706)}:host(.bd-chip--danger){background:var(--bd-danger-soft, rgba(220, 38, 38, .1));color:var(--bd-danger, #dc2626)}:host(.bd-chip--outlined){background:transparent;border-color:currentColor}.bd-chip__remove{display:inline-flex;align-items:center;justify-content:center;width:1.1rem;height:1.1rem;margin-right:-.25rem;padding:0;background:transparent;border:none;border-radius:50%;color:inherit;font-size:1rem;line-height:1;cursor:pointer;opacity:.7;transition:opacity var(--bd-duration-fast, .15s) ease,background var(--bd-duration-fast, .15s) ease}.bd-chip__remove:hover{opacity:1;background:#00000014}.bd-chip__remove:focus-visible{outline:none;opacity:1;box-shadow:0 0 0 2px currentColor}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-chip', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <ng-content />
    @if (removable()) {
      <button
        type="button"
        class="bd-chip__remove"
        [attr.aria-label]="removeLabel()"
        (click)="removed.emit()"
      >
        &times;
      </button>
    }
  `, host: { '[class]': 'classes()' }, styles: [":host{display:inline-flex;align-items:center;gap:var(--bd-space-1, .25rem);padding:.28rem .7rem;border:1px solid transparent;border-radius:var(--bd-radius-full, 9999px);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-semibold, 600);letter-spacing:.01em;line-height:1.4;white-space:nowrap}:host(.bd-chip--primary){background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8)}:host(.bd-chip--accent){background:var(--bd-accent-soft, rgba(13, 148, 136, .1));color:var(--bd-accent, #0d9488)}:host(.bd-chip--neutral){background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}:host(.bd-chip--success){background:var(--bd-success-soft, rgba(22, 163, 74, .1));color:var(--bd-success, #16a34a)}:host(.bd-chip--warning){background:var(--bd-warning-soft, rgba(217, 119, 6, .1));color:var(--bd-warning, #d97706)}:host(.bd-chip--danger){background:var(--bd-danger-soft, rgba(220, 38, 38, .1));color:var(--bd-danger, #dc2626)}:host(.bd-chip--outlined){background:transparent;border-color:currentColor}.bd-chip__remove{display:inline-flex;align-items:center;justify-content:center;width:1.1rem;height:1.1rem;margin-right:-.25rem;padding:0;background:transparent;border:none;border-radius:50%;color:inherit;font-size:1rem;line-height:1;cursor:pointer;opacity:.7;transition:opacity var(--bd-duration-fast, .15s) ease,background var(--bd-duration-fast, .15s) ease}.bd-chip__remove:hover{opacity:1;background:#00000014}.bd-chip__remove:focus-visible{outline:none;opacity:1;box-shadow:0 0 0 2px currentColor}\n"] }]
        }], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], outlined: [{ type: i0.Input, args: [{ isSignal: true, alias: "outlined", required: false }] }], removable: [{ type: i0.Input, args: [{ isSignal: true, alias: "removable", required: false }] }], removeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeLabel", required: false }] }], removed: [{ type: i0.Output, args: ["removed"] }] } });

/**
 * Foto de perfil com fallback para iniciais.
 *
 * Se a imagem falhar, as iniciais entram no lugar — sem ícone quebrado. A cor
 * de fundo é derivada do nome, então a mesma pessoa tem sempre a mesma cor.
 *
 * @example
 * ```html
 * <bd-avatar name="João Pedro Bandeira" src="/user.jpg" />
 * <bd-avatar name="Maria Silva" size="lg" />
 * ```
 */
class BdAvatarComponent {
    name = input('', ...(ngDevMode ? [{ debugName: "name" }] : []));
    src = input('', ...(ngDevMode ? [{ debugName: "src" }] : []));
    size = input('md', ...(ngDevMode ? [{ debugName: "size" }] : []));
    falhou = signal(false, ...(ngDevMode ? [{ debugName: "falhou" }] : []));
    classes = computed(() => `bd-avatar--${this.size()}`, ...(ngDevMode ? [{ debugName: "classes" }] : []));
    /** Primeira letra do primeiro e do último nome. */
    iniciais = computed(() => {
        const partes = this.name().trim().split(/\s+/).filter(Boolean);
        if (!partes.length)
            return '?';
        if (partes.length === 1)
            return partes[0].slice(0, 2);
        return partes[0][0] + partes[partes.length - 1][0];
    }, ...(ngDevMode ? [{ debugName: "iniciais" }] : []));
    /** Matiz derivado do nome: mesma pessoa, mesma cor, sempre. */
    cor = computed(() => {
        const nome = this.name();
        if (!nome)
            return 'var(--bd-fg-subtle, #7b8399)';
        let hash = 0;
        for (let i = 0; i < nome.length; i++) {
            hash = nome.charCodeAt(i) + ((hash << 5) - hash);
        }
        return `hsl(${Math.abs(hash) % 360} 55% 45%)`;
    }, ...(ngDevMode ? [{ debugName: "cor" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdAvatarComponent, isStandalone: true, selector: "bd-avatar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, src: { classPropertyName: "src", publicName: "src", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    @if (src() && !falhou()) {
      <img [src]="src()" [alt]="name()" (error)="falhou.set(true)" />
    } @else {
      <span class="bd-avatar__initials" [style.background]="cor()" [attr.aria-hidden]="!!name()">
        {{ iniciais() }}
      </span>
      @if (name()) {
        <span class="bd-sr-only">{{ name() }}</span>
      }
    }
  `, isInline: true, styles: [":host{display:inline-grid;place-items:center;overflow:hidden;border-radius:50%;background:var(--bd-surface-hover, #f1f3f9);flex-shrink:0}img{width:100%;height:100%;object-fit:cover}.bd-avatar__initials{display:grid;place-items:center;width:100%;height:100%;color:#fff;font-weight:var(--bd-weight-semibold, 600);letter-spacing:.02em;text-transform:uppercase}:host(.bd-avatar--sm){width:28px;height:28px;font-size:.68rem}:host(.bd-avatar--md){width:40px;height:40px;font-size:.85rem}:host(.bd-avatar--lg){width:56px;height:56px;font-size:1.1rem}:host(.bd-avatar--xl){width:88px;height:88px;font-size:1.7rem}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-avatar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (src() && !falhou()) {
      <img [src]="src()" [alt]="name()" (error)="falhou.set(true)" />
    } @else {
      <span class="bd-avatar__initials" [style.background]="cor()" [attr.aria-hidden]="!!name()">
        {{ iniciais() }}
      </span>
      @if (name()) {
        <span class="bd-sr-only">{{ name() }}</span>
      }
    }
  `, host: { '[class]': 'classes()' }, styles: [":host{display:inline-grid;place-items:center;overflow:hidden;border-radius:50%;background:var(--bd-surface-hover, #f1f3f9);flex-shrink:0}img{width:100%;height:100%;object-fit:cover}.bd-avatar__initials{display:grid;place-items:center;width:100%;height:100%;color:#fff;font-weight:var(--bd-weight-semibold, 600);letter-spacing:.02em;text-transform:uppercase}:host(.bd-avatar--sm){width:28px;height:28px;font-size:.68rem}:host(.bd-avatar--md){width:40px;height:40px;font-size:.85rem}:host(.bd-avatar--lg){width:56px;height:56px;font-size:1.1rem}:host(.bd-avatar--xl){width:88px;height:88px;font-size:1.7rem}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}\n"] }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], src: [{ type: i0.Input, args: [{ isSignal: true, alias: "src", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

/**
 * Contador ou marcador de status.
 *
 * Diferente do `<bd-chip>`, que rotula conteúdo: o badge quantifica ou sinaliza,
 * normalmente grudado noutro elemento.
 *
 * @example
 * ```html
 * <bd-badge>3</bd-badge>
 * <bd-badge tone="danger" [max]="99">128</bd-badge>
 * <bd-badge tone="success" dot>online</bd-badge>
 * ```
 */
class BdBadgeComponent {
    tone = input('primary', ...(ngDevMode ? [{ debugName: "tone" }] : []));
    /** Mostra um ponto antes do texto — bom para status. */
    dot = input(false, ...(ngDevMode ? [{ debugName: "dot", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Valor numérico. Acima de `max`, exibe "max+". */
    value = input(null, ...(ngDevMode ? [{ debugName: "value" }] : []));
    max = input(99, ...(ngDevMode ? [{ debugName: "max" }] : []));
    limitado = computed(() => {
        const v = this.value();
        if (v === null)
            return '';
        return v > this.max() ? `${this.max()}+` : `${v}`;
    }, ...(ngDevMode ? [{ debugName: "limitado" }] : []));
    classes = computed(() => [`bd-badge--${this.tone()}`, this.dot() ? 'bd-badge--dot' : ''].filter(Boolean).join(' '), ...(ngDevMode ? [{ debugName: "classes" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdBadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdBadgeComponent, isStandalone: true, selector: "bd-badge", inputs: { tone: { classPropertyName: "tone", publicName: "tone", isSignal: true, isRequired: false, transformFunction: null }, dot: { classPropertyName: "dot", publicName: "dot", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "classes()" } }, ngImport: i0, template: `
    @if (dot()) {
      <span class="bd-badge__dot" aria-hidden="true"></span>
    }
    @if (limitado()) {
      {{ limitado() }}
    } @else {
      <ng-content />
    }
  `, isInline: true, styles: [":host{display:inline-flex;align-items:center;gap:.35rem;min-width:1.35rem;height:1.35rem;padding:0 .45rem;border:1px solid transparent;border-radius:var(--bd-radius-full, 9999px);font-size:.72rem;font-weight:var(--bd-weight-bold, 700);font-variant-numeric:tabular-nums;line-height:1;justify-content:center}.bd-badge__dot{width:6px;height:6px;background:currentColor;border-radius:50%}:host(.bd-badge--primary){background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}:host(.bd-badge--accent){background:var(--bd-accent, #0d9488);color:var(--bd-accent-contrast, #fff)}:host(.bd-badge--neutral){background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}:host(.bd-badge--success){background:var(--bd-success, #16a34a);color:#fff}:host(.bd-badge--warning){background:var(--bd-warning, #d97706);color:#fff}:host(.bd-badge--danger){background:var(--bd-danger, #dc2626);color:var(--bd-danger-contrast, #fff)}:host(.bd-badge--dot){background:transparent;border-color:currentColor;padding:0 .55rem}:host(.bd-badge--dot.bd-badge--primary){color:var(--bd-primary, #3d5ce8)}:host(.bd-badge--dot.bd-badge--accent){color:var(--bd-accent, #0d9488)}:host(.bd-badge--dot.bd-badge--neutral){color:var(--bd-fg-muted, #545c70)}:host(.bd-badge--dot.bd-badge--success){color:var(--bd-success, #16a34a)}:host(.bd-badge--dot.bd-badge--warning){color:var(--bd-warning, #d97706)}:host(.bd-badge--dot.bd-badge--danger){color:var(--bd-danger, #dc2626)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdBadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (dot()) {
      <span class="bd-badge__dot" aria-hidden="true"></span>
    }
    @if (limitado()) {
      {{ limitado() }}
    } @else {
      <ng-content />
    }
  `, host: { '[class]': 'classes()' }, styles: [":host{display:inline-flex;align-items:center;gap:.35rem;min-width:1.35rem;height:1.35rem;padding:0 .45rem;border:1px solid transparent;border-radius:var(--bd-radius-full, 9999px);font-size:.72rem;font-weight:var(--bd-weight-bold, 700);font-variant-numeric:tabular-nums;line-height:1;justify-content:center}.bd-badge__dot{width:6px;height:6px;background:currentColor;border-radius:50%}:host(.bd-badge--primary){background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}:host(.bd-badge--accent){background:var(--bd-accent, #0d9488);color:var(--bd-accent-contrast, #fff)}:host(.bd-badge--neutral){background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}:host(.bd-badge--success){background:var(--bd-success, #16a34a);color:#fff}:host(.bd-badge--warning){background:var(--bd-warning, #d97706);color:#fff}:host(.bd-badge--danger){background:var(--bd-danger, #dc2626);color:var(--bd-danger-contrast, #fff)}:host(.bd-badge--dot){background:transparent;border-color:currentColor;padding:0 .55rem}:host(.bd-badge--dot.bd-badge--primary){color:var(--bd-primary, #3d5ce8)}:host(.bd-badge--dot.bd-badge--accent){color:var(--bd-accent, #0d9488)}:host(.bd-badge--dot.bd-badge--neutral){color:var(--bd-fg-muted, #545c70)}:host(.bd-badge--dot.bd-badge--success){color:var(--bd-success, #16a34a)}:host(.bd-badge--dot.bd-badge--warning){color:var(--bd-warning, #d97706)}:host(.bd-badge--dot.bd-badge--danger){color:var(--bd-danger, #dc2626)}\n"] }]
        }], propDecorators: { tone: [{ type: i0.Input, args: [{ isSignal: true, alias: "tone", required: false }] }], dot: [{ type: i0.Input, args: [{ isSignal: true, alias: "dot", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }] } });

/**
 * Estado vazio: explica a ausência e oferece o próximo passo.
 *
 * Um empty state sem ação é um beco sem saída — projete-o como convite, não
 * como aviso.
 *
 * @example
 * ```html
 * <bd-empty-state
 *   icon="📭"
 *   title="Nenhum projeto ainda"
 *   description="Crie o primeiro para começar a acompanhar suas entregas."
 * >
 *   <button bdButton>Criar projeto</button>
 * </bd-empty-state>
 * ```
 */
class BdEmptyStateComponent {
    icon = input('', ...(ngDevMode ? [{ debugName: "icon" }] : []));
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdEmptyStateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdEmptyStateComponent, isStandalone: true, selector: "bd-empty-state", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (icon()) {
      <span class="bd-empty__icon" aria-hidden="true">{{ icon() }}</span>
    }
    <h3 class="bd-empty__title">{{ title() }}</h3>
    @if (description()) {
      <p class="bd-empty__desc">{{ description() }}</p>
    }
    <div class="bd-empty__actions"><ng-content /></div>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;padding:var(--bd-space-7, 3rem) var(--bd-space-5, 1.5rem);border:1px dashed var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius-lg, 1.25rem)}.bd-empty__icon{display:grid;place-items:center;width:56px;height:56px;margin-bottom:var(--bd-space-4, 1rem);background:var(--bd-surface-hover, #f1f3f9);border-radius:50%;font-size:1.5rem}.bd-empty__title{margin:0 0 .4rem;font-size:var(--bd-text-lg, 1.125rem);font-weight:var(--bd-weight-semibold, 600);color:var(--bd-fg, #10131c)}.bd-empty__desc{max-width:42ch;margin:0;color:var(--bd-fg-muted, #545c70);font-size:.92rem;line-height:1.6}.bd-empty__actions:not(:empty){display:flex;flex-wrap:wrap;justify-content:center;gap:var(--bd-space-2, .5rem);margin-top:var(--bd-space-5, 1.5rem)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdEmptyStateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-empty-state', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (icon()) {
      <span class="bd-empty__icon" aria-hidden="true">{{ icon() }}</span>
    }
    <h3 class="bd-empty__title">{{ title() }}</h3>
    @if (description()) {
      <p class="bd-empty__desc">{{ description() }}</p>
    }
    <div class="bd-empty__actions"><ng-content /></div>
  `, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;padding:var(--bd-space-7, 3rem) var(--bd-space-5, 1.5rem);border:1px dashed var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius-lg, 1.25rem)}.bd-empty__icon{display:grid;place-items:center;width:56px;height:56px;margin-bottom:var(--bd-space-4, 1rem);background:var(--bd-surface-hover, #f1f3f9);border-radius:50%;font-size:1.5rem}.bd-empty__title{margin:0 0 .4rem;font-size:var(--bd-text-lg, 1.125rem);font-weight:var(--bd-weight-semibold, 600);color:var(--bd-fg, #10131c)}.bd-empty__desc{max-width:42ch;margin:0;color:var(--bd-fg-muted, #545c70);font-size:.92rem;line-height:1.6}.bd-empty__actions:not(:empty){display:flex;flex-wrap:wrap;justify-content:center;gap:var(--bd-space-2, .5rem);margin-top:var(--bd-space-5, 1.5rem)}\n"] }]
        }], propDecorators: { icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }] } });

/**
 * Anima um número de 0 até o value final quando o elemento entra na viewport.
 *
 * Escreve direto no DOM via `requestAnimationFrame`, sem disparar change
 * detection a cada quadro. Seguro em SSR e respeita `prefers-reduced-motion`
 * (nesse caso mostra o value final imediatamente).
 *
 * @example
 * ```html
 * <span [bdCountUp]="3" suffix="+"></span>
 * <span [bdCountUp]="1250" prefix="R$ " [duration]="2000"></span>
 * ```
 */
class BdCountUpDirective {
    bdCountUp = input.required(...(ngDevMode ? [{ debugName: "bdCountUp" }] : []));
    prefix = input('', ...(ngDevMode ? [{ debugName: "prefix" }] : []));
    suffix = input('', ...(ngDevMode ? [{ debugName: "suffix" }] : []));
    /** Duração da contagem em milissegundos. */
    duration = input(1400, ...(ngDevMode ? [{ debugName: "duration" }] : []));
    host = inject(ElementRef);
    observer;
    frame;
    constructor() {
        inject(DestroyRef).onDestroy(() => {
            this.observer?.disconnect();
            if (this.frame)
                cancelAnimationFrame(this.frame);
        });
        afterNextRender(() => this.configurar());
    }
    configurar() {
        const semMovimento = matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (semMovimento || typeof IntersectionObserver === 'undefined') {
            this.render(this.bdCountUp());
            return;
        }
        this.render(0);
        this.observer = new IntersectionObserver((entries) => {
            if (entries.some((e) => e.isIntersecting)) {
                this.observer?.disconnect();
                this.animar();
            }
        }, { threshold: 0.4 });
        this.observer.observe(this.host.nativeElement);
    }
    animar() {
        const alvo = this.bdCountUp();
        const total = this.duration();
        const inicio = performance.now();
        const passo = (agora) => {
            const t = Math.min(1, (agora - inicio) / total);
            // easeOutExpo: acelera no início e assenta suave no value final.
            const eased = t === 1 ? 1 : 1 - Math.pow(2, -10 * t);
            this.render(Math.round(alvo * eased));
            if (t < 1) {
                this.frame = requestAnimationFrame(passo);
            }
        };
        this.frame = requestAnimationFrame(passo);
    }
    render(value) {
        this.host.nativeElement.textContent = `${this.prefix()}${value}${this.suffix()}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCountUpDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.27", type: BdCountUpDirective, isStandalone: true, selector: "[bdCountUp]", inputs: { bdCountUp: { classPropertyName: "bdCountUp", publicName: "bdCountUp", isSignal: true, isRequired: true, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, duration: { classPropertyName: "duration", publicName: "duration", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdCountUpDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[bdCountUp]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { bdCountUp: [{ type: i0.Input, args: [{ isSignal: true, alias: "bdCountUp", required: true }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], duration: [{ type: i0.Input, args: [{ isSignal: true, alias: "duration", required: false }] }] } });

/**
 * Indicador numérico com contagem animada na entrada em tela e variação
 * opcional em relação ao período anterior.
 *
 * A direção da variação é comunicada por seta, cor e texto anunciado — nunca
 * apenas por cor, que não é distinguível por parte dos usuários.
 *
 * @example
 * ```html
 * <bd-metric [value]="3" suffix="+" label="anos de experiência" />
 * <bd-metric [value]="98" suffix="%" label="cobertura" gradient />
 * <bd-metric [value]="128" prefix="R$ " suffix="k" label="Receita"
 *            align="start" trend="up" delta="12,5%" />
 * ```
 */
class BdMetricComponent {
    value = input.required(...(ngDevMode ? [{ debugName: "value" }] : []));
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    prefix = input('', ...(ngDevMode ? [{ debugName: "prefix" }] : []));
    suffix = input('', ...(ngDevMode ? [{ debugName: "suffix" }] : []));
    /** Preenche o número com o gradiente da marca. */
    gradient = input(false, ...(ngDevMode ? [{ debugName: "gradient", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Alinhamento do bloco. Use `start` em painéis. */
    align = input('center', ...(ngDevMode ? [{ debugName: "align" }] : []));
    /** Variação em relação ao período anterior — ex.: `'12,5%'`. */
    delta = input('', ...(ngDevMode ? [{ debugName: "delta" }] : []));
    /** Direção da variação. Define cor, seta e texto anunciado. */
    trend = input('flat', ...(ngDevMode ? [{ debugName: "trend" }] : []));
    /** Rótulos anunciados por leitores de tela para cada direção. */
    trendLabels = input({
        up: 'de aumento',
        down: 'de queda',
        flat: 'de variação',
    }, ...(ngDevMode ? [{ debugName: "trendLabels" }] : []));
    trendGlyph = computed(() => ({ up: '↑', down: '↓', flat: '→' })[this.trend()], ...(ngDevMode ? [{ debugName: "trendGlyph" }] : []));
    trendLabel = computed(() => this.trendLabels()[this.trend()], ...(ngDevMode ? [{ debugName: "trendLabel" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdMetricComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdMetricComponent, isStandalone: true, selector: "bd-metric", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, gradient: { classPropertyName: "gradient", publicName: "gradient", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, delta: { classPropertyName: "delta", publicName: "delta", isSignal: true, isRequired: false, transformFunction: null }, trend: { classPropertyName: "trend", publicName: "trend", isSignal: true, isRequired: false, transformFunction: null }, trendLabels: { classPropertyName: "trendLabels", publicName: "trendLabels", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.bd-metric--start": "align() === 'start'" } }, ngImport: i0, template: `
    <span
      class="bd-metric__value"
      [class.bd-metric__value--gradient]="gradient()"
      [bdCountUp]="value()"
      [prefix]="prefix()"
      [suffix]="suffix()"
    ></span>
    @if (label()) {
      <span class="bd-metric__label">{{ label() }}</span>
    }

    @if (delta()) {
      <!-- A direção é comunicada por texto e por seta, não apenas por cor:
           verde e vermelho não se distinguem para parte dos usuários. -->
      <span class="bd-metric__delta" [class]="'bd-metric__delta--' + trend()">
        <span aria-hidden="true">{{ trendGlyph() }}</span>
        {{ delta() }}
        <span class="bd-metric__sr">{{ trendLabel() }}</span>
      </span>
    }
  `, isInline: true, styles: [":host{display:block;text-align:center}.bd-metric__value{display:block;font-size:clamp(1.6rem,3vw,2.2rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.03em;line-height:1.1;color:var(--bd-primary, #3d5ce8);min-height:1.1em}.bd-metric__value--gradient{background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));-webkit-background-clip:text;background-clip:text;color:transparent}.bd-metric__label{display:block;margin-top:var(--bd-space-1, .25rem);font-size:var(--bd-text-sm, .875rem);color:var(--bd-fg-muted, #545c70)}.bd-metric__delta{display:inline-flex;align-items:center;gap:.25rem;margin-top:var(--bd-space-2, .5rem);padding:.12rem .5rem;border-radius:var(--bd-radius-full, 9999px);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-semibold, 600)}.bd-metric__delta--up{background:var(--bd-success-soft, rgba(22, 163, 74, .1));color:var(--bd-success, #16a34a)}.bd-metric__delta--down{background:var(--bd-danger-soft, rgba(220, 38, 38, .1));color:var(--bd-danger, #dc2626)}.bd-metric__delta--flat{background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}.bd-metric__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}:host(.bd-metric--start){text-align:left}\n"], dependencies: [{ kind: "directive", type: BdCountUpDirective, selector: "[bdCountUp]", inputs: ["bdCountUp", "prefix", "suffix", "duration"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdMetricComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-metric', standalone: true, imports: [BdCountUpDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <span
      class="bd-metric__value"
      [class.bd-metric__value--gradient]="gradient()"
      [bdCountUp]="value()"
      [prefix]="prefix()"
      [suffix]="suffix()"
    ></span>
    @if (label()) {
      <span class="bd-metric__label">{{ label() }}</span>
    }

    @if (delta()) {
      <!-- A direção é comunicada por texto e por seta, não apenas por cor:
           verde e vermelho não se distinguem para parte dos usuários. -->
      <span class="bd-metric__delta" [class]="'bd-metric__delta--' + trend()">
        <span aria-hidden="true">{{ trendGlyph() }}</span>
        {{ delta() }}
        <span class="bd-metric__sr">{{ trendLabel() }}</span>
      </span>
    }
  `, host: { '[class.bd-metric--start]': "align() === 'start'" }, styles: [":host{display:block;text-align:center}.bd-metric__value{display:block;font-size:clamp(1.6rem,3vw,2.2rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.03em;line-height:1.1;color:var(--bd-primary, #3d5ce8);min-height:1.1em}.bd-metric__value--gradient{background:var(--bd-gradient, linear-gradient(120deg, #3d5ce8, #0d9488));-webkit-background-clip:text;background-clip:text;color:transparent}.bd-metric__label{display:block;margin-top:var(--bd-space-1, .25rem);font-size:var(--bd-text-sm, .875rem);color:var(--bd-fg-muted, #545c70)}.bd-metric__delta{display:inline-flex;align-items:center;gap:.25rem;margin-top:var(--bd-space-2, .5rem);padding:.12rem .5rem;border-radius:var(--bd-radius-full, 9999px);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-semibold, 600)}.bd-metric__delta--up{background:var(--bd-success-soft, rgba(22, 163, 74, .1));color:var(--bd-success, #16a34a)}.bd-metric__delta--down{background:var(--bd-danger-soft, rgba(220, 38, 38, .1));color:var(--bd-danger, #dc2626)}.bd-metric__delta--flat{background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg-muted, #545c70)}.bd-metric__sr{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}:host(.bd-metric--start){text-align:left}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], gradient: [{ type: i0.Input, args: [{ isSignal: true, alias: "gradient", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }], delta: [{ type: i0.Input, args: [{ isSignal: true, alias: "delta", required: false }] }], trend: [{ type: i0.Input, args: [{ isSignal: true, alias: "trend", required: false }] }], trendLabels: [{ type: i0.Input, args: [{ isSignal: true, alias: "trendLabels", required: false }] }] } });

/**
 * Estilos mínimos das diretivas que escrevem fora do encapsulamento do Angular.
 *
 * `bdTooltip` cria o balão no `<body>` e `bdReveal` aplica classes no elemento
 * hospedeiro: nenhum dos dois é alcançado pelo CSS encapsulado de um componente.
 * A folha `bandeira-ui/styles/animations` cobre esses casos, mas depende de o
 * consumidor tê-la importado — quando isso não acontece, o balão aparece como
 * texto solto no canto da página.
 *
 * Para eliminar a dependência silenciosa, o mesmo conjunto essencial de regras
 * é injetado em tempo de execução, uma única vez por documento. A folha é
 * inserida como **primeiro** nó do `<head>`, de modo que qualquer estilo
 * declarado pela aplicação — inclusive a folha oficial da biblioteca — tenha
 * precedência sobre ela. O resultado é um piso funcional, nunca um teto.
 */
const MARKER = 'data-bd-runtime-styles';
const RULES = `
.bd-reveal{opacity:0;transition:opacity var(--bd-duration-slow,.5s) var(--bd-ease,cubic-bezier(.16,1,.3,1)),transform var(--bd-duration-slow,.5s) var(--bd-ease,cubic-bezier(.16,1,.3,1));will-change:opacity,transform}
.bd-reveal--up{transform:translateY(32px)}
.bd-reveal--down{transform:translateY(-32px)}
.bd-reveal--left{transform:translateX(-36px)}
.bd-reveal--right{transform:translateX(36px)}
.bd-reveal--scale{transform:scale(.94)}
.bd-reveal.is-visible{opacity:1;transform:none;will-change:auto}
.bd-tooltip{position:fixed;top:0;left:0;z-index:var(--bd-z-tooltip,400);max-width:260px;padding:.4rem .65rem;background:var(--bd-fg,#10131c);border-radius:var(--bd-radius-sm,.5rem);color:var(--bd-bg,#fff);font-family:var(--bd-font-sans,system-ui,sans-serif);font-size:.78rem;font-weight:500;line-height:1.45;pointer-events:none;animation:bd-tooltip-in .14s ease}
@keyframes bd-tooltip-in{from{opacity:0}to{opacity:1}}
.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
@media (prefers-reduced-motion:reduce){.bd-reveal{opacity:1;transform:none;transition:none}}
`;
/** Garante os estilos de base no documento. Chamadas repetidas não têm efeito. */
function ensureBdRuntimeStyles(document) {
    const head = document.head;
    if (!head || head.querySelector(`style[${MARKER}]`))
        return;
    const style = document.createElement('style');
    style.setAttribute(MARKER, '');
    style.textContent = RULES;
    head.insertBefore(style, head.firstChild);
}

let instanceCount = 0;
/**
 * Dica contextual exibida no ponteiro e no foco por teclado.
 *
 * A exibição no foco não é opcional: uma dica que responde apenas ao ponteiro
 * é inacessível a quem navega por teclado. O elemento hospedeiro recebe
 * `aria-describedby`, de modo que o leitor de tela anuncia a dica junto com o
 * controle que ela descreve.
 *
 * O balão é renderizado no `<body>` para escapar de `overflow: hidden` e de
 * contextos de empilhamento, e acompanha o alvo durante rolagem e
 * redimensionamento.
 *
 * Dicas não devem carregar informação essencial: em dispositivos de toque não
 * existe estado de ponteiro sobre o elemento.
 *
 * @example
 * ```html
 * <button bdButton iconOnly bdTooltip="Excluir projeto" aria-label="Excluir">🗑</button>
 * <span bdTooltip="Atualizado há 2 minutos" placement="right">agora</span>
 * ```
 */
class BdTooltipDirective {
    bdTooltip = input.required(...(ngDevMode ? [{ debugName: "bdTooltip" }] : []));
    placement = input('top', ...(ngDevMode ? [{ debugName: "placement" }] : []));
    /** Atraso de exibição em milissegundos — evita cintilação ao cruzar o alvo. */
    showDelay = input(120, ...(ngDevMode ? [{ debugName: "showDelay" }] : []));
    host = inject(ElementRef);
    document = inject(DOCUMENT);
    bubble;
    timer;
    frame;
    id = `bd-tooltip-${instanceCount++}`;
    /** Reposiciona o balão junto com o alvo, no ritmo do compositor. */
    onViewportChange = () => {
        if (!this.bubble)
            return;
        const view = this.document.defaultView;
        if (!view)
            return;
        if (this.frame !== undefined)
            view.cancelAnimationFrame(this.frame);
        this.frame = view.requestAnimationFrame(() => {
            this.frame = undefined;
            if (this.bubble)
                this.position(this.bubble);
        });
    };
    constructor() {
        inject(DestroyRef).onDestroy(() => this.hide());
    }
    schedule() {
        clearTimeout(this.timer);
        this.timer = setTimeout(() => this.show(), this.showDelay());
    }
    hide() {
        clearTimeout(this.timer);
        const view = this.document.defaultView;
        if (this.frame !== undefined && view) {
            view.cancelAnimationFrame(this.frame);
            this.frame = undefined;
        }
        if (this.bubble) {
            view?.removeEventListener('scroll', this.onViewportChange, true);
            view?.removeEventListener('resize', this.onViewportChange);
            this.bubble.remove();
            this.bubble = undefined;
        }
        this.host.nativeElement.removeAttribute('aria-describedby');
    }
    show() {
        if (this.bubble || !this.bdTooltip())
            return;
        ensureBdRuntimeStyles(this.document);
        const bubble = this.document.createElement('div');
        bubble.id = this.id;
        bubble.className = `bd-tooltip bd-tooltip--${this.placement()}`;
        bubble.setAttribute('role', 'tooltip');
        bubble.textContent = this.bdTooltip();
        this.document.body.appendChild(bubble);
        this.bubble = bubble;
        this.host.nativeElement.setAttribute('aria-describedby', this.id);
        this.position(bubble);
        const view = this.document.defaultView;
        // Captura na fase de descida: alcança a rolagem de qualquer ancestral,
        // não apenas a da janela.
        view?.addEventListener('scroll', this.onViewportChange, { passive: true, capture: true });
        view?.addEventListener('resize', this.onViewportChange, { passive: true });
    }
    position(bubble) {
        const view = this.document.defaultView;
        if (!view)
            return;
        const target = this.host.nativeElement.getBoundingClientRect();
        const box = bubble.getBoundingClientRect();
        const gap = 8;
        let top = 0;
        let left = 0;
        switch (this.placement()) {
            case 'top':
                top = target.top - box.height - gap;
                left = target.left + target.width / 2 - box.width / 2;
                break;
            case 'bottom':
                top = target.bottom + gap;
                left = target.left + target.width / 2 - box.width / 2;
                break;
            case 'left':
                top = target.top + target.height / 2 - box.height / 2;
                left = target.left - box.width - gap;
                break;
            case 'right':
                top = target.top + target.height / 2 - box.height / 2;
                left = target.right + gap;
                break;
        }
        // Mantém o balão dentro da área visível nos dois eixos.
        const margin = 8;
        left = Math.min(Math.max(margin, left), view.innerWidth - box.width - margin);
        top = Math.min(Math.max(margin, top), view.innerHeight - box.height - margin);
        bubble.style.top = `${top}px`;
        bubble.style.left = `${left}px`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.27", type: BdTooltipDirective, isStandalone: true, selector: "[bdTooltip]", inputs: { bdTooltip: { classPropertyName: "bdTooltip", publicName: "bdTooltip", isSignal: true, isRequired: true, transformFunction: null }, placement: { classPropertyName: "placement", publicName: "placement", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "mouseenter": "schedule()", "focus": "schedule()", "mouseleave": "hide()", "blur": "hide()", "document:keydown.escape": "hide()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[bdTooltip]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { bdTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "bdTooltip", required: true }] }], placement: [{ type: i0.Input, args: [{ isSignal: true, alias: "placement", required: false }] }], showDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelay", required: false }] }], schedule: [{
                type: HostListener,
                args: ['mouseenter']
            }, {
                type: HostListener,
                args: ['focus']
            }], hide: [{
                type: HostListener,
                args: ['mouseleave']
            }, {
                type: HostListener,
                args: ['blur']
            }, {
                type: HostListener,
                args: ['document:keydown.escape']
            }] } });

const BD_TOUR_DEFAULT_LABELS = {
    next: 'Próximo',
    prev: 'Voltar',
    finish: 'Concluir',
    skip: 'Pular',
    counter: (current, total) => `${current} de ${total}`,
};
const STORAGE_PREFIX = 'bd-tour:';
/**
 * Orquestra o tour guiado de integração. Injete onde for necessário e invoque
 * `start()`; o componente `<bd-tour />` deve estar montado uma única vez na
 * aplicação — tipicamente no componente raiz — para desenhar destaque e balão.
 *
 * O estado é exposto como signals somente-leitura, o que permite reagir ao
 * progresso do tour em qualquer ponto da aplicação.
 *
 * @example
 * ```ts
 * private readonly tour = inject(BdTourService);
 *
 * apresentar(): void {
 *   // `startOnce` registra a exibição e não repete o tour para este usuário.
 *   this.tour.startOnce('onboarding-v1', [
 *     { target: '#busca', title: 'Busca', content: 'Localize qualquer projeto.' },
 *     { target: '#filtros', title: 'Filtros', content: 'Refine por status e período.' },
 *   ]);
 * }
 * ```
 */
class BdTourService {
    document = inject(DOCUMENT);
    _steps = signal([], ...(ngDevMode ? [{ debugName: "_steps" }] : []));
    _index = signal(0, ...(ngDevMode ? [{ debugName: "_index" }] : []));
    _active = signal(false, ...(ngDevMode ? [{ debugName: "_active" }] : []));
    _outcome = signal(null, ...(ngDevMode ? [{ debugName: "_outcome" }] : []));
    storageKey = null;
    labels = signal(BD_TOUR_DEFAULT_LABELS, ...(ngDevMode ? [{ debugName: "labels" }] : []));
    steps = this._steps.asReadonly();
    index = this._index.asReadonly();
    active = this._active.asReadonly();
    /** Desfecho do último tour encerrado; `null` enquanto nenhum terminou. */
    outcome = this._outcome.asReadonly();
    total = computed(() => this._steps().length, ...(ngDevMode ? [{ debugName: "total" }] : []));
    step = computed(() => this._steps()[this._index()] ?? null, ...(ngDevMode ? [{ debugName: "step" }] : []));
    isFirst = computed(() => this._index() === 0, ...(ngDevMode ? [{ debugName: "isFirst" }] : []));
    isLast = computed(() => this._index() === this.total() - 1, ...(ngDevMode ? [{ debugName: "isLast" }] : []));
    /** Inicia o tour a partir do primeiro passo. */
    start(steps, labels) {
        if (!steps.length)
            return;
        this.labels.set(labels ? { ...BD_TOUR_DEFAULT_LABELS, ...labels } : BD_TOUR_DEFAULT_LABELS);
        this._steps.set(steps);
        this._index.set(0);
        this._outcome.set(null);
        this._active.set(true);
    }
    /**
     * Inicia o tour apenas na primeira vez para esta chave, registrando a
     * exibição no `localStorage`. Versione a chave (`onboarding-v2`) para
     * reapresentar o tour após uma mudança relevante de interface.
     *
     * @returns `true` se o tour foi iniciado.
     */
    startOnce(key, steps, labels) {
        if (this.hasSeen(key))
            return false;
        this.start(steps, labels);
        if (this._active()) {
            this.storageKey = key;
            return true;
        }
        return false;
    }
    /** Indica se o tour desta chave já foi encerrado alguma vez neste dispositivo. */
    hasSeen(key) {
        return this.storage()?.getItem(STORAGE_PREFIX + key) !== null;
    }
    /** Descarta o registro de exibição, permitindo reapresentar o tour. */
    reset(key) {
        this.storage()?.removeItem(STORAGE_PREFIX + key);
    }
    next() {
        if (this.isLast()) {
            this.finish();
            return;
        }
        this._index.update((i) => i + 1);
    }
    prev() {
        if (!this.isFirst()) {
            this._index.update((i) => i - 1);
        }
    }
    /** Salta diretamente para um passo pelo índice. */
    goTo(index) {
        if (index >= 0 && index < this.total()) {
            this._index.set(index);
        }
    }
    /** Encerra após percorrer todos os passos. */
    finish() {
        this.end(true);
    }
    /** Encerra antecipadamente (`Esc`, clique fora ou botão de pular). */
    skip() {
        this.end(false);
    }
    end(completed) {
        if (!this._active())
            return;
        this._active.set(false);
        this._outcome.set({ completed, step: this._index() });
        if (this.storageKey) {
            this.storage()?.setItem(STORAGE_PREFIX + this.storageKey, new Date().toISOString());
            this.storageKey = null;
        }
    }
    /**
     * O armazenamento é opcional por natureza: não existe em renderização no
     * servidor e lança exceção em navegação privada com cookies bloqueados.
     * Em ambos os casos o tour segue funcionando, apenas sem memória.
     */
    storage() {
        try {
            return this.document.defaultView?.localStorage ?? null;
        }
        catch {
            return null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTourService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTourService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTourService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const SPOT_PADDING = 8;
const POPOVER_GAP = 14;
const POPOVER_WIDTH = 320;
const POPOVER_FALLBACK_HEIGHT = 220;
const VIEWPORT_MARGIN = 16;
/** Tempo estimado para a rolagem suave assentar antes da medição. */
const SCROLL_SETTLE_MS = 320;
/**
 * Camada de apresentação do tour guiado. Monte uma única vez, normalmente no
 * componente raiz:
 *
 * ```html
 * <router-outlet />
 * <bd-tour />
 * ```
 *
 * O controle pertence ao {@link BdTourService}. O destaque recorta o elemento
 * alvo por meio de uma sombra projetada maior que a área visível, o balão é
 * posicionado no primeiro lado com espaço disponível e recebe o foco a cada
 * passo — `Esc` encerra, setas navegam.
 */
class BdTourComponent {
    tour = inject(BdTourService);
    /** Espaço extra em volta do elemento destacado. */
    spotPadding = input(SPOT_PADDING, ...(ngDevMode ? [{ debugName: "spotPadding" }] : []));
    /** Rola o alvo até o centro da área visível antes de destacá-lo. */
    scrollIntoView = input(true, ...(ngDevMode ? [{ debugName: "scrollIntoView" }] : []));
    document = inject(DOCUMENT);
    popover = viewChild('popover', ...(ngDevMode ? [{ debugName: "popover" }] : []));
    titleId = 'bd-tour-title';
    contentId = 'bd-tour-content';
    spot = signal({ top: 0, left: 0, width: 0, height: 0 }, ...(ngDevMode ? [{ debugName: "spot" }] : []));
    position = signal({ top: 0, left: 0, side: 'center' }, ...(ngDevMode ? [{ debugName: "position" }] : []));
    hasTarget = signal(false, ...(ngDevMode ? [{ debugName: "hasTarget" }] : []));
    settleTimer;
    frame;
    /**
     * Reagenda a medição no ritmo do compositor.
     *
     * Rolagem e redimensionamento apenas remedem: **não** movem o foco. Medir e
     * focar são operações distintas justamente porque a rolagem suave do próprio
     * passo emite dezenas de eventos — devolver o foco em cada um deles tornaria
     * a página impossível de percorrer durante o tour.
     */
    onViewportChange = () => {
        if (!this.tour.active())
            return;
        const view = this.document.defaultView;
        if (!view)
            return;
        if (this.frame !== undefined)
            view.cancelAnimationFrame(this.frame);
        this.frame = view.requestAnimationFrame(() => {
            this.frame = undefined;
            this.measure();
        });
    };
    constructor() {
        // Cada mudança de passo remede e devolve o foco ao balão — uma única vez.
        effect(() => {
            const step = this.tour.step();
            const active = this.tour.active();
            const scroll = this.scrollIntoView();
            clearTimeout(this.settleTimer);
            if (!active || !step)
                return;
            const target = this.resolveTarget(step.target);
            const shouldScroll = !!target && scroll;
            if (shouldScroll) {
                target.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
            }
            // A medição espera a rolagem assentar; sem rolagem, apenas o próximo
            // ciclo de tarefas, para que o balão do passo atual já esteja no DOM.
            this.settleTimer = setTimeout(() => {
                this.measure();
                this.focusPopover();
            }, shouldScroll ? SCROLL_SETTLE_MS : 0);
        });
        const view = this.document.defaultView;
        // Captura na fase de descida: alcança a rolagem de qualquer ancestral, não
        // apenas a da janela. Passivo, para não competir com o compositor.
        view?.addEventListener('scroll', this.onViewportChange, { passive: true, capture: true });
        view?.addEventListener('resize', this.onViewportChange, { passive: true });
        inject(DestroyRef).onDestroy(() => {
            clearTimeout(this.settleTimer);
            if (this.frame !== undefined)
                view?.cancelAnimationFrame(this.frame);
            view?.removeEventListener('scroll', this.onViewportChange, true);
            view?.removeEventListener('resize', this.onViewportChange);
        });
    }
    onKeydown(event) {
        if (!this.tour.active())
            return;
        if (event.key === 'Escape') {
            event.preventDefault();
            this.tour.skip();
            return;
        }
        // Setas e Enter só navegam com o foco dentro do balão. Sem essa restrição,
        // um Enter destinado a um formulário da página avançaria o tour e teria a
        // ação original cancelada.
        if (!this.isFocusWithinPopover())
            return;
        switch (event.key) {
            case 'ArrowRight':
            case 'Enter':
                // O Enter sobre um dos botões do balão já é tratado pelo próprio botão.
                if (this.isFocusOnControl(event))
                    return;
                event.preventDefault();
                this.tour.next();
                break;
            case 'ArrowLeft':
                event.preventDefault();
                this.tour.prev();
                break;
        }
    }
    /**
     * Resolve o alvo do passo. Um seletor malformado não deve derrubar a
     * aplicação: o passo degrada para a apresentação centralizada.
     */
    resolveTarget(selector) {
        if (!selector)
            return null;
        try {
            return this.document.querySelector(selector);
        }
        catch {
            if (typeof ngDevMode !== 'undefined' && ngDevMode) {
                console.warn(`[bandeira-ui] Seletor de passo inválido no tour: "${selector}".`);
            }
            return null;
        }
    }
    /** Mede o alvo e reposiciona destaque e balão. Não altera o foco. */
    measure() {
        const step = this.tour.step();
        const view = this.document.defaultView;
        if (!step || !view)
            return;
        const target = this.resolveTarget(step.target);
        const vw = view.innerWidth;
        const vh = view.innerHeight;
        const pad = this.spotPadding();
        if (!target) {
            // Sem alvo: a tela inteira escurece e o balão é centralizado.
            const height = this.popoverHeight();
            this.hasTarget.set(false);
            this.spot.set({ top: vh / 2, left: vw / 2, width: 0, height: 0 });
            this.position.set({
                top: Math.max(VIEWPORT_MARGIN, vh / 2 - height / 2),
                left: Math.max(VIEWPORT_MARGIN, vw / 2 - POPOVER_WIDTH / 2),
                side: 'center',
            });
            return;
        }
        const rect = target.getBoundingClientRect();
        this.hasTarget.set(true);
        this.spot.set({
            top: rect.top - pad,
            left: rect.left - pad,
            width: rect.width + pad * 2,
            height: rect.height + pad * 2,
        });
        this.position.set(this.resolvePosition(rect, step.placement ?? 'auto', vw, vh));
    }
    /**
     * Escolhe o primeiro lado com espaço suficiente. Em `auto`, a ordem é
     * abaixo, acima, direita e esquerda; sem espaço em nenhum, centraliza.
     */
    resolvePosition(rect, preferred, vw, vh) {
        // A altura real do balão, e não uma estimativa: passos com texto longo
        // ocupam bem mais que o valor nominal e escolheriam o lado errado.
        const height = this.popoverHeight();
        const pad = this.spotPadding();
        const fits = {
            bottom: vh - rect.bottom - pad > height + POPOVER_GAP,
            top: rect.top - pad > height + POPOVER_GAP,
            right: vw - rect.right - pad > POPOVER_WIDTH + POPOVER_GAP,
            left: rect.left - pad > POPOVER_WIDTH + POPOVER_GAP,
        };
        const order = preferred === 'auto'
            ? ['bottom', 'top', 'right', 'left']
            : [preferred, 'bottom', 'top', 'right', 'left'];
        const side = order.find((candidate) => fits[candidate]);
        if (!side) {
            return {
                top: Math.max(VIEWPORT_MARGIN, vh / 2 - height / 2),
                left: Math.max(VIEWPORT_MARGIN, vw / 2 - POPOVER_WIDTH / 2),
                side: 'center',
            };
        }
        // Mantém o balão dentro da área visível nos dois eixos.
        const clampX = (x) => Math.min(Math.max(VIEWPORT_MARGIN, x), vw - POPOVER_WIDTH - VIEWPORT_MARGIN);
        const clampY = (y) => Math.min(Math.max(VIEWPORT_MARGIN, y), vh - height - VIEWPORT_MARGIN);
        switch (side) {
            case 'bottom':
                return { top: rect.bottom + pad + POPOVER_GAP, left: clampX(rect.left - pad), side };
            case 'top':
                return {
                    top: rect.top - pad - POPOVER_GAP - height,
                    left: clampX(rect.left - pad),
                    side,
                };
            case 'right':
                return { top: clampY(rect.top - pad), left: rect.right + pad + POPOVER_GAP, side };
            case 'left':
                return {
                    top: clampY(rect.top - pad),
                    left: rect.left - pad - POPOVER_GAP - POPOVER_WIDTH,
                    side,
                };
        }
    }
    popoverHeight() {
        return this.popover()?.nativeElement.offsetHeight || POPOVER_FALLBACK_HEIGHT;
    }
    /** Leva o foco ao balão para que o leitor de tela anuncie o passo. */
    focusPopover() {
        this.popover()?.nativeElement.focus({ preventScroll: true });
    }
    isFocusWithinPopover() {
        const element = this.popover()?.nativeElement;
        const active = this.document.activeElement;
        return !!element && !!active && element.contains(active);
    }
    isFocusOnControl(event) {
        return event.key === 'Enter' && event.target?.tagName === 'BUTTON';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTourComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdTourComponent, isStandalone: true, selector: "bd-tour", inputs: { spotPadding: { classPropertyName: "spotPadding", publicName: "spotPadding", isSignal: true, isRequired: false, transformFunction: null }, scrollIntoView: { classPropertyName: "scrollIntoView", publicName: "scrollIntoView", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "document:keydown": "onKeydown($event)" } }, viewQueries: [{ propertyName: "popover", first: true, predicate: ["popover"], descendants: true, isSignal: true }], ngImport: i0, template: `
    @if (tour.active() && tour.step(); as step) {
      <div class="bd-tour" role="presentation">
        <!-- A sombra projetada maior que a tela escurece tudo, exceto este
             retângulo — o recorte não exige SVG nem máscara. -->
        <div
          class="bd-tour__spot"
          [class.bd-tour__spot--empty]="!hasTarget()"
          [style.top.px]="spot().top"
          [style.left.px]="spot().left"
          [style.width.px]="spot().width"
          [style.height.px]="spot().height"
        ></div>

        <!-- Captura o clique fora sem cobrir o alvo destacado. -->
        <div class="bd-tour__catch" (click)="tour.skip()"></div>

        <div
          #popover
          class="bd-tour__popover"
          [class]="'bd-tour__popover--' + position().side"
          [style.top.px]="position().top"
          [style.left.px]="position().left"
          role="dialog"
          aria-modal="true"
          [attr.aria-labelledby]="titleId"
          [attr.aria-describedby]="contentId"
          tabindex="-1"
        >
          <span class="bd-tour__arrow" aria-hidden="true"></span>

          <span class="bd-tour__counter">
            {{ tour.labels().counter(tour.index() + 1, tour.total()) }}
          </span>

          <h2 class="bd-tour__title" [id]="titleId">{{ step.title }}</h2>
          <p class="bd-tour__content" [id]="contentId">{{ step.content }}</p>

          <div class="bd-tour__dots" aria-hidden="true">
            @for (s of tour.steps(); track $index) {
              <span class="bd-tour__dot" [class.is-active]="$index === tour.index()"></span>
            }
          </div>

          <div class="bd-tour__actions">
            <button type="button" class="bd-tour__skip" (click)="tour.skip()">
              {{ tour.labels().skip }}
            </button>

            <div class="bd-tour__nav">
              @if (!tour.isFirst()) {
                <button type="button" class="bd-tour__btn" (click)="tour.prev()">
                  {{ tour.labels().prev }}
                </button>
              }
              <button
                type="button"
                class="bd-tour__btn bd-tour__btn--primary"
                (click)="tour.next()"
              >
                {{ step.nextLabel ?? (tour.isLast() ? tour.labels().finish : tour.labels().next) }}
              </button>
            </div>
          </div>
        </div>
      </div>
    }
  `, isInline: true, styles: [".bd-tour{position:fixed;inset:0;z-index:var(--bd-z-tooltip, 400);pointer-events:none}.bd-tour__spot{position:fixed;border-radius:var(--bd-radius, .875rem);box-shadow:0 0 0 9999px #03050aad;outline:2px solid var(--bd-primary, #3d5ce8);outline-offset:2px;transition:top .3s var(--bd-ease, ease),left .3s var(--bd-ease, ease),width .3s var(--bd-ease, ease),height .3s var(--bd-ease, ease);pointer-events:none}.bd-tour__spot--empty{outline:none}.bd-tour__catch{position:fixed;inset:0;pointer-events:auto}.bd-tour__popover{position:fixed;width:320px;max-width:calc(100vw - 2rem);padding:1.25rem 1.35rem 1.1rem;background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .35));color:var(--bd-fg, #10131c);pointer-events:auto;animation:bd-tour-in .24s var(--bd-ease, ease);transition:top .3s var(--bd-ease, ease),left .3s var(--bd-ease, ease)}.bd-tour__popover:focus{outline:none}@keyframes bd-tour-in{0%{opacity:0;transform:scale(.96)}to{opacity:1;transform:none}}.bd-tour__arrow{position:absolute;width:10px;height:10px;background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);transform:rotate(45deg)}.bd-tour__popover--bottom .bd-tour__arrow{top:-6px;left:28px;border-right:none;border-bottom:none}.bd-tour__popover--top .bd-tour__arrow{bottom:-6px;left:28px;border-left:none;border-top:none}.bd-tour__popover--right .bd-tour__arrow{left:-6px;top:24px;border-right:none;border-top:none}.bd-tour__popover--left .bd-tour__arrow{right:-6px;top:24px;border-left:none;border-bottom:none}.bd-tour__popover--center .bd-tour__arrow{display:none}.bd-tour__counter{display:block;margin-bottom:.35rem;color:var(--bd-primary, #3d5ce8);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:.06em;text-transform:uppercase}.bd-tour__title{margin:0 0 .4rem;font-size:var(--bd-text-lg, 1.125rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.015em}.bd-tour__content{margin:0;color:var(--bd-fg-muted, #545c70);font-size:.9rem;line-height:1.6}.bd-tour__dots{display:flex;gap:5px;margin:1rem 0 .9rem}.bd-tour__dot{width:6px;height:6px;background:var(--bd-border-strong, #cbd2e2);border-radius:50%;transition:background .2s ease,width .2s ease}.bd-tour__dot.is-active{width:18px;background:var(--bd-primary, #3d5ce8);border-radius:var(--bd-radius-full, 9999px)}.bd-tour__actions{display:flex;align-items:center;justify-content:space-between;gap:.75rem}.bd-tour__nav{display:flex;gap:.4rem}.bd-tour__btn,.bd-tour__skip{min-height:36px;padding:.4rem .9rem;border-radius:var(--bd-radius-sm, .5rem);font-family:inherit;font-size:.85rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:background .2s ease,color .2s ease,border-color .2s ease}.bd-tour__skip{padding-left:0;background:none;border:none;color:var(--bd-fg-subtle, #7b8399)}.bd-tour__skip:hover{color:var(--bd-fg, #10131c)}.bd-tour__btn{background:transparent;border:1px solid var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c)}.bd-tour__btn:hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-tour__btn--primary{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-tour__btn--primary:hover{background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}.bd-tour__btn:focus-visible,.bd-tour__skip:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .4))}@media(prefers-reduced-motion:reduce){.bd-tour__spot,.bd-tour__popover,.bd-tour__dot{transition:none;animation:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdTourComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-tour', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    @if (tour.active() && tour.step(); as step) {
      <div class="bd-tour" role="presentation">
        <!-- A sombra projetada maior que a tela escurece tudo, exceto este
             retângulo — o recorte não exige SVG nem máscara. -->
        <div
          class="bd-tour__spot"
          [class.bd-tour__spot--empty]="!hasTarget()"
          [style.top.px]="spot().top"
          [style.left.px]="spot().left"
          [style.width.px]="spot().width"
          [style.height.px]="spot().height"
        ></div>

        <!-- Captura o clique fora sem cobrir o alvo destacado. -->
        <div class="bd-tour__catch" (click)="tour.skip()"></div>

        <div
          #popover
          class="bd-tour__popover"
          [class]="'bd-tour__popover--' + position().side"
          [style.top.px]="position().top"
          [style.left.px]="position().left"
          role="dialog"
          aria-modal="true"
          [attr.aria-labelledby]="titleId"
          [attr.aria-describedby]="contentId"
          tabindex="-1"
        >
          <span class="bd-tour__arrow" aria-hidden="true"></span>

          <span class="bd-tour__counter">
            {{ tour.labels().counter(tour.index() + 1, tour.total()) }}
          </span>

          <h2 class="bd-tour__title" [id]="titleId">{{ step.title }}</h2>
          <p class="bd-tour__content" [id]="contentId">{{ step.content }}</p>

          <div class="bd-tour__dots" aria-hidden="true">
            @for (s of tour.steps(); track $index) {
              <span class="bd-tour__dot" [class.is-active]="$index === tour.index()"></span>
            }
          </div>

          <div class="bd-tour__actions">
            <button type="button" class="bd-tour__skip" (click)="tour.skip()">
              {{ tour.labels().skip }}
            </button>

            <div class="bd-tour__nav">
              @if (!tour.isFirst()) {
                <button type="button" class="bd-tour__btn" (click)="tour.prev()">
                  {{ tour.labels().prev }}
                </button>
              }
              <button
                type="button"
                class="bd-tour__btn bd-tour__btn--primary"
                (click)="tour.next()"
              >
                {{ step.nextLabel ?? (tour.isLast() ? tour.labels().finish : tour.labels().next) }}
              </button>
            </div>
          </div>
        </div>
      </div>
    }
  `, styles: [".bd-tour{position:fixed;inset:0;z-index:var(--bd-z-tooltip, 400);pointer-events:none}.bd-tour__spot{position:fixed;border-radius:var(--bd-radius, .875rem);box-shadow:0 0 0 9999px #03050aad;outline:2px solid var(--bd-primary, #3d5ce8);outline-offset:2px;transition:top .3s var(--bd-ease, ease),left .3s var(--bd-ease, ease),width .3s var(--bd-ease, ease),height .3s var(--bd-ease, ease);pointer-events:none}.bd-tour__spot--empty{outline:none}.bd-tour__catch{position:fixed;inset:0;pointer-events:auto}.bd-tour__popover{position:fixed;width:320px;max-width:calc(100vw - 2rem);padding:1.25rem 1.35rem 1.1rem;background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .35));color:var(--bd-fg, #10131c);pointer-events:auto;animation:bd-tour-in .24s var(--bd-ease, ease);transition:top .3s var(--bd-ease, ease),left .3s var(--bd-ease, ease)}.bd-tour__popover:focus{outline:none}@keyframes bd-tour-in{0%{opacity:0;transform:scale(.96)}to{opacity:1;transform:none}}.bd-tour__arrow{position:absolute;width:10px;height:10px;background:var(--bd-bg, #fff);border:1px solid var(--bd-border, #e3e7f0);transform:rotate(45deg)}.bd-tour__popover--bottom .bd-tour__arrow{top:-6px;left:28px;border-right:none;border-bottom:none}.bd-tour__popover--top .bd-tour__arrow{bottom:-6px;left:28px;border-left:none;border-top:none}.bd-tour__popover--right .bd-tour__arrow{left:-6px;top:24px;border-right:none;border-top:none}.bd-tour__popover--left .bd-tour__arrow{right:-6px;top:24px;border-left:none;border-bottom:none}.bd-tour__popover--center .bd-tour__arrow{display:none}.bd-tour__counter{display:block;margin-bottom:.35rem;color:var(--bd-primary, #3d5ce8);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:.06em;text-transform:uppercase}.bd-tour__title{margin:0 0 .4rem;font-size:var(--bd-text-lg, 1.125rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.015em}.bd-tour__content{margin:0;color:var(--bd-fg-muted, #545c70);font-size:.9rem;line-height:1.6}.bd-tour__dots{display:flex;gap:5px;margin:1rem 0 .9rem}.bd-tour__dot{width:6px;height:6px;background:var(--bd-border-strong, #cbd2e2);border-radius:50%;transition:background .2s ease,width .2s ease}.bd-tour__dot.is-active{width:18px;background:var(--bd-primary, #3d5ce8);border-radius:var(--bd-radius-full, 9999px)}.bd-tour__actions{display:flex;align-items:center;justify-content:space-between;gap:.75rem}.bd-tour__nav{display:flex;gap:.4rem}.bd-tour__btn,.bd-tour__skip{min-height:36px;padding:.4rem .9rem;border-radius:var(--bd-radius-sm, .5rem);font-family:inherit;font-size:.85rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:background .2s ease,color .2s ease,border-color .2s ease}.bd-tour__skip{padding-left:0;background:none;border:none;color:var(--bd-fg-subtle, #7b8399)}.bd-tour__skip:hover{color:var(--bd-fg, #10131c)}.bd-tour__btn{background:transparent;border:1px solid var(--bd-border-strong, #cbd2e2);color:var(--bd-fg, #10131c)}.bd-tour__btn:hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-tour__btn--primary{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-tour__btn--primary:hover{background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}.bd-tour__btn:focus-visible,.bd-tour__skip:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .4))}@media(prefers-reduced-motion:reduce){.bd-tour__spot,.bd-tour__popover,.bd-tour__dot{transition:none;animation:none}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { spotPadding: [{ type: i0.Input, args: [{ isSignal: true, alias: "spotPadding", required: false }] }], scrollIntoView: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollIntoView", required: false }] }], popover: [{ type: i0.ViewChild, args: ['popover', { isSignal: true }] }], onKeydown: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/**
 * Revela o elemento quando ele entra na viewport.
 *
 * A transição anima apenas `opacity` e `transform` — propriedades compostas
 * na GPU —, portanto não bloqueia a rolagem. O observador é desconectado assim
 * que o elemento entra em cena.
 *
 * Não exige configuração de estilos: as regras de base são garantidas em tempo
 * de execução e permanecem sobrescrevíveis pela folha
 * `bandeira-ui/styles/animations` ou pelo CSS da aplicação.
 *
 * Compatível com renderização no servidor: a configuração ocorre dentro de
 * `afterNextRender`, que só executa no navegador.
 *
 * @example
 * ```html
 * <div bdReveal></div>
 * <div bdReveal="left" [revealDelay]="120"></div>
 * <div bdReveal="scale" [revealOnce]="false"></div>
 * ```
 */
class BdRevealDirective {
    /** Direção de entrada do elemento. */
    bdReveal = input('up', ...(ngDevMode ? [{ debugName: "bdReveal" }] : []));
    /** Atraso em milissegundos — use `i * 80` em listas para criar cascata. */
    revealDelay = input(0, ...(ngDevMode ? [{ debugName: "revealDelay" }] : []));
    /** Quando `false`, o elemento volta a esconder ao sair da viewport. */
    revealOnce = input(true, ...(ngDevMode ? [{ debugName: "revealOnce", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    host = inject(ElementRef);
    document = inject(DOCUMENT);
    observer;
    constructor() {
        inject(DestroyRef).onDestroy(() => this.observer?.disconnect());
        afterNextRender(() => this.setup());
    }
    setup() {
        const el = this.host.nativeElement;
        ensureBdRuntimeStyles(this.document);
        const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
        // Sem IntersectionObserver ou com movimento reduzido, o conteúdo aparece
        // imediatamente: a animação é enfeite, o conteúdo é o que importa.
        if (reducedMotion || typeof IntersectionObserver === 'undefined') {
            el.classList.add('bd-reveal', 'is-visible');
            return;
        }
        el.classList.add('bd-reveal', `bd-reveal--${this.bdReveal() || 'up'}`);
        if (this.revealDelay() > 0) {
            el.style.transitionDelay = `${this.revealDelay()}ms`;
        }
        this.observer = new IntersectionObserver((entries) => {
            for (const entry of entries) {
                if (entry.isIntersecting) {
                    el.classList.add('is-visible');
                    if (this.revealOnce()) {
                        this.observer?.disconnect();
                    }
                }
                else if (!this.revealOnce()) {
                    el.classList.remove('is-visible');
                }
            }
        }, 
        // Dispara um pouco antes da borda inferior: o movimento fica natural.
        { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
        this.observer.observe(el);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdRevealDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "20.3.27", type: BdRevealDirective, isStandalone: true, selector: "[bdReveal]", inputs: { bdReveal: { classPropertyName: "bdReveal", publicName: "bdReveal", isSignal: true, isRequired: false, transformFunction: null }, revealDelay: { classPropertyName: "revealDelay", publicName: "revealDelay", isSignal: true, isRequired: false, transformFunction: null }, revealOnce: { classPropertyName: "revealOnce", publicName: "revealOnce", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdRevealDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[bdReveal]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { bdReveal: [{ type: i0.Input, args: [{ isSignal: true, alias: "bdReveal", required: false }] }], revealDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "revealDelay", required: false }] }], revealOnce: [{ type: i0.Input, args: [{ isSignal: true, alias: "revealOnce", required: false }] }] } });

/**
 * Estrutura de painel analítico: cabeçalho, faixa de indicadores e uma grade
 * de conteúdo com coluna principal e coluna lateral.
 *
 * A hierarquia é deliberada — indicadores no topo respondem "como estamos?" em
 * um relance; a coluna principal desenvolve a resposta; a lateral concentra o
 * secundário. Abaixo de 1080px as colunas se empilham e a lateral desce, de
 * modo que a leitura no celular preserva a mesma ordem de importância.
 *
 * @example
 * ```html
 * <bd-dashboard-template
 *   title="Visão geral"
 *   description="Desempenho consolidado dos últimos 30 dias."
 * >
 *   <button bdButton bdDashboardActions>Exportar</button>
 *
 *   <bd-metric bdDashboardMetrics label="Receita" value="R$ 128k" />
 *   <bd-metric bdDashboardMetrics label="Assinantes" value="2.480" />
 *
 *   <bd-card>Gráfico principal</bd-card>
 *
 *   <bd-card bdDashboardAside>Atividade recente</bd-card>
 * </bd-dashboard-template>
 * ```
 */
class BdDashboardTemplateComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /** Rótulo acessível da coluna lateral. */
    asideLabel = input('Informações complementares', ...(ngDevMode ? [{ debugName: "asideLabel" }] : []));
    /**
     * Reserva a coluna lateral. Precisa ser declarado porque o conteúdo
     * projetado não é observável a partir do componente: a decisão de layout
     * pertence a quem monta a tela.
     */
    hasAside = input(false, ...(ngDevMode ? [{ debugName: "hasAside", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdDashboardTemplateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdDashboardTemplateComponent, isStandalone: true, selector: "bd-dashboard-template", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, asideLabel: { classPropertyName: "asideLabel", publicName: "asideLabel", isSignal: true, isRequired: false, transformFunction: null }, hasAside: { classPropertyName: "hasAside", publicName: "hasAside", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <header class="bd-dashboard__head">
      <div class="bd-dashboard__headings">
        <h1 class="bd-dashboard__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-dashboard__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-dashboard__actions">
        <ng-content select="[bdDashboardActions]" />
      </div>
    </header>

    <!-- Faixa de indicadores: a resposta imediata da tela. -->
    <div class="bd-dashboard__metrics">
      <ng-content select="[bdDashboardMetrics]" />
    </div>

    <div class="bd-dashboard__grid" [class.bd-dashboard__grid--single]="!hasAside()">
      <div class="bd-dashboard__main">
        <ng-content />
      </div>

      @if (hasAside()) {
        <aside class="bd-dashboard__aside" [attr.aria-label]="asideLabel()">
          <ng-content select="[bdDashboardAside]" />
        </aside>
      }
    </div>
  `, isInline: true, styles: [":host{display:block;--bd-dashboard-aside-w: 340px}.bd-dashboard__head{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem);margin-bottom:var(--bd-space-6, 2rem)}.bd-dashboard__headings{min-width:0}.bd-dashboard__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-dashboard__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-dashboard__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-dashboard__metrics:not(:empty){display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:var(--bd-space-4, 1rem);margin-bottom:var(--bd-space-6, 2rem)}.bd-dashboard__grid{display:grid;grid-template-columns:minmax(0,1fr) var(--bd-dashboard-aside-w);align-items:start;gap:var(--bd-space-5, 1.5rem)}.bd-dashboard__grid--single{grid-template-columns:minmax(0,1fr)}.bd-dashboard__main,.bd-dashboard__aside{display:flex;flex-direction:column;gap:var(--bd-space-4, 1rem);min-width:0}@media(max-width:1080px){.bd-dashboard__grid{grid-template-columns:minmax(0,1fr)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdDashboardTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-dashboard-template', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <header class="bd-dashboard__head">
      <div class="bd-dashboard__headings">
        <h1 class="bd-dashboard__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-dashboard__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-dashboard__actions">
        <ng-content select="[bdDashboardActions]" />
      </div>
    </header>

    <!-- Faixa de indicadores: a resposta imediata da tela. -->
    <div class="bd-dashboard__metrics">
      <ng-content select="[bdDashboardMetrics]" />
    </div>

    <div class="bd-dashboard__grid" [class.bd-dashboard__grid--single]="!hasAside()">
      <div class="bd-dashboard__main">
        <ng-content />
      </div>

      @if (hasAside()) {
        <aside class="bd-dashboard__aside" [attr.aria-label]="asideLabel()">
          <ng-content select="[bdDashboardAside]" />
        </aside>
      }
    </div>
  `, styles: [":host{display:block;--bd-dashboard-aside-w: 340px}.bd-dashboard__head{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem);margin-bottom:var(--bd-space-6, 2rem)}.bd-dashboard__headings{min-width:0}.bd-dashboard__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-dashboard__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-dashboard__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-dashboard__metrics:not(:empty){display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:var(--bd-space-4, 1rem);margin-bottom:var(--bd-space-6, 2rem)}.bd-dashboard__grid{display:grid;grid-template-columns:minmax(0,1fr) var(--bd-dashboard-aside-w);align-items:start;gap:var(--bd-space-5, 1.5rem)}.bd-dashboard__grid--single{grid-template-columns:minmax(0,1fr)}.bd-dashboard__main,.bd-dashboard__aside{display:flex;flex-direction:column;gap:var(--bd-space-4, 1rem);min-width:0}@media(max-width:1080px){.bd-dashboard__grid{grid-template-columns:minmax(0,1fr)}}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], asideLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "asideLabel", required: false }] }], hasAside: [{ type: i0.Input, args: [{ isSignal: true, alias: "hasAside", required: false }] }] } });

/**
 * Estrutura de listagem para telas de cadastro e consulta: cabeçalho, barra de
 * busca e filtros, área de resultados e rodapé de paginação.
 *
 * Os três estados de uma listagem — carregando, vazia e preenchida — são
 * mutuamente exclusivos e ficam sob responsabilidade do template. Isso elimina
 * a repetição de `@if` em cada tela e, mais importante, elimina a divergência:
 * o estado de carregamento é anunciado por `aria-busy` em toda a aplicação, e
 * não apenas onde alguém lembrou de fazê-lo.
 *
 * @example
 * ```html
 * <bd-list-template
 *   title="Projetos"
 *   description="Tudo que está em andamento na sua equipe."
 *   [loading]="carregando()"
 *   [empty]="projetos().length === 0"
 * >
 *   <button bdButton bdListActions>Novo projeto</button>
 *
 *   <input bdInput bdListSearch type="search" placeholder="Buscar projetos" />
 *   <bd-chip bdListFilters selectable>Ativos</bd-chip>
 *
 *   <bd-empty-state bdListEmpty title="Nenhum projeto ainda" />
 *
 *   <table>…</table>
 *
 *   <span bdListFooter>24 resultados</span>
 * </bd-list-template>
 * ```
 */
class BdListTemplateComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    /** Exibe os placeholders no lugar dos resultados. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Exibe o conteúdo de `[bdListEmpty]` no lugar dos resultados. */
    empty = input(false, ...(ngDevMode ? [{ debugName: "empty", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Quantidade de linhas de placeholder durante o carregamento. */
    placeholderCount = input(5, ...(ngDevMode ? [{ debugName: "placeholderCount" }] : []));
    /** Texto anunciado por leitores de tela durante o carregamento. */
    loadingLabel = input('Carregando resultados…', ...(ngDevMode ? [{ debugName: "loadingLabel" }] : []));
    // Derivado como signal, não como método: a lista de placeholders é
    // recalculada quando a contagem muda, não a cada ciclo de detecção.
    placeholderRows = computed(() => Array.from({ length: Math.max(1, this.placeholderCount()) }, (_, index) => index), ...(ngDevMode ? [{ debugName: "placeholderRows" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdListTemplateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdListTemplateComponent, isStandalone: true, selector: "bd-list-template", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, empty: { classPropertyName: "empty", publicName: "empty", isSignal: true, isRequired: false, transformFunction: null }, placeholderCount: { classPropertyName: "placeholderCount", publicName: "placeholderCount", isSignal: true, isRequired: false, transformFunction: null }, loadingLabel: { classPropertyName: "loadingLabel", publicName: "loadingLabel", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <header class="bd-list__head">
      <div class="bd-list__headings">
        <h1 class="bd-list__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-list__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-list__actions">
        <ng-content select="[bdListActions]" />
      </div>
    </header>

    <div class="bd-list__toolbar">
      <div class="bd-list__search">
        <ng-content select="[bdListSearch]" />
      </div>
      <div class="bd-list__filters">
        <ng-content select="[bdListFilters]" />
      </div>
    </div>

    <section class="bd-list__body" [attr.aria-busy]="loading()">
      @if (loading()) {
        <!-- Skeleton com a forma do resultado: a troca não desloca a página. -->
        <div class="bd-list__skeleton">
          @for (row of placeholderRows(); track row) {
            <bd-skeleton variant="rect" height="52px" />
          }
        </div>
        <span class="bd-sr-only" role="status">{{ loadingLabel() }}</span>
      } @else if (empty()) {
        <ng-content select="[bdListEmpty]" />
      } @else {
        <ng-content />
      }
    </section>

    <footer class="bd-list__footer">
      <ng-content select="[bdListFooter]" />
    </footer>
  `, isInline: true, styles: [":host{display:block}.bd-list__head{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem)}.bd-list__headings{min-width:0}.bd-list__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-list__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-list__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-list__toolbar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem)}.bd-list__search{flex:1 1 260px;min-width:0;max-width:380px}.bd-list__filters:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-list__body{margin-top:var(--bd-space-5, 1.5rem);min-height:120px}.bd-list__skeleton{display:flex;flex-direction:column;gap:var(--bd-space-2, .5rem)}.bd-list__footer:not(:empty){display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem);padding-top:var(--bd-space-4, 1rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem)}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:640px){.bd-list__search{max-width:none}}\n"], dependencies: [{ kind: "component", type: BdSkeletonComponent, selector: "bd-skeleton", inputs: ["variant", "width", "height"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdListTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-list-template', standalone: true, imports: [BdSkeletonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <header class="bd-list__head">
      <div class="bd-list__headings">
        <h1 class="bd-list__title">{{ title() }}</h1>
        @if (description()) {
          <p class="bd-list__desc">{{ description() }}</p>
        }
      </div>

      <div class="bd-list__actions">
        <ng-content select="[bdListActions]" />
      </div>
    </header>

    <div class="bd-list__toolbar">
      <div class="bd-list__search">
        <ng-content select="[bdListSearch]" />
      </div>
      <div class="bd-list__filters">
        <ng-content select="[bdListFilters]" />
      </div>
    </div>

    <section class="bd-list__body" [attr.aria-busy]="loading()">
      @if (loading()) {
        <!-- Skeleton com a forma do resultado: a troca não desloca a página. -->
        <div class="bd-list__skeleton">
          @for (row of placeholderRows(); track row) {
            <bd-skeleton variant="rect" height="52px" />
          }
        </div>
        <span class="bd-sr-only" role="status">{{ loadingLabel() }}</span>
      } @else if (empty()) {
        <ng-content select="[bdListEmpty]" />
      } @else {
        <ng-content />
      }
    </section>

    <footer class="bd-list__footer">
      <ng-content select="[bdListFooter]" />
    </footer>
  `, styles: [":host{display:block}.bd-list__head{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-4, 1rem)}.bd-list__headings{min-width:0}.bd-list__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-list__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-list__actions:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem);flex-shrink:0}.bd-list__toolbar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem)}.bd-list__search{flex:1 1 260px;min-width:0;max-width:380px}.bd-list__filters:not(:empty){display:flex;flex-wrap:wrap;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-list__body{margin-top:var(--bd-space-5, 1.5rem);min-height:120px}.bd-list__skeleton{display:flex;flex-direction:column;gap:var(--bd-space-2, .5rem)}.bd-list__footer:not(:empty){display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem);padding-top:var(--bd-space-4, 1rem);border-top:1px solid var(--bd-border, #e3e7f0);color:var(--bd-fg-muted, #545c70);font-size:var(--bd-text-sm, .875rem)}.bd-sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}@media(max-width:640px){.bd-list__search{max-width:none}}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], empty: [{ type: i0.Input, args: [{ isSignal: true, alias: "empty", required: false }] }], placeholderCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholderCount", required: false }] }], loadingLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingLabel", required: false }] }] } });

/**
 * Estrutura de preferências: navegação por seções à esquerda, formulário à
 * direita e barra de gravação fixa ao pé da tela.
 *
 * A navegação é uma lista de âncoras reais, não um seletor decorativo: cada
 * seção permanece endereçável por URL, localizável pela busca do navegador e
 * acessível ao leitor de tela, que percorre o formulário inteiro em ordem.
 *
 * A barra de gravação só aparece quando há alterações pendentes — uma barra
 * permanentemente visível deixa de comunicar qualquer coisa.
 *
 * @example
 * ```html
 * <bd-settings-template
 *   title="Configurações"
 *   [sections]="secoes"
 *   [(activeSection)]="secaoAtual"
 *   [dirty]="formulario.dirty"
 * >
 *   <section id="perfil">…</section>
 *   <section id="notificacoes">…</section>
 *
 *   <button bdButton bdSettingsActions variant="ghost" (click)="restaurar()">Descartar</button>
 *   <button bdButton bdSettingsActions (click)="salvar()">Salvar alterações</button>
 * </bd-settings-template>
 * ```
 */
class BdSettingsTemplateComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    sections = input([], ...(ngDevMode ? [{ debugName: "sections" }] : []));
    /** Two-way: `[(activeSection)]="secaoAtual"`. */
    activeSection = model('', ...(ngDevMode ? [{ debugName: "activeSection" }] : []));
    /** Revela a barra de gravação. Ligue ao estado do formulário. */
    dirty = input(false, ...(ngDevMode ? [{ debugName: "dirty", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    dirtyLabel = input('Você tem alterações não salvas.', ...(ngDevMode ? [{ debugName: "dirtyLabel" }] : []));
    navLabel = input('Seções de configuração', ...(ngDevMode ? [{ debugName: "navLabel" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSettingsTemplateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdSettingsTemplateComponent, isStandalone: true, selector: "bd-settings-template", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, sections: { classPropertyName: "sections", publicName: "sections", isSignal: true, isRequired: false, transformFunction: null }, activeSection: { classPropertyName: "activeSection", publicName: "activeSection", isSignal: true, isRequired: false, transformFunction: null }, dirty: { classPropertyName: "dirty", publicName: "dirty", isSignal: true, isRequired: false, transformFunction: null }, dirtyLabel: { classPropertyName: "dirtyLabel", publicName: "dirtyLabel", isSignal: true, isRequired: false, transformFunction: null }, navLabel: { classPropertyName: "navLabel", publicName: "navLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeSection: "activeSectionChange" }, ngImport: i0, template: `
    <header class="bd-settings__head">
      <h1 class="bd-settings__title">{{ title() }}</h1>
      @if (description()) {
        <p class="bd-settings__desc">{{ description() }}</p>
      }
    </header>

    <div class="bd-settings__body">
      <nav class="bd-settings__nav" [attr.aria-label]="navLabel()">
        <ul>
          @for (section of sections(); track section.id) {
            <li>
              <a
                [href]="'#' + section.id"
                [class.is-active]="section.id === activeSection()"
                [attr.aria-current]="section.id === activeSection() ? 'true' : null"
                (click)="activeSection.set(section.id)"
              >
                <span class="bd-settings__nav-label">{{ section.label }}</span>
                @if (section.hint) {
                  <span class="bd-settings__nav-hint">{{ section.hint }}</span>
                }
              </a>
            </li>
          }
        </ul>
      </nav>

      <div class="bd-settings__content">
        <ng-content />
      </div>
    </div>

    @if (dirty()) {
      <!-- role="status": a barra é anunciada sem interromper a digitação. -->
      <div class="bd-settings__bar" role="status">
        <span class="bd-settings__bar-text">{{ dirtyLabel() }}</span>
        <div class="bd-settings__bar-actions">
          <ng-content select="[bdSettingsActions]" />
        </div>
      </div>
    }
  `, isInline: true, styles: [":host{display:block;--bd-settings-nav-w: 232px;padding-bottom:var(--bd-space-7, 3rem)}.bd-settings__head{padding-bottom:var(--bd-space-5, 1.5rem);margin-bottom:var(--bd-space-6, 2rem);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-settings__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-settings__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-settings__body{display:grid;grid-template-columns:var(--bd-settings-nav-w) minmax(0,1fr);align-items:start;gap:var(--bd-space-6, 2rem)}.bd-settings__nav{position:sticky;top:var(--bd-space-5, 1.5rem)}.bd-settings__nav ul{display:flex;flex-direction:column;gap:2px;margin:0;padding:0;list-style:none}.bd-settings__nav a{display:block;padding:.55rem .75rem;border-left:2px solid transparent;border-radius:0 var(--bd-radius-sm, .5rem) var(--bd-radius-sm, .5rem) 0;color:var(--bd-fg-muted, #545c70);font-size:.9rem;text-decoration:none;transition:color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}.bd-settings__nav a:hover{background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg, #10131c)}.bd-settings__nav a.is-active{border-left-color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8);font-weight:var(--bd-weight-semibold, 600)}.bd-settings__nav a:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-settings__nav-label{display:block}.bd-settings__nav-hint{display:block;margin-top:.1rem;color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-normal, 400)}.bd-settings__content{display:flex;flex-direction:column;gap:var(--bd-space-6, 2rem);min-width:0}.bd-settings__bar{position:sticky;bottom:var(--bd-space-4, 1rem);z-index:var(--bd-z-sticky, 30);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-6, 2rem);padding:var(--bd-space-3, .75rem) var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius, .875rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .12));animation:bd-settings-bar-in .22s var(--bd-ease, ease)}@keyframes bd-settings-bar-in{0%{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}.bd-settings__bar-text{color:var(--bd-fg-muted, #545c70);font-size:.9rem;font-weight:var(--bd-weight-medium, 500)}.bd-settings__bar-actions{display:flex;align-items:center;gap:var(--bd-space-2, .5rem)}@media(prefers-reduced-motion:reduce){.bd-settings__bar{animation:none}}@media(max-width:860px){.bd-settings__body{grid-template-columns:minmax(0,1fr);gap:var(--bd-space-5, 1.5rem)}.bd-settings__nav{position:static;overflow-x:auto}.bd-settings__nav ul{flex-direction:row;gap:var(--bd-space-2, .5rem)}.bd-settings__nav a{white-space:nowrap;border-left:none;border-bottom:2px solid transparent;border-radius:var(--bd-radius-sm, .5rem)}.bd-settings__nav a.is-active{border-left-color:transparent;border-bottom-color:var(--bd-primary, #3d5ce8)}.bd-settings__nav-hint{display:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdSettingsTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-settings-template', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <header class="bd-settings__head">
      <h1 class="bd-settings__title">{{ title() }}</h1>
      @if (description()) {
        <p class="bd-settings__desc">{{ description() }}</p>
      }
    </header>

    <div class="bd-settings__body">
      <nav class="bd-settings__nav" [attr.aria-label]="navLabel()">
        <ul>
          @for (section of sections(); track section.id) {
            <li>
              <a
                [href]="'#' + section.id"
                [class.is-active]="section.id === activeSection()"
                [attr.aria-current]="section.id === activeSection() ? 'true' : null"
                (click)="activeSection.set(section.id)"
              >
                <span class="bd-settings__nav-label">{{ section.label }}</span>
                @if (section.hint) {
                  <span class="bd-settings__nav-hint">{{ section.hint }}</span>
                }
              </a>
            </li>
          }
        </ul>
      </nav>

      <div class="bd-settings__content">
        <ng-content />
      </div>
    </div>

    @if (dirty()) {
      <!-- role="status": a barra é anunciada sem interromper a digitação. -->
      <div class="bd-settings__bar" role="status">
        <span class="bd-settings__bar-text">{{ dirtyLabel() }}</span>
        <div class="bd-settings__bar-actions">
          <ng-content select="[bdSettingsActions]" />
        </div>
      </div>
    }
  `, styles: [":host{display:block;--bd-settings-nav-w: 232px;padding-bottom:var(--bd-space-7, 3rem)}.bd-settings__head{padding-bottom:var(--bd-space-5, 1.5rem);margin-bottom:var(--bd-space-6, 2rem);border-bottom:1px solid var(--bd-border, #e3e7f0)}.bd-settings__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-settings__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-settings__body{display:grid;grid-template-columns:var(--bd-settings-nav-w) minmax(0,1fr);align-items:start;gap:var(--bd-space-6, 2rem)}.bd-settings__nav{position:sticky;top:var(--bd-space-5, 1.5rem)}.bd-settings__nav ul{display:flex;flex-direction:column;gap:2px;margin:0;padding:0;list-style:none}.bd-settings__nav a{display:block;padding:.55rem .75rem;border-left:2px solid transparent;border-radius:0 var(--bd-radius-sm, .5rem) var(--bd-radius-sm, .5rem) 0;color:var(--bd-fg-muted, #545c70);font-size:.9rem;text-decoration:none;transition:color var(--bd-duration, .25s) ease,background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease}.bd-settings__nav a:hover{background:var(--bd-surface-hover, #f1f3f9);color:var(--bd-fg, #10131c)}.bd-settings__nav a.is-active{border-left-color:var(--bd-primary, #3d5ce8);background:var(--bd-primary-soft, rgba(61, 92, 232, .1));color:var(--bd-primary, #3d5ce8);font-weight:var(--bd-weight-semibold, 600)}.bd-settings__nav a:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}.bd-settings__nav-label{display:block}.bd-settings__nav-hint{display:block;margin-top:.1rem;color:var(--bd-fg-subtle, #7b8399);font-size:var(--bd-text-xs, .75rem);font-weight:var(--bd-weight-normal, 400)}.bd-settings__content{display:flex;flex-direction:column;gap:var(--bd-space-6, 2rem);min-width:0}.bd-settings__bar{position:sticky;bottom:var(--bd-space-4, 1rem);z-index:var(--bd-z-sticky, 30);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-6, 2rem);padding:var(--bd-space-3, .75rem) var(--bd-space-4, 1rem);background:var(--bd-bg, #fff);border:1px solid var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius, .875rem);box-shadow:var(--bd-shadow-lg, 0 24px 60px rgba(16, 19, 28, .12));animation:bd-settings-bar-in .22s var(--bd-ease, ease)}@keyframes bd-settings-bar-in{0%{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}.bd-settings__bar-text{color:var(--bd-fg-muted, #545c70);font-size:.9rem;font-weight:var(--bd-weight-medium, 500)}.bd-settings__bar-actions{display:flex;align-items:center;gap:var(--bd-space-2, .5rem)}@media(prefers-reduced-motion:reduce){.bd-settings__bar{animation:none}}@media(max-width:860px){.bd-settings__body{grid-template-columns:minmax(0,1fr);gap:var(--bd-space-5, 1.5rem)}.bd-settings__nav{position:static;overflow-x:auto}.bd-settings__nav ul{flex-direction:row;gap:var(--bd-space-2, .5rem)}.bd-settings__nav a{white-space:nowrap;border-left:none;border-bottom:2px solid transparent;border-radius:var(--bd-radius-sm, .5rem)}.bd-settings__nav a.is-active{border-left-color:transparent;border-bottom-color:var(--bd-primary, #3d5ce8)}.bd-settings__nav-hint{display:none}}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], sections: [{ type: i0.Input, args: [{ isSignal: true, alias: "sections", required: false }] }], activeSection: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeSection", required: false }] }, { type: i0.Output, args: ["activeSectionChange"] }], dirty: [{ type: i0.Input, args: [{ isSignal: true, alias: "dirty", required: false }] }], dirtyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "dirtyLabel", required: false }] }], navLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "navLabel", required: false }] }] } });

/**
 * Estrutura de assistente por etapas: indicador de progresso, área da etapa
 * atual e rodapé de navegação.
 *
 * O indicador é uma lista ordenada real, anotada com `aria-current="step"`, de
 * modo que a posição no processo é anunciada e não apenas colorida. Etapas já
 * concluídas voltam a ser navegáveis; as futuras permanecem bloqueadas,
 * porque avançar sem completar a etapa corrente produz dados inconsistentes.
 *
 * A validação é do formulário, não do template: enquanto `canAdvance` for
 * `false`, o botão de avanço fica desabilitado e `next` não é emitido.
 *
 * @example
 * ```html
 * <bd-wizard-template
 *   title="Novo projeto"
 *   [steps]="etapas"
 *   [(activeStep)]="etapa"
 *   [canAdvance]="formulario.valid"
 *   (finish)="concluir()"
 * >
 *   @switch (etapa()) {
 *     @case (0) { <section>Dados básicos</section> }
 *     @case (1) { <section>Equipe</section> }
 *   }
 * </bd-wizard-template>
 * ```
 */
class BdWizardTemplateComponent {
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : []));
    description = input('', ...(ngDevMode ? [{ debugName: "description" }] : []));
    steps = input([], ...(ngDevMode ? [{ debugName: "steps" }] : []));
    /** Two-way: `[(activeStep)]="etapa"`. */
    activeStep = model(0, ...(ngDevMode ? [{ debugName: "activeStep" }] : []));
    /**
     * Libera o avanço. Ligue à validade do formulário da etapa corrente — com
     * `false`, o botão fica desabilitado e nenhum evento é emitido.
     */
    canAdvance = input(true, ...(ngDevMode ? [{ debugName: "canAdvance", transform: booleanAttribute }] : [{ transform: booleanAttribute }]));
    /** Estilo do indicador de progresso. Ver {@link BdStepsVariant}. */
    stepsVariant = input('panel', ...(ngDevMode ? [{ debugName: "stepsVariant" }] : []));
    previousLabel = input('Voltar', ...(ngDevMode ? [{ debugName: "previousLabel" }] : []));
    nextLabel = input('Continuar', ...(ngDevMode ? [{ debugName: "nextLabel" }] : []));
    finishLabel = input('Concluir', ...(ngDevMode ? [{ debugName: "finishLabel" }] : []));
    stepsLabel = input('Etapas do processo', ...(ngDevMode ? [{ debugName: "stepsLabel" }] : []));
    /** Emitido ao entrar em uma etapa, com o índice de destino. */
    stepChange = output();
    /** Emitido ao confirmar a última etapa. */
    finish = output();
    isFirst = computed(() => this.activeStep() === 0, ...(ngDevMode ? [{ debugName: "isFirst" }] : []));
    isLast = computed(() => this.activeStep() >= Math.max(0, this.steps().length - 1), ...(ngDevMode ? [{ debugName: "isLast" }] : []));
    advance() {
        if (!this.canAdvance())
            return;
        if (this.isLast()) {
            this.finish.emit();
            return;
        }
        this.setStep(this.activeStep() + 1);
    }
    previous() {
        if (!this.isFirst()) {
            this.setStep(this.activeStep() - 1);
        }
    }
    /**
     * Aplica a etapa de destino. O indicador só emite índices anteriores ao
     * corrente — saltar adiante nunca é permitido, porque o template não tem como
     * saber se as etapas intermediárias foram preenchidas. O avanço passa por
     * `advance()`, que respeita `canAdvance`.
     */
    setStep(index) {
        if (index < 0 || index >= this.steps().length || index === this.activeStep())
            return;
        this.activeStep.set(index);
        this.stepChange.emit(index);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdWizardTemplateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.27", type: BdWizardTemplateComponent, isStandalone: true, selector: "bd-wizard-template", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, steps: { classPropertyName: "steps", publicName: "steps", isSignal: true, isRequired: false, transformFunction: null }, activeStep: { classPropertyName: "activeStep", publicName: "activeStep", isSignal: true, isRequired: false, transformFunction: null }, canAdvance: { classPropertyName: "canAdvance", publicName: "canAdvance", isSignal: true, isRequired: false, transformFunction: null }, stepsVariant: { classPropertyName: "stepsVariant", publicName: "stepsVariant", isSignal: true, isRequired: false, transformFunction: null }, previousLabel: { classPropertyName: "previousLabel", publicName: "previousLabel", isSignal: true, isRequired: false, transformFunction: null }, nextLabel: { classPropertyName: "nextLabel", publicName: "nextLabel", isSignal: true, isRequired: false, transformFunction: null }, finishLabel: { classPropertyName: "finishLabel", publicName: "finishLabel", isSignal: true, isRequired: false, transformFunction: null }, stepsLabel: { classPropertyName: "stepsLabel", publicName: "stepsLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeStep: "activeStepChange", stepChange: "stepChange", finish: "finish" }, ngImport: i0, template: `
    <header class="bd-wizard__head">
      <h1 class="bd-wizard__title">{{ title() }}</h1>
      @if (description()) {
        <p class="bd-wizard__desc">{{ description() }}</p>
      }
    </header>

    <bd-steps
      class="bd-wizard__steps"
      [steps]="steps()"
      [active]="activeStep()"
      [variant]="stepsVariant()"
      [label]="stepsLabel()"
      clickable
      (stepChange)="setStep($event)"
    />

    <section class="bd-wizard__panel">
      <ng-content />
    </section>

    <footer class="bd-wizard__footer">
      <button type="button" class="bd-wizard__btn" [disabled]="isFirst()" (click)="previous()">
        {{ previousLabel() }}
      </button>

      <div class="bd-wizard__footer-right">
        <ng-content select="[bdWizardActions]" />

        <button
          type="button"
          class="bd-wizard__btn bd-wizard__btn--primary"
          [disabled]="!canAdvance()"
          (click)="advance()"
        >
          {{ isLast() ? finishLabel() : nextLabel() }}
        </button>
      </div>
    </footer>
  `, isInline: true, styles: [":host{display:block}.bd-wizard__head{margin-bottom:var(--bd-space-5, 1.5rem)}.bd-wizard__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-wizard__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-wizard__steps{display:block;margin-bottom:var(--bd-space-5, 1.5rem)}.bd-wizard__panel{padding:var(--bd-space-5, 1.5rem);background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem)}.bd-wizard__footer{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem)}.bd-wizard__footer-right{display:flex;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-wizard__btn{min-height:44px;padding:.7rem 1.4rem;background:transparent;border:1px solid var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font-family:inherit;font-size:.95rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.bd-wizard__btn:disabled{opacity:.55;cursor:not-allowed}.bd-wizard__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-wizard__btn--primary{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-wizard__btn--primary:not(:disabled):hover{background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}.bd-wizard__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}@media(max-width:640px){.bd-wizard__footer,.bd-wizard__footer-right{width:100%}.bd-wizard__btn{flex:1 1 auto}}\n"], dependencies: [{ kind: "component", type: BdStepsComponent, selector: "bd-steps", inputs: ["steps", "active", "variant", "orientation", "clickable", "label", "counter"], outputs: ["activeChange", "stepChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.27", ngImport: i0, type: BdWizardTemplateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'bd-wizard-template', standalone: true, imports: [BdStepsComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <header class="bd-wizard__head">
      <h1 class="bd-wizard__title">{{ title() }}</h1>
      @if (description()) {
        <p class="bd-wizard__desc">{{ description() }}</p>
      }
    </header>

    <bd-steps
      class="bd-wizard__steps"
      [steps]="steps()"
      [active]="activeStep()"
      [variant]="stepsVariant()"
      [label]="stepsLabel()"
      clickable
      (stepChange)="setStep($event)"
    />

    <section class="bd-wizard__panel">
      <ng-content />
    </section>

    <footer class="bd-wizard__footer">
      <button type="button" class="bd-wizard__btn" [disabled]="isFirst()" (click)="previous()">
        {{ previousLabel() }}
      </button>

      <div class="bd-wizard__footer-right">
        <ng-content select="[bdWizardActions]" />

        <button
          type="button"
          class="bd-wizard__btn bd-wizard__btn--primary"
          [disabled]="!canAdvance()"
          (click)="advance()"
        >
          {{ isLast() ? finishLabel() : nextLabel() }}
        </button>
      </div>
    </footer>
  `, styles: [":host{display:block}.bd-wizard__head{margin-bottom:var(--bd-space-5, 1.5rem)}.bd-wizard__title{margin:0;font-size:clamp(1.5rem,3vw,1.9rem);font-weight:var(--bd-weight-bold, 700);letter-spacing:-.025em;color:var(--bd-fg, #10131c)}.bd-wizard__desc{max-width:62ch;margin:.35rem 0 0;color:var(--bd-fg-muted, #545c70);font-size:.95rem;line-height:1.6}.bd-wizard__steps{display:block;margin-bottom:var(--bd-space-5, 1.5rem)}.bd-wizard__panel{padding:var(--bd-space-5, 1.5rem);background:var(--bd-surface, #fff);border:1px solid var(--bd-border, #e3e7f0);border-radius:var(--bd-radius-lg, 1.25rem)}.bd-wizard__footer{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:var(--bd-space-3, .75rem);margin-top:var(--bd-space-5, 1.5rem)}.bd-wizard__footer-right{display:flex;align-items:center;gap:var(--bd-space-2, .5rem)}.bd-wizard__btn{min-height:44px;padding:.7rem 1.4rem;background:transparent;border:1px solid var(--bd-border-strong, #cbd2e2);border-radius:var(--bd-radius-sm, .5rem);color:var(--bd-fg, #10131c);font-family:inherit;font-size:.95rem;font-weight:var(--bd-weight-semibold, 600);cursor:pointer;transition:background var(--bd-duration, .25s) ease,border-color var(--bd-duration, .25s) ease,color var(--bd-duration, .25s) ease}.bd-wizard__btn:disabled{opacity:.55;cursor:not-allowed}.bd-wizard__btn:not(:disabled):hover{border-color:var(--bd-primary, #3d5ce8);color:var(--bd-primary, #3d5ce8)}.bd-wizard__btn--primary{background:var(--bd-primary-strong, #2b46c9);border-color:transparent;color:var(--bd-primary-contrast, #fff)}.bd-wizard__btn--primary:not(:disabled):hover{background:var(--bd-primary, #3d5ce8);color:var(--bd-primary-contrast, #fff)}.bd-wizard__btn:focus-visible{outline:none;box-shadow:var(--bd-focus-ring, 0 0 0 3px rgba(61, 92, 232, .3))}@media(max-width:640px){.bd-wizard__footer,.bd-wizard__footer-right{width:100%}.bd-wizard__btn{flex:1 1 auto}}\n"] }]
        }], propDecorators: { title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], steps: [{ type: i0.Input, args: [{ isSignal: true, alias: "steps", required: false }] }], activeStep: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeStep", required: false }] }, { type: i0.Output, args: ["activeStepChange"] }], canAdvance: [{ type: i0.Input, args: [{ isSignal: true, alias: "canAdvance", required: false }] }], stepsVariant: [{ type: i0.Input, args: [{ isSignal: true, alias: "stepsVariant", required: false }] }], previousLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "previousLabel", required: false }] }], nextLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextLabel", required: false }] }], finishLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "finishLabel", required: false }] }], stepsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "stepsLabel", required: false }] }], stepChange: [{ type: i0.Output, args: ["stepChange"] }], finish: [{ type: i0.Output, args: ["finish"] }] } });

/*
 * bandeira-ui — design system em Angular
 * API pública da biblioteca.
 */
/* --------------------------------------------------------------- Ações --- */
/**
 * Conjunto completo da biblioteca, para importação única:
 *
 * ```ts
 * @Component({ imports: [BANDEIRA_UI] })
 * ```
 *
 * Conveniente em protótipos. Em produção, importe apenas o que a tela utiliza:
 * a eliminação de código não utilizado depende disso.
 */
const BANDEIRA_UI = [
    BdAccordionComponent,
    BdAlertComponent,
    BdAppShellComponent,
    BdAuthLayoutComponent,
    BdAvatarComponent,
    BdBadgeComponent,
    BdButtonComponent,
    BdCardComponent,
    BdCheckboxComponent,
    BdChipComponent,
    BdContainerComponent,
    BdDashboardTemplateComponent,
    BdEmptyStateComponent,
    BdFieldComponent,
    BdInputComponent,
    BdListTemplateComponent,
    BdMetricComponent,
    BdModalComponent,
    BdPageHeaderComponent,
    BdPaginationComponent,
    BdProgressComponent,
    BdSettingsTemplateComponent,
    BdSkeletonComponent,
    BdSpinnerComponent,
    BdStepsComponent,
    BdSwitchComponent,
    BdTabPanelComponent,
    BdTableComponent,
    BdTabsComponent,
    BdTooltipDirective,
    BdTourComponent,
    BdWizardTemplateComponent,
    BdCountUpDirective,
    BdRevealDirective,
];

/**
 * Generated bundle index. Do not edit.
 */

export { BANDEIRA_UI, BD_TOUR_DEFAULT_LABELS, BdAccordionComponent, BdAlertComponent, BdAppShellComponent, BdAuthLayoutComponent, BdAvatarComponent, BdBadgeComponent, BdButtonComponent, BdCardComponent, BdCheckboxComponent, BdChipComponent, BdContainerComponent, BdCountUpDirective, BdDashboardTemplateComponent, BdEmptyStateComponent, BdFieldComponent, BdInputComponent, BdListTemplateComponent, BdMetricComponent, BdModalComponent, BdOverlayStackService, BdPageHeaderComponent, BdPaginationComponent, BdProgressComponent, BdRevealDirective, BdScrollLockService, BdSettingsTemplateComponent, BdSkeletonComponent, BdSpinnerComponent, BdStepsComponent, BdSwitchComponent, BdTabPanelComponent, BdTableComponent, BdTabsComponent, BdTooltipDirective, BdTourComponent, BdTourService, BdWizardTemplateComponent };
//# sourceMappingURL=bandeira-ui.mjs.map
