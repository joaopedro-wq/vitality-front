import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

type BdButtonVariant = 'primary' | 'ghost' | 'subtle' | 'danger';
type BdButtonSize = 'sm' | 'md' | 'lg';
/**
 * Botão do design system.
 *
 * Usa seletor de atributo para aplicar em `<button>` ou `<a>` sem elemento
 * extra no DOM e sem perder a semântica nativa (foco, Enter, `href`).
 *
 * @example
 * ```html
 * <button bdButton>Salvar</button>
 * <button bdButton variant="ghost" size="sm">Cancelar</button>
 * <button bdButton [loading]="salvando()">Enviar</button>
 * <button bdButton iconOnly aria-label="Fechar"><i class="fas fa-times"></i></button>
 * <a bdButton variant="subtle" href="/docs">Documentação</a>
 * ```
 */
declare class BdButtonComponent {
    readonly variant: _angular_core.InputSignal<BdButtonVariant>;
    readonly size: _angular_core.InputSignal<BdButtonSize>;
    /** Ocupa toda a largura disponível. */
    readonly block: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Mostra o spinner e bloqueia a interação. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Botão quadrado só com ícone — exige `aria-label`. */
    readonly iconOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly host;
    protected readonly isDisabled: _angular_core.Signal<boolean>;
    protected readonly classes: _angular_core.Signal<string>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdButtonComponent, "button[bdButton], a[bdButton]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "block": { "alias": "block"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Envelope de campo de formulário: rótulo, controle, dica e mensagem de erro.
 *
 * Encontra o `[bdInput]` projetado e liga tudo sozinho — o `for` do rótulo
 * aponta para o `id` real do campo, o `aria-describedby` aponta para a dica ou
 * o erro, e o `aria-invalid` acompanha o estado. Quem consome não precisa
 * lembrar de nada disso.
 *
 * @example
 * ```html
 * <bd-field label="Seu e-mail" hint="Não compartilho com ninguém" required>
 *   <input bdInput type="email" formControlName="email" />
 * </bd-field>
 *
 * <bd-field label="Mensagem" [error]="erro()">
 *   <textarea bdInput rows="4"></textarea>
 * </bd-field>
 * ```
 */
declare class BdFieldComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    /** Quando presente, substitui a dica, pinta o campo e vira `role="alert"`. */
    readonly error: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly uid;
    protected readonly errorId: string;
    protected readonly hintId: string;
    /** O campo projetado — é dele que sai o `id` usado no `for` do rótulo. */
    private readonly control;
    protected readonly controlId: _angular_core.Signal<string>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdFieldComponent, "bd-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, {}, ["control"], ["*"], true, never>;
}

/**
 * Aplica o estilo do design system em `<input>`, `<textarea>` e `<select>`.
 *
 * É um componente de seletor por atributo com template vazio: o estilo fica
 * encapsulado (sem `::ng-deep`) e o elemento nativo continua sendo o elemento
 * real do formulário, então `formControlName`, `type` e validação nativa
 * funcionam sem intermediário.
 *
 * Dentro de um `<bd-field>`, recebe automaticamente o `id` usado pelo `for` do
 * rótulo e as ligações de `aria-describedby` / `aria-invalid`.
 *
 * @example
 * ```html
 * <bd-field label="Seu e-mail" [error]="erro()">
 *   <input bdInput type="email" formControlName="email" />
 * </bd-field>
 *
 * <input bdInput type="text" placeholder="Busca" />
 * ```
 */
declare class BdInputComponent {
    /** Informe para fixar o `id`; do contrário um é gerado. */
    readonly inputId: _angular_core.InputSignal<string>;
    private readonly gerado;
    /** Preenchidos pelo `<bd-field>` que envolve este campo. */
    private readonly fieldDescribedBy;
    private readonly fieldInvalid;
    readonly element: ElementRef<HTMLElement>;
    readonly id: _angular_core.Signal<string>;
    readonly describedBy: _angular_core.Signal<string>;
    readonly invalid: _angular_core.Signal<boolean>;
    /** @internal chamado pelo `<bd-field>` que envolve este campo. */
    _conectarAoField(describedBy: string, invalido: boolean): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdInputComponent, "input[bdInput], textarea[bdInput], select[bdInput]", never, { "inputId": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Caixa de seleção.
 *
 * Suporta o estado indeterminado — o "traço" que representa seleção parcial
 * numa lista de filhos. Ele é visual e ARIA, não um terceiro value: ao clicar,
 * o controle vira marcado.
 *
 * @example
 * ```html
 * <bd-checkbox [(checked)]="aceito">Aceito os termos</bd-checkbox>
 * <bd-checkbox formControlName="ativo" indeterminate>Todos</bd-checkbox>
 * ```
 */
declare class BdCheckboxComponent implements ControlValueAccessor {
    /** Two-way: `[(checked)]="aceito"`. */
    readonly checked: _angular_core.ModelSignal<boolean>;
    /** Seleção parcial. Ao clicar, o controle passa a marcado. */
    readonly indeterminate: _angular_core.ModelSignal<boolean>;
    /** Desabilita via template: `<bd-checkbox disabled>`. */
    readonly disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Escrito pelo Reactive Forms via setDisabledState. */
    private readonly disabledByForm;
    /** Vale isDisabled se veio do template OU do formulário. */
    protected readonly disabled: _angular_core.Signal<boolean>;
    private readonly uid;
    protected readonly id: string;
    protected readonly labelId: string;
    private onChangeFn;
    protected onTouchedFn: () => void;
    protected toggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdCheckboxComponent, "bd-checkbox", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; "indeterminate": "indeterminateChange"; }, never, ["*"], true, never>;
}

/**
 * Interruptor liga/desliga.
 *
 * Use quando o efeito é imediato ("ativar notificações"). Para algo que só vale
 * ao enviar o formulário, prefira `<bd-checkbox>`.
 *
 * Implementa `ControlValueAccessor`, então funciona com `formControlName` e
 * `[(ngModel)]` — e também de forma avulsa com `[(checked)]`.
 *
 * @example
 * ```html
 * <bd-switch [(checked)]="notificacoes">Notificações por e-mail</bd-switch>
 * <bd-switch formControlName="ativo">Ativo</bd-switch>
 * ```
 */
declare class BdSwitchComponent implements ControlValueAccessor {
    /** Two-way: `[(checked)]="ativo"`. */
    readonly checked: _angular_core.ModelSignal<boolean>;
    /** Desabilita via template: `<bd-switch disabled>`. */
    readonly disabledInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Escrito pelo Reactive Forms via setDisabledState. */
    private readonly disabledByForm;
    /** Vale isDisabled se veio do template OU do formulário. */
    protected readonly disabled: _angular_core.Signal<boolean>;
    private readonly uid;
    protected readonly id: string;
    protected readonly labelId: string;
    private onChangeFn;
    protected onTouchedFn: () => void;
    protected toggle(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdSwitchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdSwitchComponent, "bd-switch", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabledInput": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, ["*"], true, never>;
}

type BdAlertTone = 'info' | 'success' | 'warning' | 'danger';
/**
 * Mensagem persistente na página — diferente do toast, que some sozinho.
 *
 * Erros e avisos recebem `role="alert"` (o leitor de tela interrompe e anuncia);
 * info e sucesso recebem `role="status"` (anuncia sem interromper).
 *
 * @example
 * ```html
 * <bd-alert tone="warning" title="Plano expirando">
 *   Sua assinatura vence em 3 dias.
 * </bd-alert>
 *
 * <bd-alert tone="danger" dismissible (dismissed)="esconder()">
 *   Não foi possível salvar.
 * </bd-alert>
 * ```
 */
declare class BdAlertComponent {
    readonly tone: _angular_core.InputSignal<BdAlertTone>;
    readonly title: _angular_core.InputSignal<string>;
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeLabel: _angular_core.InputSignal<string>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    protected readonly icone: _angular_core.Signal<string>;
    protected readonly classes: _angular_core.Signal<string>;
    /** Erro e aviso interrompem o leitor de tela; os demais só anunciam. */
    protected readonly papel: _angular_core.Signal<"alert" | "status">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdAlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdAlertComponent, "bd-alert", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; }, { "dismissed": "dismissed"; }, never, ["*"], true, never>;
}

type BdProgressTone = 'primary' | 'accent' | 'success' | 'warning' | 'danger';
/**
 * Barra de progresso determinada.
 *
 * Expõe `role="progressbar"` com os valores ARIA corretos, então leitores de
 * tela anunciam a porcentagem. Para carregamento sem fim conhecido, use
 * `<bd-spinner>` — uma barra que não avança confunde mais do que informa.
 *
 * @example
 * ```html
 * <bd-progress [value]="65" />
 * <bd-progress [value]="3" [max]="5" tone="success" showValue label="Etapas" />
 * ```
 */
declare class BdProgressComponent {
    readonly value: _angular_core.InputSignal<number>;
    readonly max: _angular_core.InputSignal<number>;
    readonly tone: _angular_core.InputSignal<BdProgressTone>;
    readonly label: _angular_core.InputSignal<string>;
    /** Mostra a porcentagem ao lado do rótulo. */
    readonly showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly classes: _angular_core.Signal<string>;
    protected readonly percentual: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdProgressComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdProgressComponent, "bd-progress", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdSkeletonVariant = 'text' | 'title' | 'circle' | 'rect';
/**
 * Placeholder do conteúdo enquanto ele carrega.
 *
 * Prefira skeleton a spinner quando você já sabe o formato do que vai chegar:
 * a página não "salta" na troca e a espera parece mais curta.
 *
 * É invisível para leitores de tela (`aria-hidden`) — anuncie o carregamento
 * no container, com `aria-busy`.
 *
 * @example
 * ```html
 * <bd-skeleton variant="title" />
 * <bd-skeleton variant="text" width="80%" />
 * <bd-skeleton variant="circle" width="48px" height="48px" />
 * ```
 */
declare class BdSkeletonComponent {
    readonly variant: _angular_core.InputSignal<BdSkeletonVariant>;
    /** Sobrescreve a largura padrão da variante. */
    readonly width: _angular_core.InputSignal<string>;
    /** Sobrescreve a altura padrão da variante. */
    readonly height: _angular_core.InputSignal<string>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdSkeletonComponent, "bd-skeleton", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdSpinnerSize = 'sm' | 'md' | 'lg';
/**
 * Indicador de carregamento indeterminado.
 *
 * Traz o rótulo para leitores de tela por padrão — um spinner mudo deixa quem
 * não enxerga sem saber que algo está acontecendo.
 *
 * @example
 * ```html
 * <bd-spinner />
 * <bd-spinner size="lg" label="Carregando projetos" />
 * ```
 */
declare class BdSpinnerComponent {
    readonly size: _angular_core.InputSignal<BdSpinnerSize>;
    /** Texto anunciado por leitores de tela. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdSpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdSpinnerComponent, "bd-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Diálogo modal acessível.
 *
 * Confina o foco (`cdkTrapFocus`), encerra com `Esc` ou clique no fundo, trava
 * a rolagem da página e devolve o foco ao elemento que o abriu. Abaixo de
 * 600px assume o formato de bottom sheet, ao alcance do polegar.
 *
 * Diálogos empilhados são coordenados: a trava de rolagem é contada por
 * referência e `Esc` encerra apenas o diálogo do topo da pilha.
 *
 * @example
 * ```html
 * <bd-modal [(open)]="confirmacaoAberta" title="Excluir projeto">
 *   <p>Esta ação não pode ser desfeita.</p>
 * </bd-modal>
 * ```
 */
declare class BdModalComponent {
    /** Two-way: `[(open)]="mostrar"`. */
    readonly open: _angular_core.ModelSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    /** Rótulo acessível quando o diálogo não tem título visível. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Quando `false`, esconde o X e ignora `Esc` e clique no fundo. */
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeLabel: _angular_core.InputSignal<string>;
    protected readonly titleId: string;
    private readonly document;
    private readonly scrollLock;
    private readonly overlayStack;
    private focusOrigin;
    private locked;
    constructor();
    protected onEscape(): void;
    protected close(): void;
    private onOpen;
    private onClose;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdModalComponent, "bd-modal", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; }, { "open": "openChange"; }, never, ["*"], true, never>;
}

/**
 * Estrutura de aplicação: cabeçalho fixo, barra lateral e área de conteúdo.
 *
 * No desktop a lateral fica fixa; abaixo de 900px ela vira gaveta sobreposta,
 * com fundo escuro clicável para fechar. O `<main>` é marcado como
 * `id="conteudo"`, alvo do link "pular para o conteúdo".
 *
 * @example
 * ```html
 * <bd-app-shell [(sidebarOpen)]="menuAberto">
 *   <a bdAppShellBrand href="/">Minha Empresa</a>
 *   <nav bdAppShellNav>…</nav>
 *   <button bdAppShellActions bdButton size="sm">Novo</button>
 *
 *   <router-outlet />
 * </bd-app-shell>
 * ```
 */
declare class BdAppShellComponent {
    /** Two-way: `[(sidebarOpen)]="menuAberto"`. Só afeta o mobile. */
    readonly sidebarOpen: _angular_core.ModelSignal<boolean>;
    /** Esconde o botão de menu — útil quando não há navegação lateral. */
    readonly hideToggle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly skipLabel: _angular_core.InputSignal<string>;
    readonly openMenuLabel: _angular_core.InputSignal<string>;
    readonly closeMenuLabel: _angular_core.InputSignal<string>;
    readonly navLabel: _angular_core.InputSignal<string>;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdAppShellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdAppShellComponent, "bd-app-shell", never, { "sidebarOpen": { "alias": "sidebarOpen"; "required": false; "isSignal": true; }; "hideToggle": { "alias": "hideToggle"; "required": false; "isSignal": true; }; "skipLabel": { "alias": "skipLabel"; "required": false; "isSignal": true; }; "openMenuLabel": { "alias": "openMenuLabel"; "required": false; "isSignal": true; }; "closeMenuLabel": { "alias": "closeMenuLabel"; "required": false; "isSignal": true; }; "navLabel": { "alias": "navLabel"; "required": false; "isSignal": true; }; }, { "sidebarOpen": "sidebarOpenChange"; }, never, ["[bdAppShellBrand]", "[bdAppShellActions]", "[bdAppShellNav]", "*"], true, never>;
}

type BdAuthAsideSide = 'left' | 'right';
/**
 * Tela dividida para login, cadastro e recuperação de senha.
 *
 * O painel de marca some abaixo de 900px — no celular o formulário ocupa a
 * tela inteira, que é o que importa ali. Por ser decorativo, ele fica depois
 * do formulário na ordem do DOM: quem navega por teclado chega ao campo antes.
 *
 * @example
 * ```html
 * <bd-auth-layout title="Bem-vindo de volta" subtitle="Entre para continuar.">
 *   <div bdAuthAside>
 *     <h2>Sua marca aqui</h2>
 *   </div>
 *
 *   <form>…</form>
 * </bd-auth-layout>
 * ```
 */
declare class BdAuthLayoutComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    /** Lado do painel decorativo no desktop. */
    readonly asideSide: _angular_core.InputSignal<BdAuthAsideSide>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdAuthLayoutComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdAuthLayoutComponent, "bd-auth-layout", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "asideSide": { "alias": "asideSide"; "required": false; "isSignal": true; }; }, {}, never, ["[bdAuthBrand]", "*", "[bdAuthFooter]", "[bdAuthAside]"], true, never>;
}

type BdContainerSize = 'sm' | 'md' | 'lg' | 'full';
/**
 * Centraliza o conteúdo com largura máxima e respiro lateral.
 *
 * O respiro é responsivo, então o conteúdo nunca encosta na borda no celular.
 *
 * @example
 * ```html
 * <bd-container size="md">…</bd-container>
 * ```
 */
declare class BdContainerComponent {
    readonly size: _angular_core.InputSignal<BdContainerSize>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdContainerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdContainerComponent, "bd-container", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Cabeçalho de página: título, descrição e ações à direita.
 *
 * O título sai como `<h1>` — em quase toda tela ele é o título principal, e
 * pular esse nível quebra a navegação por cabeçalhos no leitor de tela.
 *
 * @example
 * ```html
 * <bd-page-header title="Projetos" description="Tudo que está em andamento.">
 *   <nav bdPageHeaderBreadcrumb>Início / Projetos</nav>
 *   <button bdButton bdPageHeaderActions>Novo projeto</button>
 * </bd-page-header>
 * ```
 */
declare class BdPageHeaderComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdPageHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdPageHeaderComponent, "bd-page-header", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["[bdPageHeaderBreadcrumb]", "[bdPageHeaderActions]", "*"], true, never>;
}

interface BdAccordionItem {
    id: string;
    title: string;
    content: string;
    disabled?: boolean;
}
/**
 * Lista de seções expansíveis.
 *
 * O cabeçalho de cada seção é um `<button>` dentro de um heading, com
 * `aria-expanded` e `aria-controls` ligados ao painel — a estrutura que
 * leitores de tela usam para navegar por seções.
 *
 * @example
 * ```html
 * <bd-accordion [items]="perguntas" [(opened)]="abertas" />
 * <bd-accordion [items]="perguntas" multiple />
 * ```
 */
declare class BdAccordionComponent {
    readonly items: _angular_core.InputSignal<BdAccordionItem[]>;
    /** Ids das seções abertas. Two-way: `[(opened)]="abertas"`. */
    readonly opened: _angular_core.ModelSignal<string[]>;
    /** Permite mais de uma seção aberta ao mesmo tempo. */
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Emitido com o id e o novo estado da seção. */
    readonly toggled: _angular_core.OutputEmitterRef<{
        id: string;
        open: boolean;
    }>;
    protected estaAberto(id: string): boolean;
    protected toggle(item: BdAccordionItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdAccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdAccordionComponent, "bd-accordion", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "opened": { "alias": "opened"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "opened": "openedChange"; "toggled": "toggled"; }, never, never, true, never>;
}

interface BdStep {
    label: string;
    /** Texto auxiliar exibido abaixo do rótulo. */
    hint?: string;
    /** Glifo exibido no marcador em vez do número. */
    icon?: string;
    /** Marca a etapa como dispensável na leitura. */
    optional?: boolean;
}
/**
 * Estilos disponíveis do indicador.
 *
 * - `panel` — cartões lado a lado, com rótulo e apoio. Denso em informação.
 * - `line` — círculos ligados por linha, o formato canônico de assistente.
 * - `numbered` — lista numerada com conector; legível na vertical.
 * - `dots` — apenas marcadores. Para fluxos curtos e áreas estreitas.
 * - `progress` — barra de progresso com contador. O mais compacto.
 */
type BdStepsVariant = 'panel' | 'line' | 'numbered' | 'dots' | 'progress';
type BdStepsOrientation = 'horizontal' | 'vertical';
/**
 * Indicador de progresso em etapas.
 *
 * A marcação é sempre a mesma — uma lista ordenada com `aria-current="step"` na
 * etapa corrente —, o que muda entre as variantes é apenas a apresentação. A
 * posição no processo é, portanto, anunciada por leitores de tela em todas
 * elas, e não apenas sinalizada por cor.
 *
 * Etapas já concluídas voltam a ser navegáveis quando `clickable` está ativo;
 * as futuras permanecem bloqueadas, porque o indicador não tem como saber se as
 * intermediárias foram preenchidas.
 *
 * @example
 * ```html
 * <bd-steps [steps]="etapas" [(active)]="etapa" variant="line" clickable />
 * <bd-steps [steps]="etapas" [active]="etapa()" variant="numbered" orientation="vertical" />
 * <bd-steps [steps]="etapas" [active]="etapa()" variant="progress" />
 * ```
 */
declare class BdStepsComponent {
    readonly steps: _angular_core.InputSignal<readonly BdStep[]>;
    /** Two-way com o índice da etapa corrente. */
    readonly active: _angular_core.ModelSignal<number>;
    readonly variant: _angular_core.InputSignal<BdStepsVariant>;
    readonly orientation: _angular_core.InputSignal<BdStepsOrientation>;
    /** Permite retornar a etapas já concluídas pelo próprio indicador. */
    readonly clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    /** Recebe (posição atual, total) — ex.: "Etapa 2 de 5". */
    readonly counter: _angular_core.InputSignal<(current: number, total: number) => string>;
    readonly stepChange: _angular_core.OutputEmitterRef<number>;
    protected readonly classes: _angular_core.Signal<string>;
    protected readonly hasConnector: _angular_core.Signal<boolean>;
    protected readonly progress: _angular_core.Signal<number>;
    protected readonly currentLabel: _angular_core.Signal<string>;
    protected readonly counterText: _angular_core.Signal<string>;
    protected isReachable(index: number): boolean;
    protected markerFor(step: BdStep, index: number): string;
    protected select(index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdStepsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdStepsComponent, "bd-steps", never, { "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "counter": { "alias": "counter"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; "stepChange": "stepChange"; }, never, never, true, never>;
}

/**
 * Painel de conteúdo ligado a uma aba do `<bd-tabs>`.
 *
 * Recebe `role="tabpanel"` e o `aria-labelledby` apontando para a aba
 * correspondente, fechando o par que os leitores de tela esperam.
 *
 * @example
 * ```html
 * <bd-tabs [tabs]="abas" [(active)]="abaAtiva" />
 *
 * <bd-tab-panel tabId="design" [active]="abaAtiva()">
 *   Conteúdo da aba de design
 * </bd-tab-panel>
 * ```
 */
declare class BdTabPanelComponent {
    /** Deve casar com o `id` da aba correspondente em `<bd-tabs>`. */
    readonly tabId: _angular_core.InputSignal<string>;
    /** O `id` da aba ativa no momento. */
    readonly active: _angular_core.InputSignal<string>;
    protected readonly isVisible: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTabPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdTabPanelComponent, "bd-tab-panel", never, { "tabId": { "alias": "tabId"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface BdTab {
    id: string;
    label: string;
    /** Classe de ícone opcional (ex.: 'fas fa-code'). */
    icon?: string;
    disabled?: boolean;
}
/**
 * Navegação por abas seguindo o padrão WAI-ARIA de `tablist`.
 *
 * Setas ←/→ movem entre as abas, `Home`/`End` vão para as pontas e o foco
 * acompanha a seleção. Abas desabilitadas são puladas na navegação.
 *
 * Use com `<bd-tab-panel>` para que o painel também receba os papéis corretos.
 *
 * @example
 * ```html
 * <bd-tabs [tabs]="abas" [(active)]="abaAtiva" label="Seções" />
 *
 * <bd-tab-panel tabId="design" [active]="abaAtiva()">
 *   Conteúdo da aba
 * </bd-tab-panel>
 * ```
 */
declare class BdTabsComponent {
    readonly tabs: _angular_core.InputSignal<BdTab[]>;
    /** Two-way: `[(active)]="minhaAba"`. */
    readonly active: _angular_core.ModelSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    private readonly host;
    select(tab: BdTab): void;
    onKeydown(event: KeyboardEvent, index: number): void;
    /**
     * Caminha na direção informada ignorando abas desabilitadas, com retorno
     * circular. Devolve `null` quando não há nenhuma aba habilitada.
     */
    private nextEnabled;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdTabsComponent, "bd-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; }, never, never, true, never>;
}

interface BdPageEvent {
    /** Índice da página, começando em 0. */
    page: number;
    pageSize: number;
}
/**
 * Paginação de listagens e tabelas.
 *
 * A sequência de páginas é condensada com reticências quando o total é grande:
 * exibir cem botões não ajuda ninguém a navegar. As extremidades e a vizinhança
 * da página corrente permanecem sempre acessíveis, que é o que se usa na
 * prática.
 *
 * O elemento é um `<nav>` com rótulo, e a página corrente é marcada com
 * `aria-current="page"` — a posição é anunciada, não apenas destacada.
 *
 * @example
 * ```html
 * <bd-pagination
 *   [total]="240"
 *   [(page)]="pagina"
 *   [(pageSize)]="tamanho"
 *   (paginate)="carregar($event)"
 * />
 * ```
 */
declare class BdPaginationComponent {
    /** Total de registros. */
    readonly total: _angular_core.InputSignal<number>;
    /** Two-way com o índice da página, começando em 0. */
    readonly page: _angular_core.ModelSignal<number>;
    readonly pageSize: _angular_core.ModelSignal<number>;
    readonly pageSizeOptions: _angular_core.InputSignal<readonly number[]>;
    /** Quantidade de páginas exibidas de cada lado da corrente. */
    readonly siblings: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly pageLabel: _angular_core.InputSignal<string>;
    readonly previousLabel: _angular_core.InputSignal<string>;
    readonly nextLabel: _angular_core.InputSignal<string>;
    readonly pageSizeLabel: _angular_core.InputSignal<string>;
    /** Recebe (primeiro, último, total) — ex.: "21–40 de 240". */
    readonly summaryText: _angular_core.InputSignal<(from: number, to: number, total: number) => string>;
    /**
     * Emitido a cada navegação, com página e tamanho já resolvidos.
     *
     * Deliberadamente **não** se chama `pageChange`: esse nome pertence ao output
     * implícito do `model page`, e reutilizá-lo faria a sintaxe `[(page)]`
     * escrever este objeto na variável do consumidor.
     */
    readonly paginate: _angular_core.OutputEmitterRef<BdPageEvent>;
    protected readonly gap: "…";
    protected readonly pageCount: _angular_core.Signal<number>;
    protected readonly isFirst: _angular_core.Signal<boolean>;
    protected readonly isLast: _angular_core.Signal<boolean>;
    protected readonly summary: _angular_core.Signal<string>;
    /**
     * Sequência condensada de páginas: primeira, vizinhança da corrente, última,
     * com reticências onde há salto.
     */
    protected readonly sequence: _angular_core.Signal<(number | "…")[]>;
    protected goTo(page: number): void;
    protected onPageSizeChange(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdPaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdPaginationComponent, "bd-pagination", never, { "total": { "alias": "total"; "required": true; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "pageSizeOptions": { "alias": "pageSizeOptions"; "required": false; "isSignal": true; }; "siblings": { "alias": "siblings"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "pageLabel": { "alias": "pageLabel"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "pageSizeLabel": { "alias": "pageSizeLabel"; "required": false; "isSignal": true; }; "summaryText": { "alias": "summaryText"; "required": false; "isSignal": true; }; }, { "page": "pageChange"; "pageSize": "pageSizeChange"; "paginate": "paginate"; }, never, never, true, never>;
}

type BdTableAlign = 'start' | 'center' | 'end';
type BdSortDirection = 'asc' | 'desc';
type BdTableFrozen = 'start' | 'end';
interface BdTableColumn<T = Record<string, unknown>> {
    /** Chave da coluna. Serve de identidade e, por padrão, de acessor. */
    key: string;
    header: string;
    /** Habilita a ordenação por esta coluna. */
    sortable?: boolean;
    align?: BdTableAlign;
    /** Largura da trilha na grade — ex.: `'160px'`, `'2fr'`, `'minmax(120px, 1fr)'`. */
    width?: string;
    /**
     * Extrai o valor exibido. Sem acessor, a célula usa `row[key]`.
     * Use também para formatar — a formatação não deve viver no template.
     */
    value?: (row: T) => string | number | null | undefined;
    /**
     * Valor usado na ordenação no cliente. Sem ele, `value` é usado; sem ambos,
     * `row[key]`. Útil para ordenar por data enquanto se exibe texto.
     */
    sortValue?: (row: T) => string | number | Date | null | undefined;
    /** Oculta a coluna abaixo de 720px. Reserve para o que é acessório. */
    secondary?: boolean;
    /**
     * Fixa a coluna na borda durante a rolagem horizontal.
     *
     * Exige `width` em pixels: o deslocamento de cada coluna fixa é a soma das
     * larguras das anteriores, e uma trilha flexível não tem largura conhecida
     * antes do layout. Fixe apenas o que identifica a linha — congelar metade da
     * tabela devolve ao usuário o problema que a fixação deveria resolver.
     */
    frozen?: BdTableFrozen;
    /**
     * Conteúdo desta coluna na linha de totais. Receber as linhas permite somar,
     * contar ou calcular médias sem duplicar o conjunto de dados fora da tabela.
     * A linha de totais só é renderizada se ao menos uma coluna a definir.
     */
    footer?: (rows: readonly T[]) => string | number | null | undefined;
}
interface BdSortState {
    key: string;
    direction: BdSortDirection;
}
/**
 * Tabela de dados.
 *
 * ## Semântica
 *
 * A estrutura usa papéis ARIA (`table`, `rowgroup`, `row`, `columnheader`,
 * `cell`) sobre uma grade CSS, e não os elementos `<table>` nativos. A escolha
 * é deliberada: uma tabela nativa não pode ter suas linhas virtualizadas sem
 * quebrar o modelo de layout, e a virtualização é o que torna viável exibir
 * dezenas de milhares de linhas. Os papéis entregam ao leitor de tela a mesma
 * informação que a tabela nativa entregaria.
 *
 * ## Custo de renderização
 *
 * - Detecção de mudanças `OnPush` e estado em signals: uma alteração de página
 *   ou de ordenação não propaga verificação para o resto da aplicação.
 * - `track` obrigatório via {@link trackBy} — sem identidade estável, cada
 *   atualização destrói e recria todas as linhas do DOM.
 * - Ordenação no cliente derivada em `computed`: reordena apenas quando as
 *   linhas ou o critério mudam, nunca a cada ciclo de detecção.
 * - Com `virtual`, apenas as linhas visíveis existem no DOM. O custo de
 *   renderização passa a ser função da altura da janela, não do tamanho do
 *   conjunto de dados.
 *
 * ## Volume de dados
 *
 * | Linhas          | Configuração recomendada                          |
 * | --------------- | ------------------------------------------------- |
 * | até ~200        | padrão, ordenação no cliente                      |
 * | ~200 a ~2.000   | `virtual` com `viewportHeight`                    |
 * | acima disso     | `sortMode="server"` com paginação ou `(loadMore)`  |
 *
 * ## Combinações incompatíveis
 *
 * `virtual` pressupõe altura de linha uniforme, e por isso não se combina com
 * `expandable` nem com `wrap` — ambos tornam a altura dependente do conteúdo.
 * Para conjuntos grandes que também precisam de detalhe, pagine em vez de
 * virtualizar.
 *
 * @example
 * ```html
 * <bd-table
 *   [columns]="colunas"
 *   [rows]="projetos()"
 *   [trackBy]="rastrear"
 *   [(sort)]="ordenacao"
 *   [loading]="carregando()"
 *   (rowClick)="abrir($event)"
 * />
 * ```
 */
declare class BdTableComponent<T extends object = Record<string, unknown>> {
    readonly columns: _angular_core.InputSignal<readonly BdTableColumn<T>[]>;
    readonly rows: _angular_core.InputSignal<readonly T[]>;
    /**
     * Identidade estável das linhas. O padrão usa o índice, o que é correto
     * apenas para listas imutáveis: com dados que mudam de ordem, forneça uma
     * chave real para evitar a recriação de todo o corpo da tabela.
     */
    readonly trackBy: _angular_core.InputSignal<(index: number, row: T) => unknown>;
    /** Two-way com o critério de ordenação. `null` significa ordem original. */
    readonly sort: _angular_core.ModelSignal<BdSortState | null>;
    /**
     * `client` reordena as linhas recebidas; `server` apenas emite
     * `(sortChange)` e mantém a ordem em que os dados chegaram.
     */
    readonly sortMode: _angular_core.InputSignal<"client" | "server">;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly placeholderCount: _angular_core.InputSignal<number>;
    /** Habilita a coluna de seleção. */
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Two-way com o conjunto de linhas selecionadas. */
    readonly selection: _angular_core.ModelSignal<readonly T[]>;
    /** Renderiza apenas as linhas visíveis. Exige altura de linha uniforme. */
    readonly virtual: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rowHeight: _angular_core.InputSignal<number>;
    readonly viewportHeight: _angular_core.InputSignal<number>;
    readonly density: _angular_core.InputSignal<"default" | "compact">;
    /** Alterna o fundo das linhas, ajudando a percorrer tabelas largas. */
    readonly striped: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Permite que as células quebrem em várias linhas. A altura passa a depender
     * do conteúdo, o que é incompatível com `virtual` — as duas são exclusivas.
     */
    readonly wrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Habilita a linha de detalhe, revelada pelo botão no início da linha.
     *
     * O detalhe é renderizado como uma linha irmã que ocupa toda a largura, e não
     * ampliando a linha original: alterar a altura de uma linha desalinharia as
     * colunas de todas as demais. Como a altura deixa de ser uniforme, a expansão
     * não é combinável com `virtual`.
     */
    readonly expandable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Two-way com as linhas expandidas. */
    readonly expanded: _angular_core.ModelSignal<readonly T[]>;
    /** Total de registros no servidor, quando maior que o conjunto exibido. */
    readonly totalCount: _angular_core.InputSignal<number | null>;
    readonly label: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly loadingLabel: _angular_core.InputSignal<string>;
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    readonly selectRowLabel: _angular_core.InputSignal<string>;
    readonly expandColumnLabel: _angular_core.InputSignal<string>;
    readonly expandLabel: _angular_core.InputSignal<string>;
    readonly collapseLabel: _angular_core.InputSignal<string>;
    /** Conteúdo do estado vazio, quando um texto não basta. */
    readonly emptyTemplate: _angular_core.Signal<TemplateRef<unknown> | undefined>;
    /** Conteúdo da linha de detalhe. Recebe a linha como contexto implícito. */
    readonly detailTemplate: _angular_core.Signal<TemplateRef<{
        $implicit: T;
    }> | undefined>;
    readonly rowClick: _angular_core.OutputEmitterRef<T>;
    readonly sortChange: _angular_core.OutputEmitterRef<BdSortState | null>;
    /** Emitido ao abrir ou fechar uma linha, com o conjunto expandido resultante. */
    readonly expandedChangeRows: _angular_core.OutputEmitterRef<readonly T[]>;
    /**
     * Emitido no modo virtual quando a rolagem se aproxima do fim da lista.
     * Use para carregar a página seguinte sob demanda.
     */
    readonly loadMore: _angular_core.OutputEmitterRef<void>;
    /** Linhas efetivamente renderizadas, já ordenadas quando `sortMode` é `client`. */
    protected readonly visibleRows: _angular_core.Signal<readonly T[]>;
    protected readonly placeholderRows: _angular_core.Signal<number[]>;
    protected readonly gridTemplate: _angular_core.Signal<string>;
    protected readonly hasFrozenStart: _angular_core.Signal<boolean>;
    protected readonly expandOffset: _angular_core.Signal<number>;
    protected readonly selectOffset: _angular_core.Signal<0 | 44>;
    /** Largura ocupada pelas colunas de controle, que precedem as demais. */
    private readonly controlsWidth;
    /**
     * Deslocamento acumulado de cada coluna fixa, por chave.
     *
     * Colunas fixas ao início acumulam da esquerda; ao fim, da direita. O cálculo
     * exige largura em pixels — uma trilha flexível não tem largura conhecida
     * antes do layout, e um deslocamento errado empilharia as colunas umas sobre
     * as outras.
     */
    private readonly frozenOffsets;
    /** Última coluna fixa de cada lado: é nela que a borda de separação vai. */
    private readonly frozenEdges;
    protected readonly allSelected: _angular_core.Signal<boolean>;
    protected readonly someSelected: _angular_core.Signal<boolean>;
    protected readonly hasFooter: _angular_core.Signal<boolean>;
    protected frozenStartOffset(column: BdTableColumn<T>): number | null;
    protected frozenEndOffset(column: BdTableColumn<T>): number | null;
    protected isFrozenEdge(column: BdTableColumn<T>): boolean;
    protected footerValue(column: BdTableColumn<T>): string;
    protected isExpanded(row: T): boolean;
    protected toggleExpanded(row: T): void;
    protected display(column: BdTableColumn<T>, row: T): string;
    protected ariaSortFor(column: BdTableColumn<T>): string | null;
    protected sortGlyphFor(column: BdTableColumn<T>): string;
    /** Alterna entre ascendente, descendente e sem ordenação. */
    protected toggleSort(column: BdTableColumn<T>): void;
    protected isSelected(row: T): boolean;
    protected toggleRow(row: T): void;
    protected toggleAll(): void;
    protected onRowClick(row: T): void;
    protected onScrolledIndexChange(index: number): void;
    private sortKey;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTableComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdTableComponent<any>, "bd-table", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "sort": { "alias": "sort"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "placeholderCount": { "alias": "placeholderCount"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "virtual": { "alias": "virtual"; "required": false; "isSignal": true; }; "rowHeight": { "alias": "rowHeight"; "required": false; "isSignal": true; }; "viewportHeight": { "alias": "viewportHeight"; "required": false; "isSignal": true; }; "density": { "alias": "density"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "wrap": { "alias": "wrap"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "totalCount": { "alias": "totalCount"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "loadingLabel": { "alias": "loadingLabel"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; "selectRowLabel": { "alias": "selectRowLabel"; "required": false; "isSignal": true; }; "expandColumnLabel": { "alias": "expandColumnLabel"; "required": false; "isSignal": true; }; "expandLabel": { "alias": "expandLabel"; "required": false; "isSignal": true; }; "collapseLabel": { "alias": "collapseLabel"; "required": false; "isSignal": true; }; }, { "sort": "sortChange"; "selection": "selectionChange"; "expanded": "expandedChange"; "rowClick": "rowClick"; "sortChange": "sortChange"; "expandedChangeRows": "expandedChangeRows"; "loadMore": "loadMore"; }, ["emptyTemplate", "detailTemplate"], never, true, never>;
}

type BdCardPadding = 'none' | 'sm' | 'md' | 'lg';
/**
 * Container base do design system.
 *
 * @example
 * ```html
 * <bd-card>Conteúdo</bd-card>
 * <bd-card interactive padding="lg">Sobe no hover</bd-card>
 * <bd-card dashed>Placeholder / empty state</bd-card>
 * ```
 */
declare class BdCardComponent {
    readonly padding: _angular_core.InputSignal<BdCardPadding>;
    /** Aplica elevação e deslocamento no hover. */
    readonly interactive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Borda tracejada — bom para empty states e placeholders. */
    readonly dashed: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdCardComponent, "bd-card", never, { "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; "dashed": { "alias": "dashed"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type BdChipTone = 'primary' | 'accent' | 'neutral' | 'success' | 'warning' | 'danger';
/**
 * Etiqueta compacta para tecnologias, níveis, filtros e status.
 *
 * @example
 * ```html
 * <bd-chip>Angular</bd-chip>
 * <bd-chip tone="accent">avançado</bd-chip>
 * <bd-chip tone="neutral" outlined>rascunho</bd-chip>
 * <bd-chip removable (removed)="tirarFiltro()">TypeScript</bd-chip>
 * ```
 */
declare class BdChipComponent {
    readonly tone: _angular_core.InputSignal<BdChipTone>;
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Mostra o botão de remover. */
    readonly removable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Rótulo acessível do botão de remover. */
    readonly removeLabel: _angular_core.InputSignal<string>;
    /** Emitido ao clicar no botão de remover. */
    readonly removed: _angular_core.OutputEmitterRef<void>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdChipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdChipComponent, "bd-chip", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "removeLabel": { "alias": "removeLabel"; "required": false; "isSignal": true; }; }, { "removed": "removed"; }, never, ["*"], true, never>;
}

type BdAvatarSize = 'sm' | 'md' | 'lg' | 'xl';
/**
 * Foto de perfil com fallback para iniciais.
 *
 * Se a imagem falhar, as iniciais entram no lugar — sem ícone quebrado. A cor
 * de fundo é derivada do nome, então a mesma pessoa tem sempre a mesma cor.
 *
 * @example
 * ```html
 * <bd-avatar name="João Pedro Bandeira" src="/user.jpg" />
 * <bd-avatar name="Maria Silva" size="lg" />
 * ```
 */
declare class BdAvatarComponent {
    readonly name: _angular_core.InputSignal<string>;
    readonly src: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<BdAvatarSize>;
    protected readonly falhou: _angular_core.WritableSignal<boolean>;
    protected readonly classes: _angular_core.Signal<string>;
    /** Primeira letra do primeiro e do último nome. */
    protected readonly iniciais: _angular_core.Signal<string>;
    /** Matiz derivado do nome: mesma pessoa, mesma cor, sempre. */
    protected readonly cor: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdAvatarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdAvatarComponent, "bd-avatar", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "src": { "alias": "src"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdBadgeTone = 'primary' | 'accent' | 'neutral' | 'success' | 'warning' | 'danger';
/**
 * Contador ou marcador de status.
 *
 * Diferente do `<bd-chip>`, que rotula conteúdo: o badge quantifica ou sinaliza,
 * normalmente grudado noutro elemento.
 *
 * @example
 * ```html
 * <bd-badge>3</bd-badge>
 * <bd-badge tone="danger" [max]="99">128</bd-badge>
 * <bd-badge tone="success" dot>online</bd-badge>
 * ```
 */
declare class BdBadgeComponent {
    readonly tone: _angular_core.InputSignal<BdBadgeTone>;
    /** Mostra um ponto antes do texto — bom para status. */
    readonly dot: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Valor numérico. Acima de `max`, exibe "max+". */
    readonly value: _angular_core.InputSignal<number | null>;
    readonly max: _angular_core.InputSignal<number>;
    protected readonly limitado: _angular_core.Signal<string>;
    protected readonly classes: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdBadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdBadgeComponent, "bd-badge", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "dot": { "alias": "dot"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Estado vazio: explica a ausência e oferece o próximo passo.
 *
 * Um empty state sem ação é um beco sem saída — projete-o como convite, não
 * como aviso.
 *
 * @example
 * ```html
 * <bd-empty-state
 *   icon="📭"
 *   title="Nenhum projeto ainda"
 *   description="Crie o primeiro para começar a acompanhar suas entregas."
 * >
 *   <button bdButton>Criar projeto</button>
 * </bd-empty-state>
 * ```
 */
declare class BdEmptyStateComponent {
    readonly icon: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdEmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdEmptyStateComponent, "bd-empty-state", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type BdMetricTrend = 'up' | 'down' | 'flat';
type BdMetricAlign = 'center' | 'start';
/**
 * Indicador numérico com contagem animada na entrada em tela e variação
 * opcional em relação ao período anterior.
 *
 * A direção da variação é comunicada por seta, cor e texto anunciado — nunca
 * apenas por cor, que não é distinguível por parte dos usuários.
 *
 * @example
 * ```html
 * <bd-metric [value]="3" suffix="+" label="anos de experiência" />
 * <bd-metric [value]="98" suffix="%" label="cobertura" gradient />
 * <bd-metric [value]="128" prefix="R$ " suffix="k" label="Receita"
 *            align="start" trend="up" delta="12,5%" />
 * ```
 */
declare class BdMetricComponent {
    readonly value: _angular_core.InputSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    /** Preenche o número com o gradiente da marca. */
    readonly gradient: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Alinhamento do bloco. Use `start` em painéis. */
    readonly align: _angular_core.InputSignal<BdMetricAlign>;
    /** Variação em relação ao período anterior — ex.: `'12,5%'`. */
    readonly delta: _angular_core.InputSignal<string>;
    /** Direção da variação. Define cor, seta e texto anunciado. */
    readonly trend: _angular_core.InputSignal<BdMetricTrend>;
    /** Rótulos anunciados por leitores de tela para cada direção. */
    readonly trendLabels: _angular_core.InputSignal<Record<BdMetricTrend, string>>;
    protected readonly trendGlyph: _angular_core.Signal<string>;
    protected readonly trendLabel: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdMetricComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdMetricComponent, "bd-metric", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "gradient": { "alias": "gradient"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "delta": { "alias": "delta"; "required": false; "isSignal": true; }; "trend": { "alias": "trend"; "required": false; "isSignal": true; }; "trendLabels": { "alias": "trendLabels"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdTooltipPlacement = 'top' | 'bottom' | 'left' | 'right';
/**
 * Dica contextual exibida no ponteiro e no foco por teclado.
 *
 * A exibição no foco não é opcional: uma dica que responde apenas ao ponteiro
 * é inacessível a quem navega por teclado. O elemento hospedeiro recebe
 * `aria-describedby`, de modo que o leitor de tela anuncia a dica junto com o
 * controle que ela descreve.
 *
 * O balão é renderizado no `<body>` para escapar de `overflow: hidden` e de
 * contextos de empilhamento, e acompanha o alvo durante rolagem e
 * redimensionamento.
 *
 * Dicas não devem carregar informação essencial: em dispositivos de toque não
 * existe estado de ponteiro sobre o elemento.
 *
 * @example
 * ```html
 * <button bdButton iconOnly bdTooltip="Excluir projeto" aria-label="Excluir">🗑</button>
 * <span bdTooltip="Atualizado há 2 minutos" placement="right">agora</span>
 * ```
 */
declare class BdTooltipDirective {
    readonly bdTooltip: _angular_core.InputSignal<string>;
    readonly placement: _angular_core.InputSignal<BdTooltipPlacement>;
    /** Atraso de exibição em milissegundos — evita cintilação ao cruzar o alvo. */
    readonly showDelay: _angular_core.InputSignal<number>;
    private readonly host;
    private readonly document;
    private bubble?;
    private timer?;
    private frame?;
    private readonly id;
    /** Reposiciona o balão junto com o alvo, no ritmo do compositor. */
    private readonly onViewportChange;
    constructor();
    protected schedule(): void;
    protected hide(): void;
    private show;
    private position;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BdTooltipDirective, "[bdTooltip]", never, { "bdTooltip": { "alias": "bdTooltip"; "required": true; "isSignal": true; }; "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdTourPlacement = 'top' | 'bottom' | 'left' | 'right' | 'auto';
interface BdTourStep {
    /** Seletor CSS do elemento a destacar. Sem alvo, o passo é centralizado. */
    target?: string;
    title: string;
    content: string;
    /** Lado preferido do balão. `auto` escolhe o primeiro lado com espaço. */
    placement?: BdTourPlacement;
    /** Rótulo do botão de avanço deste passo. */
    nextLabel?: string;
}
interface BdTourLabels {
    next: string;
    prev: string;
    finish: string;
    skip: string;
    /** Recebe (posição atual, total) — ex.: "2 de 5". */
    counter: (current: number, total: number) => string;
}
/** Desfecho de um tour encerrado. */
interface BdTourOutcome {
    /** `true` quando o usuário percorreu todos os passos até o fim. */
    completed: boolean;
    /** Índice do passo em que o tour foi encerrado. */
    step: number;
}
declare const BD_TOUR_DEFAULT_LABELS: BdTourLabels;
/**
 * Orquestra o tour guiado de integração. Injete onde for necessário e invoque
 * `start()`; o componente `<bd-tour />` deve estar montado uma única vez na
 * aplicação — tipicamente no componente raiz — para desenhar destaque e balão.
 *
 * O estado é exposto como signals somente-leitura, o que permite reagir ao
 * progresso do tour em qualquer ponto da aplicação.
 *
 * @example
 * ```ts
 * private readonly tour = inject(BdTourService);
 *
 * apresentar(): void {
 *   // `startOnce` registra a exibição e não repete o tour para este usuário.
 *   this.tour.startOnce('onboarding-v1', [
 *     { target: '#busca', title: 'Busca', content: 'Localize qualquer projeto.' },
 *     { target: '#filtros', title: 'Filtros', content: 'Refine por status e período.' },
 *   ]);
 * }
 * ```
 */
declare class BdTourService {
    private readonly document;
    private readonly _steps;
    private readonly _index;
    private readonly _active;
    private readonly _outcome;
    private storageKey;
    readonly labels: _angular_core.WritableSignal<BdTourLabels>;
    readonly steps: _angular_core.Signal<BdTourStep[]>;
    readonly index: _angular_core.Signal<number>;
    readonly active: _angular_core.Signal<boolean>;
    /** Desfecho do último tour encerrado; `null` enquanto nenhum terminou. */
    readonly outcome: _angular_core.Signal<BdTourOutcome | null>;
    readonly total: _angular_core.Signal<number>;
    readonly step: _angular_core.Signal<BdTourStep | null>;
    readonly isFirst: _angular_core.Signal<boolean>;
    readonly isLast: _angular_core.Signal<boolean>;
    /** Inicia o tour a partir do primeiro passo. */
    start(steps: BdTourStep[], labels?: Partial<BdTourLabels>): void;
    /**
     * Inicia o tour apenas na primeira vez para esta chave, registrando a
     * exibição no `localStorage`. Versione a chave (`onboarding-v2`) para
     * reapresentar o tour após uma mudança relevante de interface.
     *
     * @returns `true` se o tour foi iniciado.
     */
    startOnce(key: string, steps: BdTourStep[], labels?: Partial<BdTourLabels>): boolean;
    /** Indica se o tour desta chave já foi encerrado alguma vez neste dispositivo. */
    hasSeen(key: string): boolean;
    /** Descarta o registro de exibição, permitindo reapresentar o tour. */
    reset(key: string): void;
    next(): void;
    prev(): void;
    /** Salta diretamente para um passo pelo índice. */
    goTo(index: number): void;
    /** Encerra após percorrer todos os passos. */
    finish(): void;
    /** Encerra antecipadamente (`Esc`, clique fora ou botão de pular). */
    skip(): void;
    private end;
    /**
     * O armazenamento é opcional por natureza: não existe em renderização no
     * servidor e lança exceção em navegação privada com cookies bloqueados.
     * Em ambos os casos o tour segue funcionando, apenas sem memória.
     */
    private storage;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTourService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BdTourService>;
}

interface Rect {
    top: number;
    left: number;
    width: number;
    height: number;
}
interface PopoverPosition {
    top: number;
    left: number;
    side: Exclude<BdTourPlacement, 'auto'> | 'center';
}
/**
 * Camada de apresentação do tour guiado. Monte uma única vez, normalmente no
 * componente raiz:
 *
 * ```html
 * <router-outlet />
 * <bd-tour />
 * ```
 *
 * O controle pertence ao {@link BdTourService}. O destaque recorta o elemento
 * alvo por meio de uma sombra projetada maior que a área visível, o balão é
 * posicionado no primeiro lado com espaço disponível e recebe o foco a cada
 * passo — `Esc` encerra, setas navegam.
 */
declare class BdTourComponent {
    readonly tour: BdTourService;
    /** Espaço extra em volta do elemento destacado. */
    readonly spotPadding: _angular_core.InputSignal<number>;
    /** Rola o alvo até o centro da área visível antes de destacá-lo. */
    readonly scrollIntoView: _angular_core.InputSignal<boolean>;
    private readonly document;
    private readonly popover;
    protected readonly titleId = "bd-tour-title";
    protected readonly contentId = "bd-tour-content";
    protected readonly spot: _angular_core.WritableSignal<Rect>;
    protected readonly position: _angular_core.WritableSignal<PopoverPosition>;
    protected readonly hasTarget: _angular_core.WritableSignal<boolean>;
    private settleTimer?;
    private frame?;
    /**
     * Reagenda a medição no ritmo do compositor.
     *
     * Rolagem e redimensionamento apenas remedem: **não** movem o foco. Medir e
     * focar são operações distintas justamente porque a rolagem suave do próprio
     * passo emite dezenas de eventos — devolver o foco em cada um deles tornaria
     * a página impossível de percorrer durante o tour.
     */
    private readonly onViewportChange;
    constructor();
    protected onKeydown(event: KeyboardEvent): void;
    /**
     * Resolve o alvo do passo. Um seletor malformado não deve derrubar a
     * aplicação: o passo degrada para a apresentação centralizada.
     */
    private resolveTarget;
    /** Mede o alvo e reposiciona destaque e balão. Não altera o foco. */
    private measure;
    /**
     * Escolhe o primeiro lado com espaço suficiente. Em `auto`, a ordem é
     * abaixo, acima, direita e esquerda; sem espaço em nenhum, centraliza.
     */
    private resolvePosition;
    private popoverHeight;
    /** Leva o foco ao balão para que o leitor de tela anuncie o passo. */
    private focusPopover;
    private isFocusWithinPopover;
    private isFocusOnControl;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdTourComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdTourComponent, "bd-tour", never, { "spotPadding": { "alias": "spotPadding"; "required": false; "isSignal": true; }; "scrollIntoView": { "alias": "scrollIntoView"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Anima um número de 0 até o value final quando o elemento entra na viewport.
 *
 * Escreve direto no DOM via `requestAnimationFrame`, sem disparar change
 * detection a cada quadro. Seguro em SSR e respeita `prefers-reduced-motion`
 * (nesse caso mostra o value final imediatamente).
 *
 * @example
 * ```html
 * <span [bdCountUp]="3" suffix="+"></span>
 * <span [bdCountUp]="1250" prefix="R$ " [duration]="2000"></span>
 * ```
 */
declare class BdCountUpDirective {
    readonly bdCountUp: _angular_core.InputSignal<number>;
    readonly prefix: _angular_core.InputSignal<string>;
    readonly suffix: _angular_core.InputSignal<string>;
    /** Duração da contagem em milissegundos. */
    readonly duration: _angular_core.InputSignal<number>;
    private readonly host;
    private observer?;
    private frame?;
    constructor();
    private configurar;
    private animar;
    private render;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdCountUpDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BdCountUpDirective, "[bdCountUp]", never, { "bdCountUp": { "alias": "bdCountUp"; "required": true; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "duration": { "alias": "duration"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type BdRevealDirection = 'up' | 'down' | 'left' | 'right' | 'scale';
/**
 * Revela o elemento quando ele entra na viewport.
 *
 * A transição anima apenas `opacity` e `transform` — propriedades compostas
 * na GPU —, portanto não bloqueia a rolagem. O observador é desconectado assim
 * que o elemento entra em cena.
 *
 * Não exige configuração de estilos: as regras de base são garantidas em tempo
 * de execução e permanecem sobrescrevíveis pela folha
 * `bandeira-ui/styles/animations` ou pelo CSS da aplicação.
 *
 * Compatível com renderização no servidor: a configuração ocorre dentro de
 * `afterNextRender`, que só executa no navegador.
 *
 * @example
 * ```html
 * <div bdReveal></div>
 * <div bdReveal="left" [revealDelay]="120"></div>
 * <div bdReveal="scale" [revealOnce]="false"></div>
 * ```
 */
declare class BdRevealDirective {
    /** Direção de entrada do elemento. */
    readonly bdReveal: _angular_core.InputSignal<"" | BdRevealDirection>;
    /** Atraso em milissegundos — use `i * 80` em listas para criar cascata. */
    readonly revealDelay: _angular_core.InputSignal<number>;
    /** Quando `false`, o elemento volta a esconder ao sair da viewport. */
    readonly revealOnce: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly host;
    private readonly document;
    private observer?;
    constructor();
    private setup;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdRevealDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BdRevealDirective, "[bdReveal]", never, { "bdReveal": { "alias": "bdReveal"; "required": false; "isSignal": true; }; "revealDelay": { "alias": "revealDelay"; "required": false; "isSignal": true; }; "revealOnce": { "alias": "revealOnce"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Estrutura de painel analítico: cabeçalho, faixa de indicadores e uma grade
 * de conteúdo com coluna principal e coluna lateral.
 *
 * A hierarquia é deliberada — indicadores no topo respondem "como estamos?" em
 * um relance; a coluna principal desenvolve a resposta; a lateral concentra o
 * secundário. Abaixo de 1080px as colunas se empilham e a lateral desce, de
 * modo que a leitura no celular preserva a mesma ordem de importância.
 *
 * @example
 * ```html
 * <bd-dashboard-template
 *   title="Visão geral"
 *   description="Desempenho consolidado dos últimos 30 dias."
 * >
 *   <button bdButton bdDashboardActions>Exportar</button>
 *
 *   <bd-metric bdDashboardMetrics label="Receita" value="R$ 128k" />
 *   <bd-metric bdDashboardMetrics label="Assinantes" value="2.480" />
 *
 *   <bd-card>Gráfico principal</bd-card>
 *
 *   <bd-card bdDashboardAside>Atividade recente</bd-card>
 * </bd-dashboard-template>
 * ```
 */
declare class BdDashboardTemplateComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    /** Rótulo acessível da coluna lateral. */
    readonly asideLabel: _angular_core.InputSignal<string>;
    /**
     * Reserva a coluna lateral. Precisa ser declarado porque o conteúdo
     * projetado não é observável a partir do componente: a decisão de layout
     * pertence a quem monta a tela.
     */
    readonly hasAside: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdDashboardTemplateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdDashboardTemplateComponent, "bd-dashboard-template", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "asideLabel": { "alias": "asideLabel"; "required": false; "isSignal": true; }; "hasAside": { "alias": "hasAside"; "required": false; "isSignal": true; }; }, {}, never, ["[bdDashboardActions]", "[bdDashboardMetrics]", "*", "[bdDashboardAside]"], true, never>;
}

/**
 * Estrutura de listagem para telas de cadastro e consulta: cabeçalho, barra de
 * busca e filtros, área de resultados e rodapé de paginação.
 *
 * Os três estados de uma listagem — carregando, vazia e preenchida — são
 * mutuamente exclusivos e ficam sob responsabilidade do template. Isso elimina
 * a repetição de `@if` em cada tela e, mais importante, elimina a divergência:
 * o estado de carregamento é anunciado por `aria-busy` em toda a aplicação, e
 * não apenas onde alguém lembrou de fazê-lo.
 *
 * @example
 * ```html
 * <bd-list-template
 *   title="Projetos"
 *   description="Tudo que está em andamento na sua equipe."
 *   [loading]="carregando()"
 *   [empty]="projetos().length === 0"
 * >
 *   <button bdButton bdListActions>Novo projeto</button>
 *
 *   <input bdInput bdListSearch type="search" placeholder="Buscar projetos" />
 *   <bd-chip bdListFilters selectable>Ativos</bd-chip>
 *
 *   <bd-empty-state bdListEmpty title="Nenhum projeto ainda" />
 *
 *   <table>…</table>
 *
 *   <span bdListFooter>24 resultados</span>
 * </bd-list-template>
 * ```
 */
declare class BdListTemplateComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    /** Exibe os placeholders no lugar dos resultados. */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Exibe o conteúdo de `[bdListEmpty]` no lugar dos resultados. */
    readonly empty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Quantidade de linhas de placeholder durante o carregamento. */
    readonly placeholderCount: _angular_core.InputSignal<number>;
    /** Texto anunciado por leitores de tela durante o carregamento. */
    readonly loadingLabel: _angular_core.InputSignal<string>;
    protected readonly placeholderRows: _angular_core.Signal<number[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdListTemplateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdListTemplateComponent, "bd-list-template", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "empty": { "alias": "empty"; "required": false; "isSignal": true; }; "placeholderCount": { "alias": "placeholderCount"; "required": false; "isSignal": true; }; "loadingLabel": { "alias": "loadingLabel"; "required": false; "isSignal": true; }; }, {}, never, ["[bdListActions]", "[bdListSearch]", "[bdListFilters]", "[bdListEmpty]", "*", "[bdListFooter]"], true, never>;
}

interface BdSettingsSection {
    /** Identificador usado na âncora e na seleção. */
    id: string;
    label: string;
    /** Texto auxiliar exibido abaixo do rótulo na navegação. */
    hint?: string;
}
/**
 * Estrutura de preferências: navegação por seções à esquerda, formulário à
 * direita e barra de gravação fixa ao pé da tela.
 *
 * A navegação é uma lista de âncoras reais, não um seletor decorativo: cada
 * seção permanece endereçável por URL, localizável pela busca do navegador e
 * acessível ao leitor de tela, que percorre o formulário inteiro em ordem.
 *
 * A barra de gravação só aparece quando há alterações pendentes — uma barra
 * permanentemente visível deixa de comunicar qualquer coisa.
 *
 * @example
 * ```html
 * <bd-settings-template
 *   title="Configurações"
 *   [sections]="secoes"
 *   [(activeSection)]="secaoAtual"
 *   [dirty]="formulario.dirty"
 * >
 *   <section id="perfil">…</section>
 *   <section id="notificacoes">…</section>
 *
 *   <button bdButton bdSettingsActions variant="ghost" (click)="restaurar()">Descartar</button>
 *   <button bdButton bdSettingsActions (click)="salvar()">Salvar alterações</button>
 * </bd-settings-template>
 * ```
 */
declare class BdSettingsTemplateComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly sections: _angular_core.InputSignal<readonly BdSettingsSection[]>;
    /** Two-way: `[(activeSection)]="secaoAtual"`. */
    readonly activeSection: _angular_core.ModelSignal<string>;
    /** Revela a barra de gravação. Ligue ao estado do formulário. */
    readonly dirty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dirtyLabel: _angular_core.InputSignal<string>;
    readonly navLabel: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdSettingsTemplateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdSettingsTemplateComponent, "bd-settings-template", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "sections": { "alias": "sections"; "required": false; "isSignal": true; }; "activeSection": { "alias": "activeSection"; "required": false; "isSignal": true; }; "dirty": { "alias": "dirty"; "required": false; "isSignal": true; }; "dirtyLabel": { "alias": "dirtyLabel"; "required": false; "isSignal": true; }; "navLabel": { "alias": "navLabel"; "required": false; "isSignal": true; }; }, { "activeSection": "activeSectionChange"; }, never, ["*", "[bdSettingsActions]"], true, never>;
}

/** As etapas do assistente são as mesmas do indicador {@link BdStepsComponent}. */
type BdWizardStep = BdStep;
/**
 * Estrutura de assistente por etapas: indicador de progresso, área da etapa
 * atual e rodapé de navegação.
 *
 * O indicador é uma lista ordenada real, anotada com `aria-current="step"`, de
 * modo que a posição no processo é anunciada e não apenas colorida. Etapas já
 * concluídas voltam a ser navegáveis; as futuras permanecem bloqueadas,
 * porque avançar sem completar a etapa corrente produz dados inconsistentes.
 *
 * A validação é do formulário, não do template: enquanto `canAdvance` for
 * `false`, o botão de avanço fica desabilitado e `next` não é emitido.
 *
 * @example
 * ```html
 * <bd-wizard-template
 *   title="Novo projeto"
 *   [steps]="etapas"
 *   [(activeStep)]="etapa"
 *   [canAdvance]="formulario.valid"
 *   (finish)="concluir()"
 * >
 *   @switch (etapa()) {
 *     @case (0) { <section>Dados básicos</section> }
 *     @case (1) { <section>Equipe</section> }
 *   }
 * </bd-wizard-template>
 * ```
 */
declare class BdWizardTemplateComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly steps: _angular_core.InputSignal<readonly BdStep[]>;
    /** Two-way: `[(activeStep)]="etapa"`. */
    readonly activeStep: _angular_core.ModelSignal<number>;
    /**
     * Libera o avanço. Ligue à validade do formulário da etapa corrente — com
     * `false`, o botão fica desabilitado e nenhum evento é emitido.
     */
    readonly canAdvance: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Estilo do indicador de progresso. Ver {@link BdStepsVariant}. */
    readonly stepsVariant: _angular_core.InputSignal<BdStepsVariant>;
    readonly previousLabel: _angular_core.InputSignal<string>;
    readonly nextLabel: _angular_core.InputSignal<string>;
    readonly finishLabel: _angular_core.InputSignal<string>;
    readonly stepsLabel: _angular_core.InputSignal<string>;
    /** Emitido ao entrar em uma etapa, com o índice de destino. */
    readonly stepChange: _angular_core.OutputEmitterRef<number>;
    /** Emitido ao confirmar a última etapa. */
    readonly finish: _angular_core.OutputEmitterRef<void>;
    protected readonly isFirst: _angular_core.Signal<boolean>;
    protected readonly isLast: _angular_core.Signal<boolean>;
    protected advance(): void;
    protected previous(): void;
    /**
     * Aplica a etapa de destino. O indicador só emite índices anteriores ao
     * corrente — saltar adiante nunca é permitido, porque o template não tem como
     * saber se as etapas intermediárias foram preenchidas. O avanço passa por
     * `advance()`, que respeita `canAdvance`.
     */
    protected setStep(index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdWizardTemplateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BdWizardTemplateComponent, "bd-wizard-template", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "activeStep": { "alias": "activeStep"; "required": false; "isSignal": true; }; "canAdvance": { "alias": "canAdvance"; "required": false; "isSignal": true; }; "stepsVariant": { "alias": "stepsVariant"; "required": false; "isSignal": true; }; "previousLabel": { "alias": "previousLabel"; "required": false; "isSignal": true; }; "nextLabel": { "alias": "nextLabel"; "required": false; "isSignal": true; }; "finishLabel": { "alias": "finishLabel"; "required": false; "isSignal": true; }; "stepsLabel": { "alias": "stepsLabel"; "required": false; "isSignal": true; }; }, { "activeStep": "activeStepChange"; "stepChange": "stepChange"; "finish": "finish"; }, never, ["*", "[bdWizardActions]"], true, never>;
}

/**
 * Pilha das camadas sobrepostas abertas (diálogos, tour, gavetas).
 *
 * Existe para que atalhos globais atinjam apenas a camada do topo: com dois
 * diálogos empilhados, `Esc` fecha o de cima e mantém o de baixo. Sem essa
 * arbitragem, cada instância reagiria ao mesmo evento de teclado.
 */
declare class BdOverlayStackService {
    private readonly stack;
    push(reference: unknown): void;
    remove(reference: unknown): void;
    /** `true` quando a referência é a camada mais alta da pilha. */
    isTopmost(reference: unknown): boolean;
    get depth(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdOverlayStackService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BdOverlayStackService>;
}

/**
 * Trava a rolagem do documento enquanto houver camadas sobrepostas abertas.
 *
 * O controle é por contagem de referências: dois diálogos empilhados produzem
 * duas travas, e a rolagem só volta quando a última é liberada. O valor
 * original de `overflow` é preservado e restaurado — a biblioteca não descarta
 * estilos definidos pela aplicação hospedeira.
 *
 * A largura da barra de rolagem é compensada com `padding-right` para que o
 * conteúdo não salte lateralmente ao abrir a camada.
 */
declare class BdScrollLockService {
    private readonly document;
    private references;
    private previousOverflow;
    private previousPaddingRight;
    /** Número de travas ativas. Exposto para diagnóstico e testes. */
    get active(): number;
    lock(): void;
    release(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BdScrollLockService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BdScrollLockService>;
}

/**
 * Conjunto completo da biblioteca, para importação única:
 *
 * ```ts
 * @Component({ imports: [BANDEIRA_UI] })
 * ```
 *
 * Conveniente em protótipos. Em produção, importe apenas o que a tela utiliza:
 * a eliminação de código não utilizado depende disso.
 */
declare const BANDEIRA_UI: readonly [typeof BdAccordionComponent, typeof BdAlertComponent, typeof BdAppShellComponent, typeof BdAuthLayoutComponent, typeof BdAvatarComponent, typeof BdBadgeComponent, typeof BdButtonComponent, typeof BdCardComponent, typeof BdCheckboxComponent, typeof BdChipComponent, typeof BdContainerComponent, typeof BdDashboardTemplateComponent, typeof BdEmptyStateComponent, typeof BdFieldComponent, typeof BdInputComponent, typeof BdListTemplateComponent, typeof BdMetricComponent, typeof BdModalComponent, typeof BdPageHeaderComponent, typeof BdPaginationComponent, typeof BdProgressComponent, typeof BdSettingsTemplateComponent, typeof BdSkeletonComponent, typeof BdSpinnerComponent, typeof BdStepsComponent, typeof BdSwitchComponent, typeof BdTabPanelComponent, typeof BdTableComponent, typeof BdTabsComponent, typeof BdTooltipDirective, typeof BdTourComponent, typeof BdWizardTemplateComponent, typeof BdCountUpDirective, typeof BdRevealDirective];

export { BANDEIRA_UI, BD_TOUR_DEFAULT_LABELS, BdAccordionComponent, BdAlertComponent, BdAppShellComponent, BdAuthLayoutComponent, BdAvatarComponent, BdBadgeComponent, BdButtonComponent, BdCardComponent, BdCheckboxComponent, BdChipComponent, BdContainerComponent, BdCountUpDirective, BdDashboardTemplateComponent, BdEmptyStateComponent, BdFieldComponent, BdInputComponent, BdListTemplateComponent, BdMetricComponent, BdModalComponent, BdOverlayStackService, BdPageHeaderComponent, BdPaginationComponent, BdProgressComponent, BdRevealDirective, BdScrollLockService, BdSettingsTemplateComponent, BdSkeletonComponent, BdSpinnerComponent, BdStepsComponent, BdSwitchComponent, BdTabPanelComponent, BdTableComponent, BdTabsComponent, BdTooltipDirective, BdTourComponent, BdTourService, BdWizardTemplateComponent };
export type { BdAccordionItem, BdAlertTone, BdAuthAsideSide, BdAvatarSize, BdBadgeTone, BdButtonSize, BdButtonVariant, BdCardPadding, BdChipTone, BdContainerSize, BdMetricAlign, BdMetricTrend, BdPageEvent, BdProgressTone, BdRevealDirection, BdSettingsSection, BdSkeletonVariant, BdSortDirection, BdSortState, BdSpinnerSize, BdStep, BdStepsOrientation, BdStepsVariant, BdTab, BdTableAlign, BdTableColumn, BdTableFrozen, BdTooltipPlacement, BdTourLabels, BdTourOutcome, BdTourPlacement, BdTourStep, BdWizardStep };
