# Changelog

## 0.1.0 — 2026-09-01

Primeira extração, a partir do app shell do `vitality-front`:

- `BsShellComponent` — grid sidebar/topbar responsivo, bottom-nav + bottom-sheet "mais" abaixo de
  900px, toggle sidebar/horizontal, dropdown de tema e de paleta embutidos; conteúdo específico do
  app entra via slots de projeção (`bsShellBrand`, `bsShellGreeting`, `bsShellTopActions`,
  `bsShellSidebarFooter`, `bsShellOverlays`).
- `BsThemeService` / `provideShellTheme()` — tema claro/escuro.
- `BsPaletteService` / `provideShellPalette()` / `BsPalettePickerComponent` — paletas trocáveis
  (o pacote não dita cores; ver `styles/_palette-contract.scss`).
- `BsNavigationLayoutService`, `BsNavigationProgressService` — toggle sidebar/horizontal e
  indicador de navegação em andamento.
- `BsOverlayStackService` — pilha de overlays fecháveis pelo topo (usada pelo botão físico voltar).
- `BsPlatformService`, `BsNativeShellService` / `provideShellNative()` — comportamento nativo
  Capacitor (botão voltar, barra de status, splash, revalidação de sessão), desacoplado de
  `AuthService`/serviço de toast concretos via hooks (`onExitConfirmRequested`, `onResume`).
- `provideShell()` — açúcar que agrega os `provide*()` acima.
- `generateAntiFlashScript()` — gera o snippet do script anti-flash de tema/paleta para o
  `index.html`, a partir da mesma lista de paletas usada em `provideShellPalette()`.
