# bandeira-shell

Motor de app shell reutilizável para Angular 20 — sidebar/topbar responsivo, tema claro/escuro,
paletas trocáveis e comportamento nativo Capacitor (botão físico de voltar), tudo parametrizável
via `provide*()` (mesmo idioma de `provideRouter`/`provideHttpClient`), sem depender de nenhum
domínio de app específico. Extraído do app shell do `vitality-front`.

Peer dependencies: `@angular/core`/`@angular/common`/`@angular/router` `>=20`, `@lucide/angular`,
e [`bandeira-ui`](https://www.npmjs.com/package/bandeira-ui) (usado internamente para
botão/tooltip). `@capacitor/*` são peer dependencies opcionais — só é preciso instalá-los se o
app roda em Capacitor.

## Instalação

Este pacote não é publicado em registry — é distribuído como tarball local, no mesmo padrão de
`bandeira-ui`:

```bash
npm run pack:lib          # gera dist/bandeira-shell-<versão>.tgz
cp dist/bandeira-shell-*.tgz ../seu-projeto/vendor/
```

E no `package.json` do projeto consumidor:

```json
"dependencies": {
  "bandeira-shell": "file:vendor/bandeira-shell-0.1.0.tgz"
}
```

## Uso básico

```ts
// app.config.ts
import { provideShell } from 'bandeira-shell';
import { LucideHouse, LucideUser } from '@lucide/angular';

export const appConfig: ApplicationConfig = {
  providers: [
    // ...
    provideShell({
      palette: {
        options: [{ id: 'default', label: 'Padrão', swatch: '#5c7a3f' }],
        defaultId: 'default',
      },
      navigation: [
        { path: '/dashboard', label: 'Dashboard', icon: LucideHouse },
        { path: '/perfil', label: 'Perfil', icon: LucideUser },
      ],
    }),
  ],
};
```

```html
<!-- shell.component.html do app consumidor -->
<bs-shell>
  <a bsShellBrand routerLink="/dashboard">Minha marca</a>
  <span bsShellGreeting>Olá!</span>
  <div bsShellTopActions>
    <button (click)="logout()">Sair</button>
  </div>
</bs-shell>
```

O app é dono das cores: defina os tokens `--bd-primary*`/`--bs-sidebar-*` de cada paleta no seu
`styles.scss`, usando o mixin `bs-palette()` de `bandeira-shell/styles/palette-contract` — ver
`CHANGELOG.md` e os comentários em `styles/_palette-contract.scss` para o contrato completo.

## Desenvolvimento

```bash
npm run build:lib   # ng build + copia README/LICENSE/CHANGELOG pro pacote
npm run pack:lib     # build:lib + npm pack em dist/
npm test             # karma, headless
```
