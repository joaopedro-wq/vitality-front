import * as i0 from '@angular/core';
import { InjectionToken, EnvironmentProviders } from '@angular/core';
import { LucideIcon } from '@lucide/angular';

type BsTheme = 'light' | 'dark';
interface ShellThemeConfig {
    /** Chave usada no `localStorage`. @default 'theme' */
    storageKey?: string;
    /** Tema usado quando não há preferência salva nem `prefers-color-scheme`. */
    default?: BsTheme;
}
declare const SHELL_THEME_CONFIG: InjectionToken<Required<ShellThemeConfig>>;
/**
 * Registra o serviço de tema claro/escuro (`BsThemeService`) — signal +
 * `data-theme` no `documentElement` + persistência em `localStorage`.
 *
 * `storageKey` default é `'theme'`, a mesma chave usada historicamente pelo
 * vitality-front: manter o default evita resetar a preferência de quem já
 * tem o valor salvo no navegador.
 */
declare function provideShellTheme(config?: ShellThemeConfig): EnvironmentProviders;

/**
 * Tema claro/escuro do shell. Genérico — sem nenhum conhecimento do app
 * consumidor. Lê o estado inicial do próprio atributo `data-theme` (setado
 * por um script anti-flash antes do Angular bootar, ver `generateAntiFlashScript`)
 * ou de `prefers-color-scheme`, e a partir daí persiste em `localStorage`.
 */
declare class BsThemeService {
    private readonly document;
    private readonly config;
    private readonly themeSignal;
    readonly theme: i0.Signal<BsTheme>;
    constructor();
    toggle(): void;
    set(theme: BsTheme): void;
    private apply;
    private readInitialTheme;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsThemeService>;
}

interface ShellPaletteOption {
    id: string;
    label: string;
    /** Cor usada no swatch do seletor — normalmente o `--bd-primary` claro desta paleta. */
    swatch: string;
}
interface ShellPaletteConfig {
    /** Ordem em que aparecem no seletor. */
    options: ShellPaletteOption[];
    /** Id usado quando não há preferência salva nem atributo já presente no `<html>`. */
    defaultId: string;
    /** Chave usada no `localStorage`. @default 'palette' */
    storageKey?: string;
}
declare const SHELL_PALETTE_CONFIG: InjectionToken<Required<ShellPaletteConfig>>;
/**
 * Registra o serviço de paleta trocável (`BsPaletteService`) — signal +
 * `data-palette` no `documentElement` + persistência em `localStorage`.
 *
 * O pacote não dita cores: `options` é a lista de paletas do app consumidor
 * (id/label/swatch); os tokens CSS de cada paleta (`--bd-primary*`,
 * `--bs-sidebar-*`) são escritos pelo próprio app usando o mixin
 * `bs-palette()` de `bandeira-shell/styles` — ver `_palette-contract.scss`.
 */
declare function provideShellPalette(config: ShellPaletteConfig): EnvironmentProviders;

/**
 * Paleta de cor do sistema (primary + chrome do menu) — independente do tema
 * claro/escuro (`BsThemeService`). Mesmo padrão: signal + `data-palette` no
 * `documentElement` + `localStorage`, lido antes do Angular bootar pelo
 * script anti-flash (`generateAntiFlashScript`).
 */
declare class BsPaletteService {
    private readonly document;
    private readonly config;
    readonly paletas: readonly ShellPaletteOption[];
    private readonly paletteSignal;
    readonly palette: i0.Signal<string>;
    constructor();
    set(id: string): void;
    private apply;
    private readInitialPalette;
    private isKnownId;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsPaletteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsPaletteService>;
}

/**
 * Item de navegação do shell. O pacote não força i18n: `label`/`mobileLabel`
 * aceitam uma string já resolvida ou um getter reativo (o app decide a fonte
 * — Transloco, `@angular/localize`, texto fixo...).
 */
interface ShellNavItem {
    path: string;
    label: string | (() => string);
    /** Rótulo alternativo, mais curto, para a barra mobile. @default label */
    mobileLabel?: string | (() => string);
    icon: LucideIcon;
    /** Reavaliado a cada render — generaliza um `adminOnly` fixo. */
    visible?: () => boolean;
    /**
     * Em telas <900px, o item vai para a barra fixa (`'bar'`, padrão) ou para
     * a gaveta "mais" (`'more'`). Generaliza a exclude-list hardcoded de hoje.
     */
    mobileSlot?: 'bar' | 'more';
    /** Bag genérico de atributos (ex.: alvo de um tour guiado), sem acoplar a nenhuma feature. */
    data?: Record<string, string>;
}
declare function resolveShellLabel(label: string | (() => string)): string;
declare const SHELL_NAVIGATION_CONFIG: InjectionToken<ShellNavItem[]>;
/** Registra os itens de navegação do shell (sidebar, nav horizontal, mobile). */
declare function provideShellNavigation(items: ShellNavItem[]): EnvironmentProviders;

type BsNavigationLayout = 'sidebar' | 'horizontal';
/** Alterna entre sidebar e nav horizontal — genérico, sem conhecimento de domínio. */
declare class BsNavigationLayoutService {
    private readonly layoutSignal;
    readonly layout: i0.Signal<BsNavigationLayout>;
    toggle(): void;
    private readInitialLayout;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsNavigationLayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsNavigationLayoutService>;
}

/**
 * Sinaliza que uma navegação está em andamento — útil quando as rotas são
 * lazy (`loadComponent`) e trocar de tela baixa um chunk sem indicador algum.
 * Trata todos os desfechos de navegação, não só o feliz: só ouvir
 * `NavigationStart`/`NavigationEnd` deixaria o indicador preso quando um
 * guard cancela a navegação.
 */
declare class BsNavigationProgressService {
    private readonly router;
    private readonly navegandoSignal;
    readonly navegando: i0.Signal<boolean>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<BsNavigationProgressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsNavigationProgressService>;
}

/**
 * Pilha de overlays fecháveis (menu "mais" mobile, dropdown de paleta,
 * modais). Qualquer camada se registra ao abrir; o botão físico de voltar
 * (Capacitor) ou uma tecla Escape fecham só o topo da pilha, sem saber o que
 * cada camada é.
 */
declare class BsOverlayStackService {
    private readonly camadas;
    registrar(fechar: () => void): () => void;
    fecharTopo(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsOverlayStackService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsOverlayStackService>;
}

declare class BsPlatformService {
    readonly isNative: boolean;
    readonly isAndroid: boolean;
    readonly isIos: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsPlatformService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsPlatformService>;
}

/**
 * Configuração do comportamento nativo (Capacitor) do shell — botão físico
 * de voltar, revalidação ao voltar do segundo plano, barra de status.
 * Desacoplado de qualquer `AuthService`/serviço de toast concreto: o app
 * consumidor decide o que fazer nos dois pontos de extensão (`onExitConfirmRequested`,
 * `onResume`).
 */
interface ShellNativeConfig {
    /** Rotas onde o botão voltar não navega para trás — exige duplo toque para sair. */
    rootRoutes: string[];
    /** Janela do duplo toque de saída, em ms. @default 2000 */
    exitConfirmWindowMs?: number;
    /** Chamado no primeiro toque de saída, na raiz (ex.: mostrar um toast de dica). */
    onExitConfirmRequested?: () => void;
    /** Chamado quando o app volta do segundo plano com sessão ativa (ex.: revalidar token). */
    onResume?: () => void;
    /** Chama `start()` automaticamente via `provideAppInitializer`. @default true */
    autoStart?: boolean;
}
declare const SHELL_NATIVE_CONFIG: InjectionToken<Required<ShellNativeConfig>>;
declare function provideShellNative(config: ShellNativeConfig): EnvironmentProviders;

/**
 * Comportamento nativo do shell no Capacitor: botão físico de voltar,
 * barra de status reagindo ao tema, splash e revalidação de sessão ao
 * voltar do segundo plano. No-op completo no navegador (`BsPlatformService.isNative`).
 */
declare class BsNativeShellService {
    private readonly platform;
    private readonly zone;
    private readonly router;
    private readonly overlays;
    private readonly theme;
    private readonly config;
    private readonly listeners;
    private saidaConfirmadaAte;
    private iniciado;
    constructor();
    /** Chamado uma vez, depois do bootstrap do Angular (ver `provideShellNative`/`autoStart`). */
    start(): void;
    stop(): Promise<void>;
    private onBackButton;
    private onAppStateChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<BsNativeShellService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BsNativeShellService>;
}

/**
 * Gera o snippet JS do script anti-flash de tema/paleta — pensado para ser
 * injetado no `<head>` do `index.html`, ANTES de qualquer bundle Angular
 * (por isso é uma função pura que devolve string, não código que roda no
 * browser). Aplica `data-theme`/`data-palette` no `<html>` a partir do
 * `localStorage`, evitando o flash do tema/paleta default no primeiro paint.
 *
 * Não é chamada em runtime pelo app: um script de build (Node, ex.
 * `scripts/sync-index-html.mjs`) chama esta função lendo a MESMA lista de
 * paletas usada em `provideShellPalette()`, e reescreve o bloco entre
 * marcadores no `index.html` — fonte única, sem lista duplicada à mão.
 */
interface AntiFlashOptions {
    themeStorageKey?: string;
    paletteStorageKey?: string;
    defaultPaletteId: string;
}
declare function generateAntiFlashScript(paletteIds: string[], options: AntiFlashOptions): string;

interface ProvideShellConfig {
    theme?: ShellThemeConfig;
    palette: ShellPaletteConfig;
    navigation: ShellNavItem[];
    /** Omitir se o app não roda em Capacitor — nenhum provider nativo é registrado. */
    native?: ShellNativeConfig;
}
/**
 * Açúcar sintático: registra tema, paleta, navegação e (opcionalmente) o
 * comportamento nativo do shell num só `provide*()`, no espírito de
 * `provideRouter`/`provideHttpClient`. Equivale a chamar `provideShellTheme`
 * + `provideShellPalette` + `provideShellNavigation` + `provideShellNative`
 * separadamente — use as funções individuais se precisar de mais controle
 * sobre a ordem/composição dos providers.
 */
declare function provideShell(config: ProvideShellConfig): EnvironmentProviders;

export { BsNativeShellService, BsNavigationLayoutService, BsNavigationProgressService, BsOverlayStackService, BsPaletteService, BsPlatformService, BsThemeService, SHELL_NATIVE_CONFIG, SHELL_NAVIGATION_CONFIG, SHELL_PALETTE_CONFIG, SHELL_THEME_CONFIG, generateAntiFlashScript, provideShell, provideShellNative, provideShellNavigation, provideShellPalette, provideShellTheme, resolveShellLabel };
export type { AntiFlashOptions, BsNavigationLayout, BsTheme, ProvideShellConfig, ShellNativeConfig, ShellNavItem, ShellPaletteConfig, ShellPaletteOption, ShellThemeConfig };
