import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, inject, signal, Injectable, NgZone, effect, provideAppInitializer } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError, NavigationSkipped } from '@angular/router';
import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { SplashScreen } from '@capacitor/splash-screen';
import { StatusBar, Style } from '@capacitor/status-bar';

const SHELL_THEME_CONFIG = new InjectionToken('SHELL_THEME_CONFIG');
const DEFAULT_CONFIG = {
    storageKey: 'theme',
    default: 'dark',
};
/**
 * Registra o serviço de tema claro/escuro (`BsThemeService`) — signal +
 * `data-theme` no `documentElement` + persistência em `localStorage`.
 *
 * `storageKey` default é `'theme'`, a mesma chave usada historicamente pelo
 * vitality-front: manter o default evita resetar a preferência de quem já
 * tem o valor salvo no navegador.
 */
function provideShellTheme(config = {}) {
    return makeEnvironmentProviders([
        { provide: SHELL_THEME_CONFIG, useValue: { ...DEFAULT_CONFIG, ...config } },
    ]);
}

/**
 * Tema claro/escuro do shell. Genérico — sem nenhum conhecimento do app
 * consumidor. Lê o estado inicial do próprio atributo `data-theme` (setado
 * por um script anti-flash antes do Angular bootar, ver `generateAntiFlashScript`)
 * ou de `prefers-color-scheme`, e a partir daí persiste em `localStorage`.
 */
class BsThemeService {
    document = inject(DOCUMENT);
    config = inject(SHELL_THEME_CONFIG);
    themeSignal = signal(this.readInitialTheme(), ...(ngDevMode ? [{ debugName: "themeSignal" }] : []));
    theme = this.themeSignal.asReadonly();
    constructor() {
        this.apply(this.themeSignal());
    }
    toggle() {
        const next = this.themeSignal() === 'dark' ? 'light' : 'dark';
        this.themeSignal.set(next);
        this.apply(next);
    }
    set(theme) {
        if (theme === this.themeSignal())
            return;
        this.themeSignal.set(theme);
        this.apply(theme);
    }
    apply(theme) {
        this.document.documentElement.setAttribute('data-theme', theme);
        try {
            localStorage.setItem(this.config.storageKey, theme);
        }
        catch {
            // localStorage indisponível (modo privado/SSR) — segue só em memória.
        }
    }
    readInitialTheme() {
        const attr = this.document.documentElement.getAttribute('data-theme');
        if (attr === 'light' || attr === 'dark') {
            return attr;
        }
        if (typeof window !== 'undefined' && window.matchMedia) {
            return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
        }
        return this.config.default;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

const SHELL_PALETTE_CONFIG = new InjectionToken('SHELL_PALETTE_CONFIG');
/**
 * Registra o serviço de paleta trocável (`BsPaletteService`) — signal +
 * `data-palette` no `documentElement` + persistência em `localStorage`.
 *
 * O pacote não dita cores: `options` é a lista de paletas do app consumidor
 * (id/label/swatch); os tokens CSS de cada paleta (`--bd-primary*`,
 * `--bs-sidebar-*`) são escritos pelo próprio app usando o mixin
 * `bs-palette()` de `bandeira-shell/styles` — ver `_palette-contract.scss`.
 */
function provideShellPalette(config) {
    return makeEnvironmentProviders([
        {
            provide: SHELL_PALETTE_CONFIG,
            useValue: { storageKey: 'palette', ...config },
        },
    ]);
}

/**
 * Paleta de cor do sistema (primary + chrome do menu) — independente do tema
 * claro/escuro (`BsThemeService`). Mesmo padrão: signal + `data-palette` no
 * `documentElement` + `localStorage`, lido antes do Angular bootar pelo
 * script anti-flash (`generateAntiFlashScript`).
 */
class BsPaletteService {
    document = inject(DOCUMENT);
    config = inject(SHELL_PALETTE_CONFIG);
    paletas = this.config.options;
    paletteSignal = signal(this.readInitialPalette(), ...(ngDevMode ? [{ debugName: "paletteSignal" }] : []));
    palette = this.paletteSignal.asReadonly();
    constructor() {
        this.apply(this.paletteSignal());
    }
    set(id) {
        if (id === this.paletteSignal() || !this.isKnownId(id))
            return;
        this.paletteSignal.set(id);
        this.apply(id);
    }
    apply(id) {
        this.document.documentElement.setAttribute('data-palette', id);
        try {
            localStorage.setItem(this.config.storageKey, id);
        }
        catch {
            // localStorage indisponível (modo privado/SSR) — segue só em memória.
        }
    }
    readInitialPalette() {
        const attr = this.document.documentElement.getAttribute('data-palette');
        if (attr && this.isKnownId(attr))
            return attr;
        return this.config.defaultId;
    }
    isKnownId(value) {
        return this.config.options.some((option) => option.id === value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPaletteService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPaletteService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPaletteService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

function resolveShellLabel(label) {
    return typeof label === 'function' ? label() : label;
}
const SHELL_NAVIGATION_CONFIG = new InjectionToken('SHELL_NAVIGATION_CONFIG');
/** Registra os itens de navegação do shell (sidebar, nav horizontal, mobile). */
function provideShellNavigation(items) {
    return makeEnvironmentProviders([{ provide: SHELL_NAVIGATION_CONFIG, useValue: items }]);
}

const STORAGE_KEY = 'navigation-layout';
/** Alterna entre sidebar e nav horizontal — genérico, sem conhecimento de domínio. */
class BsNavigationLayoutService {
    layoutSignal = signal(this.readInitialLayout(), ...(ngDevMode ? [{ debugName: "layoutSignal" }] : []));
    layout = this.layoutSignal.asReadonly();
    toggle() {
        const next = this.layoutSignal() === 'sidebar' ? 'horizontal' : 'sidebar';
        this.layoutSignal.set(next);
        try {
            localStorage.setItem(STORAGE_KEY, next);
        }
        catch {
            // localStorage indisponível — mantém a escolha enquanto a sessão estiver aberta.
        }
    }
    readInitialLayout() {
        try {
            return localStorage.getItem(STORAGE_KEY) === 'horizontal' ? 'horizontal' : 'sidebar';
        }
        catch {
            return 'sidebar';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationLayoutService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationLayoutService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationLayoutService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Sinaliza que uma navegação está em andamento — útil quando as rotas são
 * lazy (`loadComponent`) e trocar de tela baixa um chunk sem indicador algum.
 * Trata todos os desfechos de navegação, não só o feliz: só ouvir
 * `NavigationStart`/`NavigationEnd` deixaria o indicador preso quando um
 * guard cancela a navegação.
 */
class BsNavigationProgressService {
    router = inject(Router);
    navegandoSignal = signal(false, ...(ngDevMode ? [{ debugName: "navegandoSignal" }] : []));
    navegando = this.navegandoSignal.asReadonly();
    constructor() {
        this.router.events.pipe(takeUntilDestroyed()).subscribe((evento) => {
            if (evento instanceof NavigationStart) {
                this.navegandoSignal.set(true);
                return;
            }
            if (evento instanceof NavigationEnd ||
                evento instanceof NavigationCancel ||
                evento instanceof NavigationError ||
                evento instanceof NavigationSkipped) {
                this.navegandoSignal.set(false);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationProgressService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationProgressService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNavigationProgressService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * Pilha de overlays fecháveis (menu "mais" mobile, dropdown de paleta,
 * modais). Qualquer camada se registra ao abrir; o botão físico de voltar
 * (Capacitor) ou uma tecla Escape fecham só o topo da pilha, sem saber o que
 * cada camada é.
 */
class BsOverlayStackService {
    camadas = [];
    registrar(fechar) {
        this.camadas.push(fechar);
        return () => {
            const indice = this.camadas.lastIndexOf(fechar);
            if (indice >= 0)
                this.camadas.splice(indice, 1);
        };
    }
    fecharTopo() {
        const fechar = this.camadas.pop();
        if (!fechar)
            return false;
        fechar();
        return true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsOverlayStackService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsOverlayStackService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsOverlayStackService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class BsPlatformService {
    isNative = Capacitor.isNativePlatform();
    isAndroid = Capacitor.getPlatform() === 'android';
    isIos = Capacitor.getPlatform() === 'ios';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsPlatformService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const SHELL_NATIVE_CONFIG = new InjectionToken('SHELL_NATIVE_CONFIG');
const NOOP = () => { };
function provideShellNative(config) {
    return makeEnvironmentProviders([
        {
            provide: SHELL_NATIVE_CONFIG,
            useValue: {
                exitConfirmWindowMs: 2000,
                onExitConfirmRequested: NOOP,
                onResume: NOOP,
                autoStart: true,
                ...config,
            },
        },
    ]);
}

/**
 * Comportamento nativo do shell no Capacitor: botão físico de voltar,
 * barra de status reagindo ao tema, splash e revalidação de sessão ao
 * voltar do segundo plano. No-op completo no navegador (`BsPlatformService.isNative`).
 */
class BsNativeShellService {
    platform = inject(BsPlatformService);
    zone = inject(NgZone);
    router = inject(Router);
    overlays = inject(BsOverlayStackService);
    theme = inject(BsThemeService);
    config = inject(SHELL_NATIVE_CONFIG);
    listeners = [];
    saidaConfirmadaAte = 0;
    iniciado = false;
    constructor() {
        // Fora do `start()` porque effect() exige contexto de injeção. Só age
        // quando o app nativo já iniciou.
        effect(() => {
            const tema = this.theme.theme();
            if (!this.platform.isNative || !this.iniciado)
                return;
            // `Style.Dark` = conteúdo claro sobre fundo escuro.
            void StatusBar.setStyle({ style: tema === 'dark' ? Style.Dark : Style.Light }).catch(() => {
                // Alguns aparelhos não expõem a barra; não é motivo para quebrar o boot.
            });
        });
    }
    /** Chamado uma vez, depois do bootstrap do Angular (ver `provideShellNative`/`autoStart`). */
    start() {
        if (!this.platform.isNative || this.iniciado)
            return;
        this.iniciado = true;
        void SplashScreen.hide().catch(() => {
            // Splash já escondida (ou plugin ausente): segue o jogo.
        });
        void App.addListener('backButton', ({ canGoBack }) => {
            this.zone.run(() => this.onBackButton(canGoBack));
        }).then((listener) => this.listeners.push(listener));
        void App.addListener('appStateChange', ({ isActive }) => {
            this.zone.run(() => this.onAppStateChange(isActive));
        }).then((listener) => this.listeners.push(listener));
    }
    async stop() {
        await Promise.all(this.listeners.map((listener) => listener.remove()));
        this.listeners.length = 0;
        this.iniciado = false;
    }
    onBackButton(canGoBack) {
        // 1. O que estiver por cima fecha primeiro.
        if (this.overlays.fecharTopo())
            return;
        // 2. Fora das raízes, voltar é navegar para trás.
        const naRaiz = this.config.rootRoutes.includes(this.router.url.split('?')[0]);
        if (canGoBack && !naRaiz) {
            window.history.back();
            return;
        }
        // 3. Na raiz, sair — mas só no segundo toque, para não fechar sem querer.
        const agora = Date.now();
        if (agora < this.saidaConfirmadaAte) {
            void App.exitApp();
            return;
        }
        this.saidaConfirmadaAte = agora + this.config.exitConfirmWindowMs;
        this.config.onExitConfirmRequested();
    }
    onAppStateChange(isActive) {
        if (!isActive)
            return;
        this.config.onResume();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.30", ngImport: i0, type: BsNativeShellService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

function generateAntiFlashScript(paletteIds, options) {
    const themeKey = options.themeStorageKey ?? 'theme';
    const paletteKey = options.paletteStorageKey ?? 'palette';
    const ids = JSON.stringify(paletteIds);
    const defaultId = JSON.stringify(options.defaultPaletteId);
    return `<script>
  (function () {
    try {
      var t = localStorage.getItem(${JSON.stringify(themeKey)});
      if (!t) t = window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', t);

      var validPalettes = ${ids};
      var p = localStorage.getItem(${JSON.stringify(paletteKey)});
      if (validPalettes.indexOf(p) === -1) p = ${defaultId};
      document.documentElement.setAttribute('data-palette', p);
    } catch (e) {}
  })();
</script>`;
}

/**
 * Açúcar sintático: registra tema, paleta, navegação e (opcionalmente) o
 * comportamento nativo do shell num só `provide*()`, no espírito de
 * `provideRouter`/`provideHttpClient`. Equivale a chamar `provideShellTheme`
 * + `provideShellPalette` + `provideShellNavigation` + `provideShellNative`
 * separadamente — use as funções individuais se precisar de mais controle
 * sobre a ordem/composição dos providers.
 */
function provideShell(config) {
    const providers = [
        provideShellTheme(config.theme),
        provideShellPalette(config.palette),
        provideShellNavigation(config.navigation),
    ];
    if (config.native) {
        providers.push(provideShellNative(config.native));
        if (config.native.autoStart !== false) {
            providers.push(makeEnvironmentProviders([
                provideAppInitializer(() => {
                    const nativeConfig = inject(SHELL_NATIVE_CONFIG);
                    if (nativeConfig.autoStart)
                        inject(BsNativeShellService).start();
                }),
            ]));
        }
    }
    return makeEnvironmentProviders(providers);
}

/*
 * Public API surface of bandeira-shell
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BsNativeShellService, BsNavigationLayoutService, BsNavigationProgressService, BsOverlayStackService, BsPaletteService, BsPlatformService, BsThemeService, SHELL_NATIVE_CONFIG, SHELL_NAVIGATION_CONFIG, SHELL_PALETTE_CONFIG, SHELL_THEME_CONFIG, generateAntiFlashScript, provideShell, provideShellNative, provideShellNavigation, provideShellPalette, provideShellTheme, resolveShellLabel };
//# sourceMappingURL=bandeira-shell.mjs.map
